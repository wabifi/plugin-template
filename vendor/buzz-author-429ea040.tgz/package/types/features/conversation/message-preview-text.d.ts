/** A compact excerpt: stop before an empty paragraph rather than clamping a blank line. */
export declare function messagePreviewText(content: string): string;
