import type { RelaySession } from "../relay/session";
import type { ChannelReference } from "../relay/contracts";
/** Mounted only while a preview is open. The session owns access, edits and deletion. */
export declare function BuzzLinkPreview({ session, channelId, messageId, }: {
    session: RelaySession;
    channelId: string;
    messageId: string;
}): import("react").JSX.Element;
/** Hover card for a channel-only link. The store supplies what the reader
 * may see; a nonmember sees an open channel's public metadata, never its
 * roster. */
export declare function ChannelLinkPreview({ channel, }: {
    channel: Extract<ChannelReference, {
        state: "found";
    }>;
}): import("react").JSX.Element;
