import type { ComponentType, ReactNode } from "react";
import { type EmbeddedThreadProps } from "./EmbeddedThread";
import { Service, type Context } from "@deepseek-ai/cordis";
import { type MessageComposerProps } from "../messages/MessageComposer";
import { type MessageRowProps } from "../messages/MessageRow";
import { formatDayGroupLabel, formatFullTimestamp, formatItemTimestamp } from "../../shared/datetime";
import { relativeTimestamp } from "../../shared/relative-timestamp";
import type { AttachmentRenderer, CodeBlockRenderer, ComposerTool, ComposerAccessory, ComposerCompletion, InlineRenderer, LinkRenderer, MessageRenderer, MessageAction, ContributionReader, PageTabsProps } from "./contracts";
export type Conversation = {
    attachments: ContributionReader<AttachmentRenderer>;
    registerAttachment(renderer: AttachmentRenderer): void;
    messages: ContributionReader<MessageRenderer>;
    registerMessage(renderer: MessageRenderer): void;
    accessories: ContributionReader<ComposerAccessory>;
    registerAccessory(accessory: ComposerAccessory): void;
    tools: ContributionReader<ComposerTool>;
    registerTool(tool: ComposerTool): void;
    completions: ContributionReader<ComposerCompletion>;
    registerCompletion(provider: ComposerCompletion): void;
    inline: ContributionReader<InlineRenderer>;
    registerInline(renderer: InlineRenderer): void;
    links: ContributionReader<LinkRenderer>;
    registerLink(renderer: LinkRenderer): void;
    codeBlocks: ContributionReader<CodeBlockRenderer>;
    registerCodeBlock(renderer: CodeBlockRenderer): void;
    actions: ContributionReader<MessageAction>;
    registerMessageAction(action: MessageAction): void;
    ui: {
        Thread: (props: EmbeddedThreadProps) => ReactNode;
        Composer: (props: Omit<MessageComposerProps, "extensions">) => ReactNode;
        Message: (props: Omit<MessageRowProps, "extensions">) => ReactNode;
        /** The page's content as the first tab, beside conversations it opens;
         * absent until a plugin provides the tab workspace, as Channels does. */
        readonly Tabs?: ((props: PageTabsProps) => ReactNode) | undefined;
    };
    /** Provides `ui.Tabs` while the providing plugin runs; the first one wins. */
    registerTabs(component: ComponentType<PageTabsProps>): void;
    /** The host's date labels, so plugin text reads like the message rows. */
    format: {
        /** "9:05 AM", "Yesterday", "Monday", "Sat, Jun 20", "Jun 20, 2025";
         * `withTime` appends " at 9:05 AM" outside today. */
        itemTimestamp: typeof formatItemTimestamp;
        /** The day divider: "Today", "Yesterday", "Monday", "Saturday, June 20",
         * "June 20, 2025". */
        dayGroupLabel: typeof formatDayGroupLabel;
        /** The hover text on a byline: "Friday, October 2, 2026 at 3:05:09 PM EDT". */
        fullTimestamp: typeof formatFullTimestamp;
        /** Link previews: "just now", "5 minutes ago", "3 days ago", "on Jun 20". */
        relativeTimestamp: typeof relativeTimestamp;
    };
};
declare module "@deepseek-ai/cordis" {
    interface Context {
        conversation: Conversation;
    }
}
export declare class ConversationService extends Service implements Conversation {
    readonly attachments: {
        snapshot: () => readonly Readonly<Readonly<{
            id: string;
            title: string;
            matches(attachment: import("../relay/contracts").Attachment): boolean;
            component: ComponentType<import("./contracts").AttachmentRendererProps>;
        }> & {
            key: string;
            pluginId: string;
            revision: string;
            source?: "bundled" | "external";
        }>[];
        subscribe: (listener: () => void) => () => void;
    };
    private readonly attachmentEntries;
    readonly messages: {
        snapshot: () => readonly Readonly<Readonly<{
            id: string;
            title: string;
            matches(message: import("../relay/contracts").ChannelMessage): boolean;
            component: ComponentType<import("./contracts").TargetOpener & {
                message: import("../relay/contracts").ChannelMessage;
            }>;
        }> & {
            key: string;
            pluginId: string;
            revision: string;
            source?: "bundled" | "external";
        }>[];
        subscribe: (listener: () => void) => () => void;
    };
    private readonly messageEntries;
    readonly tools: {
        snapshot: () => readonly Readonly<Readonly<{
            id: string;
            title: string;
            order?: number;
            component: ComponentType<import("./contracts").ComposerToolProps>;
            reactionComponent?: ComponentType<import("./contracts").ReactionToolProps>;
        }> & {
            key: string;
            pluginId: string;
            revision: string;
            source?: "bundled" | "external";
        }>[];
        subscribe: (listener: () => void) => () => void;
    };
    readonly accessories: {
        snapshot: () => readonly Readonly<Readonly<{
            placement?: "composer" | "message";
            decoratesMessageSummary?: boolean;
            id: string;
            title: string;
            order?: number;
            component: ComponentType<import("./contracts").ComposerAccessoryProps>;
        }> & {
            key: string;
            pluginId: string;
            revision: string;
            source?: "bundled" | "external";
        }>[];
        subscribe: (listener: () => void) => () => void;
    };
    private readonly accessoryEntries;
    readonly completions: {
        snapshot: () => readonly Readonly<Readonly<{
            id: string;
            title: string;
            order?: number;
            match(observation: import("./contracts").ComposerObservation, context: import("./contracts").CompletionContext): import("./contracts").CompletionQuery | null;
            component: ComponentType<import("./contracts").ComposerCompletionProps>;
        }> & {
            key: string;
            pluginId: string;
            revision: string;
            source?: "bundled" | "external";
        }>[];
        subscribe: (listener: () => void) => () => void;
    };
    private readonly completionEntries;
    readonly inline: {
        snapshot: () => readonly Readonly<Readonly<{
            id: string;
            title: string;
            matches(content: import("./contracts").InlineContent): readonly Readonly<{
                start: number;
                end: number;
            }>[];
            component: ComponentType<import("./contracts").TargetOpener & {
                text: string;
                content: import("./contracts").InlineContent;
                media(url: string): string | undefined;
            }>;
        }> & {
            key: string;
            pluginId: string;
            revision: string;
            source?: "bundled" | "external";
        }>[];
        subscribe: (listener: () => void) => () => void;
    };
    private readonly toolEntries;
    private readonly inlineEntries;
    readonly links: {
        snapshot: () => readonly Readonly<Readonly<{
            id: string;
            title: string;
            matches(url: string): boolean;
            order?: import("../../plugins/contributions").MatchOrder | undefined;
            className?: string | undefined;
            component: ComponentType<{
                url: string;
            }>;
        }> & {
            key: string;
            pluginId: string;
            revision: string;
            source?: "bundled" | "external";
        }>[];
        subscribe: (listener: () => void) => () => void;
    };
    private readonly linkEntries;
    readonly codeBlocks: {
        snapshot: () => readonly Readonly<Readonly<{
            id: string;
            title: string;
            matches(language: string): boolean;
            component: ComponentType<{
                code: string;
                language: string;
            }>;
            action?: ComponentType<{
                code: string;
                language: string;
            }> | undefined;
        }> & {
            key: string;
            pluginId: string;
            revision: string;
            source?: "bundled" | "external";
        }>[];
        subscribe: (listener: () => void) => () => void;
    };
    private readonly codeBlockEntries;
    readonly actions: {
        snapshot: () => readonly Readonly<Readonly<{
            id: string;
            title: string;
            icon?: ComponentType;
            matches(message: import("../relay/contracts").ChannelMessage, session: import("../relay/session").RelaySession): boolean;
            component: ComponentType<import("./contracts").TargetOpener & {
                message: import("../relay/contracts").ChannelMessage;
                session: import("../relay/session").RelaySession;
                close(): void;
            }>;
            marker?: ComponentType<{
                message: import("../relay/contracts").ChannelMessage;
                session: import("../relay/session").RelaySession;
            }>;
        }> & {
            key: string;
            pluginId: string;
            revision: string;
            source?: "bundled" | "external";
        }>[];
        subscribe: (listener: () => void) => () => void;
    };
    private readonly actionEntries;
    private readonly tabEntries;
    readonly ui: Conversation["ui"];
    constructor(ctx: Context);
    registerTabs(component: ComponentType<PageTabsProps>): void;
    registerMessageAction(value: MessageAction): void;
    registerAttachment(value: AttachmentRenderer): void;
    registerMessage(value: MessageRenderer): void;
    registerAccessory(value: ComposerAccessory): void;
    registerTool(value: ComposerTool): void;
    registerCompletion(value: ComposerCompletion): void;
    registerInline(value: InlineRenderer): void;
    registerLink(value: LinkRenderer): void;
    registerCodeBlock(value: CodeBlockRenderer): void;
    readonly format: Readonly<{
        itemTimestamp: typeof formatItemTimestamp;
        dayGroupLabel: typeof formatDayGroupLabel;
        fullTimestamp: typeof formatFullTimestamp;
        relativeTimestamp: typeof relativeTimestamp;
    }>;
}
