import { type ReactNode } from "react";
/** Optional host-resolved display label; presentation never resolves a destination. */
export declare const LinkLabelContext: import("react").Context<string | undefined>;
/** Authored Markdown formatting stays inside the host anchor. */
export declare const LinkContentContext: import("react").Context<ReactNode>;
/** Host-resolved visibility for channel links rendered by a shared link renderer. */
export declare const LinkChannelPrivateContext: import("react").Context<boolean>;
/** Host workspace opener for a message link's thread tab; false when it cannot. */
export declare const LinkThreadTabContext: import("react").Context<((channelId: string, messageId: string, rootId: string) => boolean) | undefined>;
