import type { Contribution } from "../../plugins/contributions";
import type { ComposerCompletion, ComposerObservation, CompletionContext, CompletionQuery, CompletionResult } from "./contracts";
export declare function matchCompletion(providers: readonly Contribution<ComposerCompletion>[], observation: ComposerObservation, context: CompletionContext, resolved?: readonly Readonly<{
    start: number;
    end: number;
}>[]): {
    provider: Contribution<ComposerCompletion>;
    query: CompletionQuery;
} | undefined;
/** Copy edit primitives so later provider mutation cannot retarget a displayed choice. */
export declare function completionResult(result: CompletionResult): CompletionResult;
