import { type ReactNode } from "react";
import type { ChannelMessage } from "../relay/contracts";
import type { ContributionReader, MessageRenderer } from "./contracts";
/** First active match wins; a broken optional renderer leaves the host fallback. */
export declare function MessageBody({ registry, message, children, }: {
    registry: ContributionReader<MessageRenderer>;
    message: ChannelMessage;
    children: ReactNode;
}): string | number | bigint | boolean | import("react").JSX.Element | Iterable<ReactNode> | Promise<string | number | bigint | boolean | Iterable<ReactNode> | import("react").ReactElement<unknown, string | import("react").JSXElementConstructor<any>> | import("react").ReactPortal | null | undefined> | null | undefined;
