import type { ComposerSnapshot } from "../messages/mention-draft";
import type { ComposerInputElement } from "../messages/composer-dom";
import { type RefObject } from "react";
import type { ComposerCompletion, CompletionContext, CompletionEdit, CompletionQuery, ComposerObservation, ContributionReader } from "./contracts";
import type { CompletionEditor } from "./useCompletionEditor";
export declare function ComposerCompletions({ registry, editor, input, replace, resolved, ...context }: CompletionContext & {
    registry: ContributionReader<ComposerCompletion>;
    editor: CompletionEditor;
    input: RefObject<ComposerInputElement | null>;
    /** Chip ranges and the draft text they were measured against. */
    resolved: Readonly<{
        text: string;
        document?: ComposerSnapshot;
        recipients: readonly Readonly<{
            start: number;
            end: number;
        }>[];
    }>;
    replace(edit: CompletionEdit, query: CompletionQuery, observation: ComposerObservation, key?: string): boolean;
}): import("react").JSX.Element | null;
