import { type ReactNode } from "react";
import type { RelaySession } from "../relay/session";
type Replacement = Readonly<{
    session: RelaySession;
    channelId: string;
    threadRootId: string | undefined;
    pubkey: string;
}>;
/** Mounted conversation presentation only; no data, timers, or plugin identity checks. */
export declare function TypingPresentation({ active, children, }: {
    active: boolean;
    children: ReactNode;
}): import("react").JSX.Element;
export declare function useTypingReplacement(value: Replacement, enabled: boolean): void;
export declare function useReplacedTypers(session: object | undefined, channelId: string, threadRootId: string | undefined): Set<string>;
export {};
