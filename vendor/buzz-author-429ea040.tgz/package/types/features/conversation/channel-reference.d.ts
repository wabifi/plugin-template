import type { ChannelQueries, ChannelReference } from "../relay/contracts";
/**
 * What a channel-only link can show about a channel the reader may not have
 * joined. The store owns the lookup, its batching, expiry and retry; this
 * hook only demands one while the answer isn't `found` and the list is
 * ready, because discovery owns access.
 */
export declare function useChannelReference(queries: ChannelQueries | undefined, channelId: string | undefined): ChannelReference;
