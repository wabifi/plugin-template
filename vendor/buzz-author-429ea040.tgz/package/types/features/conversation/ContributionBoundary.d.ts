import { Component, type ReactNode } from "react";
export declare function contributionKey(entry: object): number;
export declare class ContributionBoundary extends Component<{
    children: ReactNode;
    fallback: ReactNode;
}, {
    failed: boolean;
}> {
    state: {
        failed: boolean;
    };
    static getDerivedStateFromError(): {
        failed: boolean;
    };
    render(): ReactNode;
}
