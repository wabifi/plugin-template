import type { ComposerInputElement } from "../messages/composer-dom";
import { type RefObject, type KeyboardEvent } from "react";
import type { ComposerObservation } from "./contracts";
/** One synchronous invalidation owner; stale React closures cannot revive an edit. */
export declare function useCompletionEditor(input: RefObject<ComposerInputElement | null>, enabled: boolean): {
    observation: Readonly<{
        revision: number;
        text: string;
        start: number;
        end: number;
    }> | undefined;
    valid: (expected: ComposerObservation) => boolean;
    observe: (force?: boolean) => void;
    invalidate: () => void;
    keys: RefObject<((event: KeyboardEvent<ComposerInputElement>) => boolean) | undefined>;
    composing: RefObject<boolean>;
};
export type CompletionEditor = ReturnType<typeof useCompletionEditor>;
