import type { ComposerInputElement } from "../messages/composer-dom";
import { type RefObject } from "react";
/** Portal positioning belongs to the host, not provider previews. The available
 * visual viewport bounds the menu even inside clipped/narrow conversation panels. */
export declare function useCompletionPosition(input: RefObject<ComposerInputElement | null>, widthRatio?: number, { preferAbove, gap, maxWidth, }?: {
    preferAbove?: boolean;
    gap?: number;
    maxWidth?: number;
}): RefObject<HTMLElement | null>;
