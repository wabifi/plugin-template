import { type ComponentProps, type ReactNode } from "react";
import type { ChannelSummary } from "../relay/contracts";
import { type ChannelTimelineProps } from "../messages/ChannelTimeline";
import { type MessageComposerProps } from "../messages/MessageComposer";
import { MediaReviewViewer } from "../messages/MediaReviewViewer";
import { type ThreadPanelProps } from "../messages/ThreadPanel";
import { type ConversationHostServices, type ConversationInteractions } from "./ConversationHost";
/** Everything a reader or composer needs from its channel, supplied once,
 * including the Solo policy, so no view can open a chat under other rules. */
type Conversation = Pick<ThreadPanelProps, "session" | "scope" | "channelId" | "channelName" | "extensions"> & ConversationInteractions & {
    soloConversation: boolean;
    ownSoloConversation: boolean;
};
type Shared = keyof Conversation;
/** Pages supply only their own policy, and may relabel the channel. */
type Own<P> = Omit<P, Shared> & Partial<Pick<P, Extract<keyof P, "channelName">>>;
/** A page's open review; the scope supplies its conversation. */
export type MediaReview = Pick<ComponentProps<typeof MediaReviewViewer>, "messageId" | "attachment" | "initialTime" | "hasComments" | "restoreFocus" | "close">;
/** A review that opens over its page and returns focus to its opener. */
export declare function useMediaReview(): {
    open: (messageId: string, attachment: import("../relay/contracts").ChannelMessage["attachments"][number], seconds: number, hasComments?: boolean) => void;
    review: MediaReview | undefined;
};
export declare function useConversation(): Conversation;
type ChannelProps = Pick<Conversation, "session" | "scope" | "extensions"> & {
    /** Absent while a page has no selected channel; readers need one. */
    channel?: {
        id: string;
        name: string;
        channelType?: ChannelSummary["channelType"] | undefined;
        /** Decides whether this is the viewer's own Solo chat; see ownSolo. */
        creator?: ChannelSummary["creator"] | undefined;
    } | undefined;
    /** Presentation name, when the page labels the channel differently. */
    channelName?: string | undefined;
    /** Whether the channel visit marks it read; see MessageManagement. */
    active?: boolean | undefined;
    children: ReactNode;
} & ({
    interactions: ConversationInteractions;
    /** The page owns when a review opens and retires. */
    mediaReview?: MediaReview | undefined;
    host?: undefined;
} | {
    /** Pages without their own placement use the shared dialog host. */
    host: ConversationHostServices;
    /** Overlays belong to one thread; recovery spans the channel. */
    threadId?: string | undefined;
    interactions?: undefined;
    mediaReview?: undefined;
});
/** One channel's editing recovery, visit and interactions for every reader in it. */
export declare function ConversationChannel(props: ChannelProps): import("react").JSX.Element;
export declare function ConversationThread(props: Own<ThreadPanelProps>): import("react").JSX.Element;
export declare function ConversationTimeline(props: Own<Omit<ChannelTimelineProps, "queries">>): import("react").JSX.Element;
export declare function ConversationComposer(props: Own<MessageComposerProps>): import("react").JSX.Element;
export {};
