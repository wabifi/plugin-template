import type { ComposerAccessory, ComposerAccessoryProps, ContributionReader } from "./contracts";
export declare function ComposerAccessories({ registry, ...props }: ComposerAccessoryProps & {
    registry: ContributionReader<ComposerAccessory>;
}): import("react").JSX.Element;
