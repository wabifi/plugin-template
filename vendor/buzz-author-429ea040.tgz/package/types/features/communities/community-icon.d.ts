/** Keep untrusted relay metadata out of executable URL schemes and huge data URLs. */
export declare function communityIcon(value: unknown): string | undefined;
/** Existing optional NIP-11 discovery, without join policy or a relay session. */
export declare function fetchCommunityPresentation(id: string, signal: AbortSignal): Promise<{
    publishedName: string | undefined;
    publishedIcon: string | undefined;
}>;
