/** What Desktop tells its native side about this identity's communities (CLO-439). A community is
 * its relay origin. The native side keeps its own record, so Wabifi Agents' owner.json can only
 * ever name a community the person joined. */
export type JoinedChange = {
    op: "add" | "remove";
    relay: string;
} | {
    op: "seed";
    relays: string[];
};
export declare const recordJoinedCommunity: (change: JoinedChange) => Promise<void>;
