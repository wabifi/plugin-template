/** A community is a secure origin, never a credential-bearing URL or an API path. */
export declare function relayOrigin(input: string): string;
/** A short deployment ID is not a URL and must never acquire a session by itself. */
export declare function isCommunityAlias(value: string): boolean;
/** Optional deployment aliases preserve existing saved IDs without shipping a community list. */
export declare function parseCommunityAliases(raw?: string): Readonly<Record<string, string>>;
export declare function communityDestination(value: string, aliases?: Readonly<Record<string, string>>): {
    id: string;
    url: string;
    name: string;
};
