import type { LocalAgentSource } from "../agents/local-activity";
import type { LocalAgents } from "../agents/local";
import type { IdentityNames } from "../identity-names/service";
import { Context } from "@deepseek-ai/cordis";
import { type RelayData } from "../relay/service";
import { type ReadTransport } from "../relay/transport";
import { type PurgeFailure } from "./device-state";
import type { JoinedChange } from "./joined-native";
export declare const PROFILE_ABOUT_MAX_LENGTH = 500;
export type PersonalProfile = {
    name: string;
    picture: string;
    about?: string;
};
export type Membership = {
    id: string;
    /** Last-known default from joining; never inferred to be a personal override. */
    name: string;
    icon?: string;
    localName?: string | undefined;
    /** Optional current public metadata; not ownership or membership evidence. */
    publishedName?: string | undefined;
    publishedIcon?: string | undefined;
};
type Saved = {
    profile: PersonalProfile;
    memberships: Membership[];
    selected: string | null;
};
export type ClientSnapshot = Saved & {
    status: "loading" | "ready" | "unavailable";
    relayAvailable: boolean;
    viewer?: string;
    error?: string;
};
/** Read-only membership inventory; does not acquire or select relay sessions. */
export type CommunityReader = {
    snapshot(): ClientSnapshot;
    subscribe(listener: () => void): () => void;
};
declare module "@deepseek-ai/cordis" {
    interface Context {
        communityReader: CommunityReader;
    }
}
export declare function createCommunities(ctx: Context, live: boolean, identityNames?: IdentityNames, openRelay?: string, agentChoices?: LocalAgents, identityReady?: Promise<string>, nativeConnect?: (id: string, signal: AbortSignal) => Promise<ReadTransport>, localAgents?: LocalAgentSource, 
/** Desktop only: tells the native side which communities this identity joined (CLO-439). */
recordJoined?: (change: JoinedChange) => Promise<void>): {
    presence: {
        status: () => "online" | "away" | "offline";
        command: () => number;
        snapshot: () => {
            status: ReturnType<() => "online" | "away" | "offline">;
            preference: import("../presence/activity").PresencePreference;
            error: string | undefined;
        };
        setViewer(value: string): void;
        setPreference(value: import("../presence/activity").PresencePreference): void;
        visible: () => boolean;
        subscribe(listener: () => void): () => void;
        dispose(): void;
    };
    relay: RelayData;
    snapshot: () => ClientSnapshot;
    subscribe(fn: () => void): () => void;
    retainPresentation(): () => void;
    setLocalName(id: string, viewer: string, value: string): void;
    select(id: string | null): void;
    /** A joined community's session, connected without selecting it, for
     * background work such as agents; it lives until the community is left. */
    open(id: string): RelayData | undefined;
    saveProfile(profile: PersonalProfile): void;
    joined(membership: Membership, profile: PersonalProfile): void;
    /** Forgets a saved community on this device once its relay has released
     * the membership (or never held one). Drops the membership, falls back to
     * Personal space when it was selected, disposes its retained session, then
     * purges the device state keyed by that origin and viewer. Persistence
     * follows `joined`: required where the device record is the only copy, and
     * that save is the only step that throws, before anything has changed.
     * Everything after it is best effort: a session that would not dispose or
     * a store that would not clear is logged and returned, never thrown, since
     * the membership is already gone and only a report can reach the viewer.
     *
     * `purge: false` keeps the device state. It is for a relay that refused
     * the leave because the viewer is banned: the relay still holds the
     * membership (bans can be timed or lifted), so the drafts and reading
     * positions keyed by this origin and viewer are kept for the day the
     * community is added again by its URL. */
    leave(id: string, { purge }?: {
        purge?: boolean;
    }): Promise<PurgeFailure[]>;
};
export type Communities = ReturnType<typeof createCommunities>;
export {};
