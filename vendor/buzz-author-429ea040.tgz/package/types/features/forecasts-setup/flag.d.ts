export declare const FORECASTS_SETUP_FLAG = "VITE_BUZZ_FORECASTS_SETUP";
export declare const forecastsSetupEnabled: () => boolean;
