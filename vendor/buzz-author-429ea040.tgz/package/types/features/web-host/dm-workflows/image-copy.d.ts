export declare function copyBrowserImage(source: string, image: HTMLImageElement): Promise<void>;
