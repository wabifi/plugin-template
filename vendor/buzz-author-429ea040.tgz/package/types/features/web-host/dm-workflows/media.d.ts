export declare function browserMediaSource(source: string): boolean;
export declare function browserDownloadName(name: string): string;
export declare function downloadBrowserMedia(source: string, name?: string): void;
