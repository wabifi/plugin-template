export type Template = Readonly<{
    kind: number;
    created_at: number;
    tags: readonly (readonly string[])[];
    content: string;
}>;
/** catalog.rs MAX_EVENT_BYTES: escaping at most doubles content, plus tags. */
export declare const CATALOG_EVENT_BYTES: number;
/** identity.rs Key::sign: the default serialized-event bound. */
export declare const EVENT_BYTES: number;
/** relay.rs ARTIFACT_MAX_EVENT_BYTES: the relay's 512 KiB frame less the EVENT wrapper. */
export declare const ARTIFACT_MAX_EVENT_BYTES: number;
/** identity.rs EventTemplate: deny unknown fields, u16 kind, u64 created_at. */
export declare function parseTemplate(value: unknown): Template;
/** relay.rs `origin`: an https origin without credentials, path, query or fragment. */
export declare function httpsOrigin(value: string): URL;
/** relay.rs `valid_plugin_list`: the community plugin list (fork/plugin-directory.md). */
export declare function validPluginList(event: Template): boolean;
/** channel_writes.rs `creation`: fixed tag order, optional about/ttl, up to 8
 * labels, up to 32 first members, then an optional client-id. */
export declare function validCreation(event: Template): boolean;
/** catalog.rs `valid`: owner-to-self NIP-AP envelopes with no secrets. */
export declare function validCatalog(event: Template): boolean;
/** relay.rs `validate_event`. Throws the desktop's error text. */
export declare function validateEvent(community: string, event: Template): void;
/** relay.rs `relay_sign` around validate_event: channel creation needs the
 * relay's NIP-29, 30078 never signs here, a coordinate delete names its own
 * author, and the serialized event stays inside the signing bound. */
export declare function signingTemplate(community: string, viewer: string, creation: boolean, value: unknown): Template;
/** The kinds the outbox may offer: those signingTemplate can accept. */
export declare const webWriteKinds: (creation: boolean) => number[];
/** relay.rs `request_url`: the only signed POSTs and unsigned GETs. */
export declare function requestUrl(community: string, path: string, method: string): string;
/** relay.rs `media_url`: only this community's content-addressed blobs. */
export declare function mediaUrl(target: string): URL | undefined;
