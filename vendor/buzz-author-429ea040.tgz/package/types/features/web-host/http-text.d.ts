export declare function boundedResponseText(response: Response, limit: number): Promise<string>;
