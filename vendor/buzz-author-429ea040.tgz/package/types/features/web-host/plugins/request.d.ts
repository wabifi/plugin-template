import type { HostRequest, HostResponse } from "../../host/service";
import type { StorageResult } from "../../../plugins/types";
export declare function browserPluginRequest(owner: {
    id: string;
    revision: string;
}, input: HostRequest, catalog: () => Promise<StorageResult>): Promise<HostResponse>;
