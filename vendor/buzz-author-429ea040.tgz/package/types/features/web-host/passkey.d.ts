/** One passkey assertion; the PRF output when the authenticator gives one. */
export declare function passkeyPrf(credentialId: Uint8Array, salt: Uint8Array): Promise<ArrayBuffer | undefined>;
/** Creates this browser's passkey and evaluates its PRF once. */
export declare function createPasskey(pubkey: string): Promise<{
    credentialId: Uint8Array<ArrayBuffer>;
    salt: Uint8Array<ArrayBuffer>;
    prf: ArrayBuffer | undefined;
}>;
