/** Spawns the host worker. A worker that cannot load (missing script, CSP
 * header refusal) fails every pending call instead of hanging the app. */
export declare function spawnHost(create?: () => Worker): Worker;
/** Calls one host operation. `transfer` moves buffers out of the page. */
export declare function hostCall<T>(op: string, args?: unknown, transfer?: Transferable[]): Promise<T>;
/** Ends the worker, and with it the key in its memory. */
export declare function terminateHost(): void;
