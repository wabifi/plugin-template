export type PairingUri = Readonly<{
    source: string;
    secret: Uint8Array;
    relay: string;
}>;
export type PairedAccount = Readonly<{
    key: Uint8Array;
    pubkey: string;
    community: string | null;
}>;
export type PairingStatus = {
    phase: "connecting";
} | {
    phase: "comparing" | "waiting";
    sas: string;
    requiresDesktopCode: boolean;
    codeAccepted: boolean;
} | {
    phase: "saving";
} | {
    phase: "paired";
} | {
    phase: "failed";
    failure: string;
};
export type PairingSession = Readonly<{
    status(): PairingStatus;
    subscribe(listener: () => void): () => void;
    submitCode(code: string): Promise<boolean>;
    confirm(): void;
    cancel(): void;
}>;
/** `nostrpair://<source>?secret=<hex>&relay=<ws url>`; ws:// only on loopback. */
export declare function parsePairingUri(text: string): PairingUri;
export declare const deriveSessionId: (secret: Uint8Array) => Promise<Uint8Array<ArrayBuffer>>;
export declare const sharedX: (key: Uint8Array, pubkey: string) => Uint8Array<ArrayBuffer>;
export declare function deriveSas(shared: Uint8Array, secret: Uint8Array): Promise<{
    code: string;
    input: Uint8Array<ArrayBuffer>;
}>;
export declare function deriveTranscriptHash(sessionId: Uint8Array, source: string, target: string, sasInput: Uint8Array, secret: Uint8Array): Promise<Uint8Array<ArrayBuffer>>;
export declare function readAccount(payloadType: string, payload: string): PairedAccount | null;
/** Publishes `complete` only after save resolves: the source tells its user
 * the browser has the account once complete arrives. */
export declare function startPairing(uri: PairingUri, save: (account: PairedAccount) => Promise<void>): PairingSession;
