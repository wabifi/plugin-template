import { type UploadProgress } from "../../relay/attachments";
export declare function abortWebUploads(): void;
export declare function sendWebUpload(origin: string, file: File, signal: AbortSignal, progress?: UploadProgress): Promise<Response>;
export declare function webAttachmentUpload(origin: string): import("../../relay/attachments").AttachmentUpload;
