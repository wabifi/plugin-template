import { type ReadTransport } from "../../relay/transport";
import { type WebTransportContext } from "../relay";
export declare function channelCapabilities({ origin, viewer, }: WebTransportContext): Partial<ReadTransport>;
