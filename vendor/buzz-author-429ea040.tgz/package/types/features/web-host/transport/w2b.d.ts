import type { ReadTransport } from "../../relay/transport";
import type { WebTransportContext } from "../relay";
export declare function preferenceCapabilities({ origin, viewer, transport, }: WebTransportContext): Partial<ReadTransport>;
