import type { ReadTransport } from "../../relay/transport";
import type { WebTransportContext } from "../relay";
export declare function w3bCapabilities({ origin, viewer, transport, }: WebTransportContext): Partial<ReadTransport>;
export declare function readAgentHostNote(community: string, agent: string, signal?: AbortSignal): Promise<unknown>;
export declare function prepareRemoteAgentAuthorization(agentPubkey: string, signal?: AbortSignal): Promise<readonly ["auth", string, string, string]>;
