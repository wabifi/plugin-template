import { type ReadTransport } from "../../relay/transport";
import { type WebTransportContext } from "../relay";
export declare function directMessageReceipt(status: number, body: string, eventId: string): string;
export declare function w2cCapabilities({ origin, viewer, }: WebTransportContext): Partial<ReadTransport>;
