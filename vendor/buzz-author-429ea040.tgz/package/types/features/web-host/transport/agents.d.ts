import type { ReadTransport } from "../../relay/transport";
import type { WebTransportContext } from "../relay";
export declare function agentCapabilities(context: WebTransportContext): Partial<ReadTransport>;
