import type { ReadTransport } from "../../relay/transport";
import type { WebTransportContext } from "../relay";
export declare function chatCapabilities(context: WebTransportContext): Partial<ReadTransport>;
