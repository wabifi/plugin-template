import type { ReadTransport } from "../../relay/transport";
import type { WebTransportContext } from "../relay";
export declare function gitArchiveCapabilities({ origin, }: WebTransportContext): Pick<ReadTransport, "authorizeGit">;
