export { channelCapabilities as w2aCapabilities } from "../channel-writers/transport";
