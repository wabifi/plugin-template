type Load = (url: string, signal: AbortSignal) => Promise<Blob>;
/** The ready blob URL, or undefined while loading or after a failure. The
 * first read of a URL starts its one fetch; later reads only look. */
export declare function relayMedia(url: string): string | undefined;
export declare const relayMediaState: (url: string) => "error" | "loading" | "ready" | undefined;
export declare const relayMediaBlob: (source: string) => Blob | undefined;
export declare function subscribeRelayMedia(listener: () => void): () => void;
/** Lets this origin's media load; the returned disposer aborts its fetches
 * and revokes its blob URLs. */
export declare function registerMediaLoader(origin: string, load: Load): () => void;
/** Sign-out: abort every fetch and revoke every blob URL, for all communities. */
export declare function disposeRelayMedia(): void;
/** Re-renders the caller whenever a browser-host media fetch settles, so its
 * `media(url)` reads see the new blob URL. Constant on desktop. */
export declare const useRelayMediaVersion: () => number;
export {};
