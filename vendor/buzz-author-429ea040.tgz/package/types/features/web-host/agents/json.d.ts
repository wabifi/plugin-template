export declare function parseCompatibleJson(text: string): unknown;
export declare function memoryWireRecords(text: string): (unknown | null)[];
