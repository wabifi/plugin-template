/** A Vite dev server, a loopback page origin, and BUZZ_WEB_DEV_UNLOCK=1. */
export declare const devUnlockAllowed: () => boolean;
/** Shown wherever the dev unlock is offered or used. */
export declare const DEV_UNLOCK_WARNING = "Dev unlock: no passkey protects this key, and any script on this page can unlock it. Use only a throwaway test identity, never a real one.";
/** A record saved with no passkey credential, only the browser-held key. */
export declare const savedWithoutPasskey: (record: {
    credentialId: Uint8Array;
}) => boolean;
/** What `enroll` takes in place of a passkey. */
export declare function withoutPasskey(): {
    credentialId: Uint8Array<ArrayBuffer>;
    salt: Uint8Array<ArrayBuffer>;
    prf: undefined;
};
