import { type ReadTransport, type Signer } from "../relay/transport";
/** What a slice's capabilities may build on (W2: transport/chat.ts, W3: transport/agents.ts). */
export type WebTransportContext = Readonly<{
    origin: string;
    viewer: string;
    creation: boolean;
    info: Readonly<Record<string, unknown>>;
    transport: ReadTransport;
}>;
/** The relay HTTP the desktop host allows (relay.rs request_url): unsigned
 * GETs of discovery and join policy, NIP-98-signed POSTs to a fixed list. */
export declare function webRelayRequest(community: string, path: string, body?: unknown, signal?: AbortSignal): Promise<Response>;
export declare function webRelayInfo(community: string, signal?: AbortSignal): Promise<Record<string, unknown>>;
/** A Signer whose key stays in the host worker; the policy runs there too. */
export declare function webSigner(origin: string, viewer: string, creation: boolean): Signer;
/** The browser counterpart of connectNativeTransport: reads, writes, the live
 * stream and encrypted read state, plus what W2 and W3 compose in. */
export declare function connectWebTransport(community: string, signal?: AbortSignal): Promise<ReadTransport>;
