import type { ReadTransport } from "../relay/transport";
import { type PairingStatus } from "./pairing";
export type WebIdentitySnapshot = {
    status: "loading";
} | {
    status: "missing";
    busy: boolean;
    error?: string | undefined;
    pairing?: PairingStatus | undefined;
} | {
    status: "locked";
    busy: boolean;
    error?: string | undefined;
    passkeyDerived: boolean;
    devUnlock?: true | undefined;
} | {
    status: "error";
    error: string;
} | {
    status: "ready";
    viewer: string;
};
/** The browser build with its own key: `BUZZ_WEB_HOST=1`, never Tauri or the dev broker. */
export declare const webHostEnabled: () => boolean;
/** Erases everything this origin stores, then returns to setup. The key goes
 * with the worker; the session and drafts go with storage. */
export declare function forgetThisBrowser(): Promise<void>;
/** The browser counterpart of createIdentity(): a key paired from another
 * device, kept by the host worker in IndexedDB wrapped by a passkey.
 * Snapshots, and this object, hold public data only. */
export declare function createWebIdentity(): {
    ready: Promise<string>;
    community: () => string;
    snapshot: () => WebIdentitySnapshot;
    subscribe(listener: () => void): () => void;
    connect(id: string, signal: AbortSignal): Promise<ReadTransport>;
    pair(code: string, community: string): void;
    submitCode: (code: string) => Promise<boolean>;
    confirm: () => void | undefined;
    cancel(): void;
    /** Creates the passkey and hands the received key to the host worker,
     * which wraps and keeps it; the page's copy is transferred away.
     * `devUnlock` saves it with no passkey (dev-unlock.ts). */
    protect(devUnlock?: boolean): Promise<void>;
    unlock(): Promise<void>;
    forget: typeof forgetThisBrowser;
};
export type WebIdentity = ReturnType<typeof createWebIdentity>;
