export type Custody = Readonly<{
    pubkey: string;
    community: string | null;
    credentialId: Uint8Array;
    salt: Uint8Array;
    iv: Uint8Array;
    ciphertext: Uint8Array;
    fallbackKey?: CryptoKey;
}>;
/** What the page needs to ask for the passkey; no ciphertext, no key. */
export type CustodyRecord = Readonly<{
    pubkey: string;
    community: string | null;
    credentialId: Uint8Array;
    salt: Uint8Array;
    passkeyDerived: boolean;
}>;
export declare function custodyRecord(): Promise<CustodyRecord | null>;
export declare const forgetCustody: () => Promise<undefined>;
/** Wraps the key with the passkey's PRF output (or the fallback) and stores it. */
export declare function enroll(input: {
    key: Uint8Array;
    prf: ArrayBuffer | undefined;
    credentialId: Uint8Array;
    salt: Uint8Array;
    community: string | null;
}): Promise<string>;
/** Decrypts the stored key with the passkey's PRF output, or the fallback. */
export declare function unlock(prf: ArrayBuffer | undefined): Promise<Uint8Array<ArrayBuffer>>;
