/** Ordinary channel visibility chooses its icon; callers retain non-channel type icons. */
export declare function channelIcon(channel: {
    readonly private?: true | undefined;
} | undefined): import("../../shared/design-system/icons/createDecorativeIcon").DefinedIcon;
