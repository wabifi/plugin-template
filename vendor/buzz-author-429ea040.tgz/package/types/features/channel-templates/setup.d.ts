import type { Outbox, LocalEvents } from "../relay/outbox";
export type ChannelSetup = {
    canvas: string;
    agents: string[];
    groupId: string;
    starred?: boolean;
    templateId: string;
};
export type ChannelCreationInput = Readonly<{
    name: string;
    description?: string | undefined;
    visibility: "open" | "private";
    ttlSeconds?: number | undefined;
    /** NIP-CL labels to create the channel with. */
    labels?: readonly string[] | undefined;
    /** Create a NIP-CL system channel: left out of channel lists. */
    system?: true | undefined;
    setup?: ChannelSetup | undefined;
}>;
/** Drops one community's unfinished setup receipts once the viewer has left it;
 * their operations have no outbox left to retire against. */
export declare function forgetChannelSetups(scope: string): void;
/** Frozen intent only. Signing, publication and delivery evidence stay in Outbox. */
export declare function createChannelSetup({ scope, outbox, local, create, delivered, confirm, refresh, canvasHead, place, star, preflight, signal, changed, }: {
    scope: string;
    outbox: Outbox;
    local: LocalEvents;
    create(id: string, input: ChannelCreationInput, active: () => boolean): string;
    /** An active gate permits explicit retry of this exact uncertain Create only. */
    delivered(id: string, active?: () => boolean): Promise<void>;
    /** Observe/read back only; never retry template publications. */
    confirm(id: string): Promise<void>;
    /** Wait for relay roster proof that `member` is in the channel `input` made. */
    refresh(id: string, member: string, input: ChannelCreationInput): Promise<void>;
    canvasHead(id: string): Promise<string | undefined>;
    place(id: string, group: string): Promise<void>;
    star(id: string): Promise<void>;
    preflight(input: ChannelCreationInput): Promise<void>;
    signal: AbortSignal;
    changed(): void;
}): Readonly<{
    run: (input: ChannelCreationInput, viewer: string) => {
        admission: Promise<string>;
        completion: Promise<void>;
    };
    snapshot: () => Readonly<{
        name: string;
        description?: string | undefined;
        visibility: "open" | "private";
        ttlSeconds?: number | undefined;
        /** NIP-CL labels to create the channel with. */
        labels?: readonly string[] | undefined;
        /** Create a NIP-CL system channel: left out of channel lists. */
        system?: true | undefined;
        setup?: ChannelSetup | undefined;
    }> | undefined;
    owns: (id: string) => boolean;
    recovered(id: string): boolean;
}>;
