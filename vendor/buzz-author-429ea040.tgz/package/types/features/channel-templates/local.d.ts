export type ChannelTemplate = Readonly<{
    id: string;
    name: string;
    /** Agents team ids. A team deleted since is skipped. */
    teams: readonly string[];
    /** Agent pubkeys, added alongside the teams' members. */
    agents: readonly string[];
    canvas: string;
}>;
export type ChannelTemplateChange = Omit<ChannelTemplate, "id"> & Readonly<{
    id?: string;
}>;
export declare const TEMPLATES_KEY = "buzz.channel-templates.v1";
export declare const channelTemplates: {
    snapshot(): readonly Readonly<{
        id: string;
        name: string;
        /** Agents team ids. A team deleted since is skipped. */
        teams: readonly string[];
        /** Agent pubkeys, added alongside the teams' members. */
        agents: readonly string[];
        canvas: string;
    }>[];
    subscribe(listener: () => void): () => void;
    /** Creates a template, or replaces the one with `id`. */
    save({ id, name, teams, agents, canvas, }: ChannelTemplateChange): ChannelTemplate;
    remove(id: string): void;
};
export declare function useChannelTemplates(): readonly Readonly<{
    id: string;
    name: string;
    /** Agents team ids. A team deleted since is skipped. */
    teams: readonly string[];
    /** Agent pubkeys, added alongside the teams' members. */
    agents: readonly string[];
    canvas: string;
}>[];
/** The agents a template adds: its own agents and each member of its teams,
 * once, that is one of `agents` (the owner's agents in this community). */
export declare function templateAgents(template: ChannelTemplate, teams: readonly Readonly<{
    id: string;
    members: readonly string[];
}>[], agents: ReadonlySet<string>): string[];
