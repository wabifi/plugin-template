import type { EventData } from "../relay/events";
export declare const SHARED_SESSION_TOPIC = "buzz.shared-session.v1";
/** Use exactly the card renderer's exclusions for quoted, code and hidden links. */
export declare function sessionReferenceIds(content: string): string[];
/** Deliberate share intent, never inferred for ordinary sent text or old receipts. */
export declare function sharedSessionTags(content: string, ids: readonly string[]): string[][];
/** Explicit shares and historical visible session cards, intersected with current text. */
export declare function sharedSessionIds(event: EventData, content?: string): string[];
