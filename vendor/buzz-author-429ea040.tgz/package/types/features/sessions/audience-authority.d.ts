/** Capability identity comes from this connection's NIP-11, never an event author. */
export declare function audienceAuthorityCommunity(value: unknown): string | undefined;
export declare function audienceAuthorityFilter(destination: string, sources: readonly string[]): {
    kinds: number[];
    consistency: string;
    audience_authority: {
        version: number;
        destination: string;
        sources: string[];
    };
}[];
/** An ordinary event-array response cannot attest current membership or visibility. */
export declare function parseAudienceAuthority(raw: unknown, pubkey: string, community: string, destination: string, sources: readonly string[]): ReadonlySet<string>;
