import type { BuzzEvent, Filter } from "../../buzz-mcp/client";
import type { RelaySession } from "../relay/session";
export type SharedSessionCursor = Readonly<{
    until: number;
    before_id: string;
}>;
export type SharedSessionEntry = Readonly<{
    id: string;
    title: string;
    shares: readonly {
        id: string;
        pubkey: string;
        createdAt: number;
    }[];
    sharedAt: number;
}>;
export type SharedSessionPage = Readonly<{
    entries: readonly SharedSessionEntry[];
    cursor?: SharedSessionCursor;
    complete: boolean;
    errors: readonly string[];
    scanned?: number;
}>;
type Reader = {
    pubkey: string;
    query(filters: readonly Filter[]): Promise<readonly Omit<BuzzEvent, "sig">[]>;
    relayAuthor?: string | undefined;
    signingAuthority?: string | undefined;
    authorizeAudience?(destination: string, sources: readonly string[]): Promise<ReadonlySet<string>>;
};
type Options = {
    cursor?: SharedSessionCursor | undefined;
    limit?: number | undefined;
    query?: string | undefined;
    signal?: AbortSignal | undefined;
    /** Set only by the host-bound agent tool, never by a model-selected argument. */
    audience?: string | undefined;
    shareIds?: readonly string[] | undefined;
};
/** One page of confirmed share messages. Merge pages by source ID and share event ID. */
export declare function listSharedSessions(value: Reader | RelaySession, destination: string, options?: Options): Promise<SharedSessionPage>;
/** Read only a surviving shared association, for the host-bound answer audience. */
export declare function readSharedSession(value: Reader, destination: string, sourceId: string, options?: Options): Promise<{
    id: string;
    citation: string;
    messages: {
        id: string;
        author: string;
        createdAt: number;
        content: string;
        truncated?: boolean;
    }[];
    cursor?: {
        until: number;
        before_id: string;
    };
    complete: boolean;
}>;
export {};
