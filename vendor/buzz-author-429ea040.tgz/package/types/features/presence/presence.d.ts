import type { ReadTransport } from "../relay/transport";
import type { LiveSubscription } from "../relay/live";
import type { PresenceActivity } from "./activity";
export type PresenceStatus = "online" | "away" | "offline" | "unknown";
/** Volatile session-owned evidence. No event retention or outbox. */
export declare function createPresence(transport: ReadTransport | null, activity: PresenceActivity | undefined, publish: NonNullable<LiveSubscription["publishPresence"]>, notify: (listener: () => void) => void): {
    status(key: string): PresenceStatus;
    limited: (key: string) => boolean;
    subscribe(key: string, listener: () => void, profile?: boolean): () => void;
    connected(value: boolean): void;
    clear: (publication?: boolean) => void;
    refresh: () => void;
    dispose(): void;
};
export type Presence = ReturnType<typeof createPresence>;
