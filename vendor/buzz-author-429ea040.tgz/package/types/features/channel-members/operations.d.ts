import type { MemberAdditionIntent } from "./members";
import type { LocalEvents } from "../relay/outbox";
/** Session-owned continuation and recovery; closing a view never cancels intent. */
export declare function createMemberAdditions(signal: AbortSignal, add: (channelId: string, pubkey: string, intent: MemberAdditionIntent) => Promise<void>, receipts?: LocalEvents): Readonly<{
    snapshot: () => readonly Readonly<{
        channelId: string;
        pubkey: string;
        pending: boolean;
        confirmed: boolean;
        error?: string;
    }>[];
    subscribe(listener: () => void): () => void;
    add(channelId: string, pubkey: string): Promise<void>;
}>;
/** Only observed failed receipts can become explicit dismissals. Missing accepted
 * or unknown evidence must never authorize a replacement membership write. */
export declare function trackMemberAdditionReceipts(receipts: LocalEvents | undefined, intents: () => Iterable<MemberAdditionIntent>): (() => void) | undefined;
