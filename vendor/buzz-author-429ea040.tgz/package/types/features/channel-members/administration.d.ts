import type { RelayReader } from "../relay/reader";
import type { RelayWriter } from "../relay/transport";
import { type RelayEvent } from "../relay/events";
import { type MemberAuthority, type MemberChange } from "./administration-protocol";
export type MemberAdministrationState = Readonly<{
    status: "idle" | "loading" | "ready" | "error";
    authority: MemberAuthority;
    operation?: Readonly<{
        change: MemberChange;
        status: "pending" | "uncertain" | "confirmed" | "failed";
    }>;
    error?: string | undefined;
}>;
/** Session-owned intent survives dialog closure, never replays privileged writes. */
export declare function createMemberAdministration({ reader, writer, viewer, relayAuthor, canAccess, acceptDiscovery, }: {
    reader?: RelayReader | undefined;
    writer?: RelayWriter | undefined;
    viewer: string;
    relayAuthor: string;
    canAccess(id: string): boolean;
    acceptDiscovery(events: readonly RelayEvent[]): void;
}): {
    capability: Readonly<{
        available: boolean;
        snapshot: (id: string) => Readonly<{
            status: "idle" | "loading" | "ready" | "error";
            authority: MemberAuthority;
            operation?: Readonly<{
                change: MemberChange;
                status: "pending" | "uncertain" | "confirmed" | "failed";
            }>;
            error?: string | undefined;
        }>;
        subscribe(listener: () => void): () => void;
        refresh(id: string): Promise<void>;
        run(id: string, intent: MemberChange): Promise<void>;
    }>;
    clear: () => void;
    dispose(): void;
};
