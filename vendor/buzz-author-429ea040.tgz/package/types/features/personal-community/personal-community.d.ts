export declare const personalCommunityOrigin: () => string;
/** The community signs `wss://` but listens plain on loopback. Only its exact origin is dialled as `ws://`. */
export declare function personalCommunitySocket(origin: string, community?: string): ((url: string) => WebSocket) | undefined;
