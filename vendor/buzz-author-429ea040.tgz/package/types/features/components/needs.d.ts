/** Which engine the person picked in the model chip. */
export type EngineChoice = "claude" | "local";
/** The plugin id grammar in `crates/plugin-manager/src/lib.rs` (`valid_id`). */
export declare function validPluginId(id: string): boolean;
/** A need this build can name; `pack:` must carry a real plugin id. */
export declare function knownNeed(need: string): boolean;
/** The needs this build cannot understand, in declaration order. */
export declare function unknownNeeds(needs: readonly string[] | undefined): string[];
/**
 * Maps a plugin's needs to component ids. `"ai"` is the engine the person
 * picked in the model chip; unknown values are left to `unknownNeeds`, which
 * the catalog reports as needing a newer Wabifi.
 */
export declare function resolveNeeds(needs: readonly string[] | undefined, engine: EngineChoice): string[];
/**
 * The engine a saved chip choice runs. This reads the same harness fields the
 * chip writes (`modelChoice` in `bundled/plugin-studio/models.ts`); it is not
 * a second store.
 */
export declare function engineChoice(harness: Readonly<{
    model: string;
    provider: string;
}>, command?: string): EngineChoice;
