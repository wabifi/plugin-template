import { type ChannelDetailsDraft } from "../relay/channel-details-protocol";
import type { ChannelSummary } from "../relay/contracts";
import type { RelaySession } from "../relay/session";
import type { OutgoingEvent } from "../relay/outbox";
import type { MemberAdditionIntent } from "../channel-members/members";
/** Sharing changes access, never presentation or Solo placement. */
export declare function canShareConversation(session: RelaySession, channel?: ChannelSummary): boolean;
export declare const soloChatLink: (id: string) => string;
export declare const soloChatLinkMessage: (id: string, name?: string) => string;
/** Outbox can finish a delivered link even after its in-process share was reset. */
export declare function isSoloChatLinkReceipt(item: OutgoingEvent): boolean;
/** Exact selected people are grants to the chat, not the destination or its parent. */
export declare function grantSoloChatAccess(session: RelaySession, channelId: string, people: readonly string[], intents: Map<string, MemberAdditionIntent>, signal: AbortSignal, onConfirmed: (key: string) => void, includeAgents?: boolean, soloParticipant?: boolean): Promise<void>;
/** Capture validated destination keys, including oversized rosters. The share
 * attempt freezes them before its combined 100-recipient admission check, so a
 * retry cannot adopt a smaller or changed audience without explicit Start over. */
export declare function destinationShareAudience(session: RelaySession, destinationId: string, signal: AbortSignal): Promise<string[]>;
/** Recheck the exact destination after grants: confirmed additions do not imply
 * the viewer can still post to another channel. The Outbox owns actual delivery. */
export declare function publishSoloChatLink(session: RelaySession, sourceId: string, destinationId: string, previousId: string | undefined, signal: AbortSignal, onQueued: (id: string) => void): Promise<string>;
/** Promote in place through the existing signed details owner. A retry checks an
 * uncertain save; it never republishes it or resets an unchanged cleanup deadline. */
export declare function applySharedChannelDetails(session: RelaySession, id: string, draft: ChannelDetailsDraft, expected: ChannelDetailsDraft, signal: AbortSignal): Promise<void>;
