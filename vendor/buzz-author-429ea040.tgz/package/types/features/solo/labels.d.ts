/** Presentation provenance in the relay's existing NIP-CL labels, never access. */
export declare const SOLO_NAMED_LABEL = "buzz.session.named";
/** NIP-CL label marking a Solo chat: a private channel whose owner talks with
 * their agents at top level. Every member and agent reads it from channel
 * metadata. Presentation and composition only; membership stays the access
 * authority. Conversion to a channel clears it. */
export declare const SOLO_LABEL = "buzz.solo";
export declare function soloLabels(labels: readonly string[] | undefined): boolean;
/** The viewer's own Solo chat: one they created. Anyone else in a shared
 * Solo chat sees its flat treatment, but files and composes as in Team. */
export declare function ownSolo(channel: Readonly<{
    channelType?: string | undefined;
    creator?: string | undefined;
}> | undefined, viewer: string | undefined): boolean;
export declare function soloChatLinkName(channel: {
    id: string;
    name: string;
    labels?: readonly string[] | undefined;
}): string;
