import type { AgentLibrarySnapshot } from "../agents/library";
import type { ChannelSummary, Profile } from "../relay/contracts";
/** Classification never grants access: candidates must be in the current relay roster. */
export declare function soloAgents(channel: ChannelSummary | undefined, profiles: ReadonlyMap<string, Profile>, library: AgentLibrarySnapshot & {
    complete?: boolean;
}, viewer: string | undefined): readonly string[] | undefined;
export declare function soloRecipients(channel: ChannelSummary | undefined, profiles: ReadonlyMap<string, Profile>, library: AgentLibrarySnapshot & {
    complete?: boolean;
}, viewer: string | undefined, explicit: readonly string[]): readonly string[];
