import type { KitEntry, Lineup, Template } from "../channel-templates/model";
import type { RelaySession } from "../relay/session";
export type Workspace = {
    folders: string[];
    worktree?: {
        location: string;
        baseBranch: string;
    } | undefined;
    canvas: string;
};
export declare const emptyWorkspace: () => Workspace;
export declare function validateWorkspace(value: Workspace): Workspace;
/** Workspace preferences remain ordinary Canvas instructions, as in the reference workflow. */
export declare function workspaceCanvas(input: Workspace): string;
export declare function readWorkspace(content: string): Workspace;
/** The folders a Canvas's workspace block lets an agent work in: its project
 * folders, then its worktree location. Unlike `readWorkspace`, hand edits to
 * the block's instructions are kept, so an agent still finds its folders; a
 * missing or malformed block names none. */
export declare function workspaceDirectories(content: string): string[];
/** One existing encrypted template record per project. */
export declare function projectTemplateId(projectId: string): Promise<string>;
/** The defaults record new chats in a project copy; validated for publication. */
export declare function projectTemplate(scope: string, id: string, projectName: string, lineup: Lineup): Template;
export declare function templateEntry(entries: readonly KitEntry[], id: string): KitEntry | undefined;
export declare function projectDefault(entries: readonly KitEntry[], projectId: string, overrideId: string, requireDefault?: boolean): Template | undefined;
export type ChatSetup = {
    projectId?: string;
    canvas: string;
    agents: string[];
};
export declare function parseChatSetup(raw: unknown): ChatSetup;
/** Which saved defaults a setup was read from: it changes whenever any
 * saved kit record does. */
export declare function defaultsRevision(kit: {
    entries: readonly KitEntry[];
}): string;
export declare function loadChatSetup(session: RelaySession, projectId: string): Promise<ChatSetup & {
    revision: string;
}>;
