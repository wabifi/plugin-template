import { type MentionDraft } from "../messages/mention-draft";
/** Remove only structured leading recipient tags; literal @ text remains title content. */
export declare function startingChatTitle(value: MentionDraft | string): string;
