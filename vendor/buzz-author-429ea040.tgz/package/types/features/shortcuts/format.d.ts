import type { KeyBinding } from "./bindings";
/** The dispatcher's platform test: `mod` is Command here and Control elsewhere. */
export declare const isApplePlatform: (platform: string) => boolean;
export type FormattedBinding = Readonly<{
    /** One entry per key chip, e.g. ["⇧", "⌘", "K"] or ["Ctrl", "Shift", "K"]. */
    parts: readonly string[];
    /** Compact display text, e.g. "⇧⌘K" or "Ctrl+Shift+K". */
    text: string;
    /** Plain words for assistive technology, e.g. "Shift Command K". */
    label: string;
}>;
/** One formatter for every chord in the UI, so hints cannot drift from the dispatcher. */
export declare function formatBinding(binding: KeyBinding, apple: boolean): FormattedBinding;
