export type BackupChoice = Readonly<{
    available: boolean;
    pubkey: string;
    automatic: boolean | null;
}>;
export type IdentitySnapshot = {
    status: "loading";
} | {
    status: "missing";
    busy: boolean;
    error?: string;
    recovery?: RecoveryState;
} | {
    status: "error";
    error: string;
} | {
    status: "ready";
    viewer: string;
};
export type RecoveryResult = {
    candidates: {
        handle: string;
        pubkey: string;
    }[];
    currentPubkey: string | null;
    failedCount: number;
};
export type RecoveryState = {
    status: "waiting";
} | {
    status: "saving";
} | {
    status: "canceling";
} | ({
    status: "choosing";
} & RecoveryResult) | {
    status: "error";
    error: string;
};
export declare function createIdentity(): {
    ready: Promise<string>;
    snapshot: () => IdentitySnapshot;
    subscribe(listener: () => void): () => void;
    retry: () => Promise<void>;
    importKey: (nsec: string) => Promise<void>;
    create: () => Promise<void>;
    /** Whether installed old Buzz left data here; never opens secure storage. */
    legacyAvailable: () => Promise<boolean>;
    /** Reads old Buzz's saved key only now, so any OS prompt follows this click. */
    importLegacy: () => Promise<void>;
    backupAvailable: () => Promise<boolean>;
    beginRecovery: () => Promise<void>;
    installRecovery: (handle: string) => Promise<void>;
    cancelRecovery: () => Promise<boolean>;
    /** Fork: the host shows or copies the key; only whether it did comes back. */
    exportKey: (copy: boolean) => Promise<boolean>;
    /** Public consent only; enabling it wakes the configured native uploader after sign-in. */
    getBackupChoice: () => Promise<Readonly<{
        available: boolean;
        pubkey: string;
        automatic: boolean | null;
    }>>;
    /** Pass the key returned by getBackupChoice so a stale selection cannot affect another key. */
    setBackupChoice: (pubkey: string, automatic: boolean) => Promise<Readonly<{
        available: boolean;
        pubkey: string;
        automatic: boolean | null;
    }>>;
    /** Why this build can't wipe, if it can't; `sign_out` enforces it either way. */
    wipeRefusal: () => Promise<string | null>;
    /** Fork: asks natively first; `false` means the member cancelled there. Else
     *  stops agents and restarts; the key (and data, with wipe) goes on next launch. */
    signOut: (choices: {
        wipe: boolean;
        removeAgents: boolean;
    }) => Promise<boolean>;
    dispose(): void;
};
export type Identity = ReturnType<typeof createIdentity>;
export declare const nativeIdentityEnabled: () => boolean;
