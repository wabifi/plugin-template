import type { EventData } from "../relay/events";
export type PluginOwner = Readonly<{
    id: string;
    name: string;
}>;
/** Whether Agents may run this agent now. */
export declare function agentAdmitted(pubkey: string): boolean;
/** Replaces the agents the phone stopped, as native's ledger holds them. */
export declare function setPhoneStopped(next: Iterable<string>): void;
/** Every agent admission refuses that it knows of: stopped from the phone, or a plugin's
 * agent asleep or paused. Native reads these as stopped. */
export declare function refusedAgents(): string[];
export declare function subscribeAgentAdmission(listener: () => void): () => void;
export declare function ownerOf(pubkey: string): PluginOwner | undefined;
export declare function ownedBy(pluginId: string): readonly string[];
export declare function isAwake(pubkey: string): boolean;
/** Replaces the known owners, as the native ledger lists them. */
export declare function setPluginOwners(next: ReadonlyMap<string, PluginOwner>): void;
export declare function recordOwner(pubkey: string, owner: PluginOwner): void;
export declare function setRunnable(next: (pluginId: string) => boolean): void;
/** Re-reads `runnable`, after the plugins it reads changed. */
export declare function runnableChanged(): void;
export declare function wake(pubkey: string, now?: number): void;
/** When the agent last woke, so idle sleep gives a woken agent its full grace. */
export declare function wokenAt(pubkey: string): number | undefined;
/** Wakes each sleeping agent of a runnable plugin that a conversation event
 * names. Agents' live dispatch, which runs right after, then reaches the woken
 * agent's new runner with the same events, so the mention is answered. */
export declare function wakeAddressed(events: readonly EventData[]): void;
export declare function sleep(pubkey: string): void;
/** Test seam: forget every owner and wake. */
export declare function resetAdmission(): void;
