import type { Agents } from "../agents/service";
import { isAwake, type PluginOwner } from "./admission";
export type { PluginOwner };
export type AgentAction = "start" | "stop" | "restart" | "sleep";
export type SessionPolicy = "channel" | "thread";
export type AgentView = Readonly<{
    id: string;
    pubkey: string;
    relayUrl: string;
    name: string;
    picture?: string | null;
    systemPrompt: string;
    sessionPolicy: SessionPolicy | null;
    workspace: string;
    harness: Readonly<{
        command: string;
        args: string[];
        model: string;
        provider: string;
        environmentKeys: string[];
    }>;
    revision: number;
    runningRevision: number | null;
    enabled: boolean;
    /** This projection reports only running and stopped; the rest are kept for
     * plugins written against the earlier runtime. */
    status: "stopped" | "waiting" | "starting" | "running" | "stopping" | "failed";
    error: string | null;
    startOnAppLaunch: boolean;
    profilePending: boolean;
    configured: boolean;
    pluginOwner: PluginOwner | null;
}>;
export type AgentEdit = Readonly<{
    name: string;
    picture?: string;
    systemPrompt: string;
    sessionPolicy: SessionPolicy | null;
    workspace: string;
    harness: Readonly<{
        command: string;
        args: string[];
        model: string;
        provider: string;
    }>;
    /** Upstream's agents take no per-agent environment; a value here is refused. */
    environment: Readonly<Record<string, string | null>>;
}>;
export type HarnessOption = Readonly<{
    command: string;
    label: string;
    status: "ready" | "cli-needed";
    installSupported: boolean;
    defaultArgs: string[];
    providers: readonly {
        value: string;
        label: string;
    }[];
}>;
export type ControlSnapshot = Readonly<{
    agents: readonly AgentView[];
    runtimeAvailable: boolean;
    harnessOptions: readonly HarnessOption[];
    createAvailable: boolean;
    defaultWorkspace: string;
    /** Claude on this computer, as upstream's Claude plugin reports it. */
    claudeSetup: Readonly<{
        status: "ready" | "cli-needed";
        installSupported: boolean;
        loginCommand: string | null;
    }>;
}>;
export type AgentControlState = Readonly<{
    status: "idle" | "loading" | "ready" | "error" | "unavailable";
    data: ControlSnapshot | null;
    busy: boolean;
    error: string | null;
}>;
export type HarnessInstallReport = Readonly<{
    ready: boolean;
    error?: string;
}>;
export type AgentControl = Readonly<{
    /** The same projection, whose create records this plugin as the owner. */
    forPlugin(owner: PluginOwner): AgentControl;
    snapshot(): AgentControlState;
    subscribe(listener: () => void): () => void;
    refresh(): Promise<void>;
    /** Waits, bounded, until the agent list is loaded; false when it did not load in time. */
    whenReady(): Promise<boolean>;
    /** A plugin may pass its `session.scope` as `destination`. Its failures are plain words. */
    create(requestId: string, destination: string, owner: string, edit: AgentEdit): Promise<AgentView>;
    save(id: string, revision: number, edit: AgentEdit): Promise<ControlSnapshot>;
    /** `since`, a replay floor in the earlier runtime, is not needed: a woken
     * agent's catch-up answers what it missed. */
    action(id: string, action: AgentAction, since?: number): Promise<ControlSnapshot>;
    delete(id: string): Promise<ControlSnapshot>;
    /** Upstream's agents have no launch preference: a plugin's agent never
     * starts with the app, every other agent always does. Kept as a no-op. */
    setStartOnAppLaunch(id: string, enabled: boolean): Promise<ControlSnapshot>;
    /** Upstream's Agents publishes profiles itself. Kept as a no-op. */
    publishProfile(id: string): Promise<ControlSnapshot>;
    installClaude(): Promise<HarnessInstallReport>;
    checkClaudeAuth(): Promise<boolean | null>;
    /** Deletes the plugin's agents through Agents, which leaves and archives them. */
    removeOwned(pluginId: string): Promise<readonly string[]>;
    /** The same Delete for saved agents whose plugin is already gone. */
    removeAgents(pubkeys: readonly string[]): Promise<readonly string[]>;
}>;
export declare const CLAUDE_COMMAND = "claude-agent-acp";
export declare const GOOSE_COMMAND = "goose";
type Config = Readonly<{
    model?: string;
    provider?: string;
    instructions?: string;
    workspace?: string;
    scope?: SessionPolicy;
}>;
type Listed = Readonly<{
    id: string;
    name: string;
    agentType: string;
    relay: string;
    pluginId: string | null;
    pluginName: string | null;
    /** Where the host runs this plugin agent, inside its plugin's data. */
    workspace: string | null;
}>;
type Native = Readonly<{
    list(): Promise<readonly Listed[]>;
    record(pubkey: string, owner: PluginOwner): Promise<string | null>;
}>;
/** Which upstream type an edit's harness names; undefined for one with no
 * upstream equivalent. */
export declare function typeFor(harness: AgentEdit["harness"]): string | undefined;
export declare function configFor(edit: AgentEdit, type: string, workspace?: string): Config;
export declare function createPluginAgentControl({ agents, selectedOrigin, native, }: {
    agents: Agents;
    /** The selected community's origin, where Agents creates agents. */
    selectedOrigin: () => string | undefined;
    native?: Native;
}): AgentControl;
export { isAwake };
declare module "@deepseek-ai/cordis" {
    interface Context {
        agentControl: AgentControl;
    }
}
