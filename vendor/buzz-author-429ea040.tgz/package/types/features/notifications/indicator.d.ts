export type IndicatorPermission = "default" | "setup" | "enabled" | "disabled" | "denied" | "unavailable";
export interface IndicatorPlatform {
    permission(request: boolean): Promise<IndicatorPermission>;
    set(unread: boolean): Promise<void>;
}
export declare function indicatorPlatform(): IndicatorPlatform | undefined;
/** One ordered native projection. Pending work always converges on current intent. */
export declare function createUnreadIndicator(platform?: IndicatorPlatform | undefined, host?: Pick<Window, "addEventListener" | "removeEventListener"> | undefined): {
    available: boolean;
    snapshot: () => Readonly<{
        permission: IndicatorPermission;
        requesting: boolean;
        error: string | null;
    }>;
    subscribe(listener: () => void): () => void;
    refresh: () => Promise<void>;
    request: () => Promise<void>;
    setUnread(value: boolean): void;
    dispose(): Promise<void>;
};
export type UnreadIndicator = ReturnType<typeof createUnreadIndicator>;
