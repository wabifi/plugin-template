import type { ChannelSummary, Profile } from "../relay/contracts";
import type { IncomingMessage } from "../relay/incoming";
import type { NotificationCategory } from "./preferences";
export type NotificationText = Readonly<{
    title: string;
    body: string;
}>;
/** Flattened, bounded prose; empty when nothing displayable remains. */
export declare function plainText(content: string): string;
/** Bounded CommonMark text, not rendered HTML or a fetch of linked/attached content.
 * Lists re-render every row's preview on each update, and parsing Markdown is
 * the cost of each, so short sources are remembered. The map is bounded; a full
 * map restarts empty. */
export declare function messagePreview(content: string): string;
/** Plugin text gets the same flattening and bounds; missing text keeps the category fallback. */
export declare function pluginNotificationText(input: Readonly<{
    title?: string;
    body?: string;
}>, label: string): NotificationText;
/** Names are optional cached enrichment; notifications never wait for profile reads. */
export declare function messageNotificationText(message: IncomingMessage, category: NotificationCategory, channel: ChannelSummary | undefined, profile: Profile | undefined, resolvedName?: string | undefined): NotificationText;
