export type NotificationPermissionState = NotificationPermission | "unsupported" | "unknown";
export type NotificationPresentation = Readonly<{
    id: string;
    title: string;
    body: string;
}>;
export interface NotificationPlatform {
    readonly label: string;
    readonly systemManaged?: boolean;
    permission(): Promise<NotificationPermissionState>;
    requestPermission(): Promise<NotificationPermissionState>;
    show(item: NotificationPresentation, activate: () => void, failed: (error: Error) => void): Promise<void>;
    dispose(): void;
}
/** One native presentation owner, with its callback registered before sending. */
export declare function createNotifications(): NotificationPlatform;
/** Running-tab alerts. Native delivery never falls back to a WebView API. */
export declare function createBrowserNotifications(host?: Window | undefined): NotificationPlatform;
