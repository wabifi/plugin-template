import type { NamingIdentity } from "./policy";
import type { RelaySession } from "../relay/session";
import type { IdentityNameView } from "./service";
/** The interface arrives through the captured session, never a global lookup. */
export declare function useIdentityNames(names: IdentityNameView | undefined): (pubkey: string, fallback: string, candidates?: readonly string[], displayFacts?: readonly NamingIdentity[]) => string;
/** Channel membership defines ambiguity, not the community-wide profile cache. */
export declare function useChannelIdentityNames(session: {
    names?: IdentityNameView | undefined;
    channels: Pick<RelaySession["channels"], "list" | "subscribeList">;
} | undefined, channelId: string | undefined): (pubkey: string, fallback: string) => string;
