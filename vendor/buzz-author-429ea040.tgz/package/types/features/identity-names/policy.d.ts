export type NamingIdentity = {
    pubkey: string;
    name: string;
    isAgent?: boolean;
    ownerPubkey?: string;
};
/** Display policy only. Neither a readable owner nor a key suffix grants authority. */
export declare function resolveIdentityNames(identities: readonly NamingIdentity[], viewer?: string, candidates?: readonly string[]): Map<string, {
    name: string;
    qualifier: string | undefined;
}>;
