/** How well a label matches typed text: exact, then prefix, then word start,
 * then any substring, then a fuzzy match whose letters each continue a run
 * that began at a word start ("bgp" in "buzz-github-prs"), then any fuzzy
 * match (the letters appear in order). Lower is better; undefined means no
 * match. Ranks are whole numbers, so callers can add fractional tie-breaks.
 * `positions` are the matched code points of the label, for underlining. */
export declare function matchName(label: string, needle: string): {
    rank: number;
    positions: number[];
} | undefined;
export declare const matchRank: (label: string, needle: string) => number | undefined;
