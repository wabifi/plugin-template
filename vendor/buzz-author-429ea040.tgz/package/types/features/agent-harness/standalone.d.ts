/** How long a standalone turn (`AgentType.runOnce`) may run before its
 * harness stops it: Janet's turn deadline. */
export declare const STANDALONE_DEADLINE_MS: number;
