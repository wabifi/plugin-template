import type { AgentHandle, Trigger, TurnResult } from "../agents/service";
export type WakeTrigger = Exclude<Trigger, {
    type: "mention";
}>;
/** Runs one standalone turn, `key` naming it (`watch/ID`, `catch-up/ID` or
 * `timer/ID`). It calls `prompt` once it is ready to start the turn, and
 * starts none when it gives undefined: the wake is no longer wanted. */
export type RunOnce = (key: string, prompt: () => Promise<string | undefined>) => Promise<TurnResult>;
/** Runs `trigger` with `runOnce`, in the lane the runner holds for it.
 * Settles when its turn ends, or at once when it no longer runs. The host
 * says whether it is still `current`, asked as it starts and again while its
 * prompt is built: a wake whose watch or timer was disabled or removed, whose
 * watch changed or no longer matches, or whose agent's attention went off,
 * while it waited does not run. `harness` names the agent type in logs. */
export declare function wake(agent: AgentHandle, trigger: WakeTrigger, current: () => boolean, runOnce: RunOnce, harness: string): Promise<TurnResult>;
