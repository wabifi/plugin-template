import { type PointerEvent } from "react";
export type DragPane = "main" | "side";
export type TabDragHost = {
    attach(element: HTMLDivElement | null): void;
    begin(event: PointerEvent<HTMLDivElement>): void;
    click(event: React.MouseEvent<HTMLDivElement>): void;
};
/** Title-only Panel Swap gesture. The conversation owner alone commits moves. */
export declare function useTabDrag({ visit, navigationSignal, movable, order, closedSideIndex, canMove, move, }: {
    visit: object;
    /** Navigation owns cancellation even between visits in the same channel. */
    navigationSignal?: AbortSignal | undefined;
    movable: ReadonlySet<string>;
    order: ReadonlySet<string>;
    /** Append an edge drop to the retained side inventory when it is closed. */
    closedSideIndex?: number | undefined;
    canMove(id: string, pane: DragPane): boolean;
    move(id: string, pane: DragPane, index: number): void;
}): {
    main: TabDragHost;
    side: TabDragHost;
    feedback: import("react").JSX.Element;
};
