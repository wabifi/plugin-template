import { type ReactNode } from "react";
/** The divider above a day's first row: "Today", "Monday", "June 20, 2025".
 * `data-day` carries the local calendar day. */
export declare function DayDivider({ createdAt }: {
    createdAt: number;
}): import("react").JSX.Element;
/** The byline includes a day outside today because its divider can scroll away. */
export declare function MessageTimestamp({ createdAt }: {
    createdAt: number;
}): import("react").JSX.Element;
/** Grouped messages keep their date available without an inline clock. */
export declare function MessageTimestampHint({ createdAt, attachments, children, }: {
    createdAt: number | undefined;
    /** Percentage-sized media needs the payload's full width. */
    attachments?: boolean;
    children: ReactNode;
}): import("react").JSX.Element;
