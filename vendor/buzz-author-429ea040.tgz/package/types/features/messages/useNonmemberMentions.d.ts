import type { ComposerSession } from "./composer-session";
import type { MentionRecipient } from "./mention-draft";
/** One consent decision for a captured send. The session owns durable additions. */
export declare function useNonmemberMentions(session: ComposerSession, channelId: string, restoreFocus: () => void): {
    prepare(people: readonly MentionRecipient[], signal: AbortSignal, current: () => boolean): Promise<readonly string[] | null>;
    dialog: import("react").JSX.Element;
};
