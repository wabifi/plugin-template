import { type ReactNode, type RefObject } from "react";
import type { ChannelMessage } from "../relay/contracts";
type EditHandler = (row: ChannelMessage) => void;
type EditScopeValue = {
    current: EditHandler | undefined;
    input: RefObject<HTMLElement | null>;
    focusTarget(): HTMLElement | null;
    exactRows?: (() => readonly ChannelMessage[]) | undefined;
};
/** A timeline and its composer share a target; nested threads/viewers own their scope. */
export declare function MessageEditScope({ children }: {
    children: ReactNode;
}): import("react").JSX.Element;
export declare const useMessageEditScope: () => EditScopeValue | undefined;
export {};
