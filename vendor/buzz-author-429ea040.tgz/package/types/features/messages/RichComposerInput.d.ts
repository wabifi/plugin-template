import type { ConversationExtensions } from "../conversation/contracts";
import type { CustomEmoji } from "../relay/emoji";
import type { ComposerSession } from "./composer-session";
import type { MentionDraft } from "./mention-draft";
import { type EditableInputProps } from "./EditableInput";
/** Decorations never change source text or infer notification recipients from names. */
export declare function RichComposerInput({ draft, session, scope, channelId, extensions, emoji, ...input }: EditableInputProps & {
    draft: MentionDraft;
    session: ComposerSession;
    scope: string;
    channelId: string;
    extensions: ConversationExtensions | undefined;
    emoji: readonly CustomEmoji[];
}): import("react").JSX.Element;
