import type { RelaySession } from "../relay/session";
type Entry = {
    id: string;
    channelId: string;
    text: string;
    recipients: readonly string[];
    publish(): string;
    beforeRelease?(): Promise<void>;
    onSend?(id: string): void;
    error?: string;
};
/** Session-local pending sends survive navigation, like background uploads. */
export declare function followUpQueue(session: RelaySession): {
    snapshot: () => readonly Entry[];
    subscribe(listener: () => void): () => void;
    /** `validated` means the caller checked recipients just now; only a later release revalidates. */
    submit(entry: Omit<Entry, "id">, validated?: boolean): string | undefined;
    sendNow(id: string): void;
    remove(id: string): void;
};
export {};
