import type { RelaySession } from "../relay/session";
import type { ComposerSession } from "./composer-session";
import { emptyReferenceDirectory } from "./ReferenceText";
import type { ConversationExtensions } from "../conversation/contracts";
import type { ChannelMessage, Profile } from "../relay/contracts";
export declare function MessageMarkdown({ row, directory, session, scope, extensions, media, onOpenLink, canOpenLink, participantProfiles, largeEmoji, interactive, staticMentions, }: {
    row: ChannelMessage;
    directory?: typeof emptyReferenceDirectory;
    session?: RelaySession | ComposerSession | undefined;
    scope?: string | undefined;
    extensions?: ConversationExtensions | undefined;
    media(url: string): string | undefined;
    onOpenLink(url: string): boolean;
    canOpenLink?: ((target: string) => boolean) | undefined;
    participantProfiles?: ReadonlyMap<string, Profile> | undefined;
    largeEmoji?: boolean | undefined;
    interactive?: boolean;
    /** Preserve signed mention presentation when this surface cannot open profiles. */
    staticMentions?: boolean | undefined;
}): import("react").JSX.Element;
