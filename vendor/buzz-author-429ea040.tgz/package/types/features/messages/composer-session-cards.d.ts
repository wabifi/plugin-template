import type { MentionDraft } from "./mention-draft";
import type { ReferenceChannel } from "./ReferenceText";
/** Move references out of editable prose without changing recipient identity or marks. */
export declare function stageSessionCards(draft: MentionDraft, channels: readonly ReferenceChannel[]): MentionDraft;
