import type { ComposerSession } from "./composer-session";
/** Desktop's composer upload pill and failure toasts, for this session's sends. */
export declare function BackgroundUploadStatus({ session, focusTarget, }: {
    session: ComposerSession;
    focusTarget: React.RefObject<HTMLElement | null>;
}): import("react").JSX.Element;
