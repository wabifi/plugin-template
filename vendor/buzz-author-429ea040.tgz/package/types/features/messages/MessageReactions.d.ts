import type { ComposerTool, ContributionReader, InlineRenderer } from "../conversation/contracts";
import type { ChannelMessage, Profile } from "../relay/contracts";
import type { RelaySession } from "../relay/session";
type Props = {
    row: ChannelMessage;
    session: RelaySession;
    scope: string;
    disabled: boolean;
    tools: ContributionReader<ComposerTool>;
    inline: ContributionReader<InlineRenderer>;
};
/**
 * Who reacted is the pill's primary answer and people scan several pills in a
 * row, so the first hover opens quickly (as Slack does); once a preview is
 * open, moving along the row switches previews immediately.
 */
export declare const REACTION_PREVIEW_DELAY_MS = 100;
/** PR 1's quick-control slot. The emoji contribution continues to own its picker. */
export declare function MessageReactionControls(props: Props): import("react").JSX.Element;
/** Always mounted under the message so failed add/remove operations stay recoverable. */
export declare function MessageReactions(props: Props & {
    onFocusedRemoval?: () => void;
    profiles?: ReadonlyMap<string, Profile>;
}): import("react").JSX.Element;
export {};
