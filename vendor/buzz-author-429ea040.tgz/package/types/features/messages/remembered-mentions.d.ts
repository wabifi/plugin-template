import type { ComposerSession } from "./composer-session";
import { type MentionDraft } from "./mention-draft";
/** The next scoped draft remembers only exact agents notified by the sent message. */
export declare function rememberedMentions(session: ComposerSession, draft: MentionDraft, notified: readonly string[]): MentionDraft;
