import type { ChannelMessage } from "../relay/contracts";
export declare function continuesMessageGroup(previous: ChannelMessage | undefined, current: ChannelMessage): boolean;
