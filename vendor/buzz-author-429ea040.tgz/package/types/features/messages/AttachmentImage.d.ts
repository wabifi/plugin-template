import type { Attachment } from "../relay/contracts";
import type { RelaySession } from "../relay/session";
export declare function AttachmentImage({ attachment, session, source, cached, onOpenReview, onOpenLink, keepMounted, label, }: {
    label?: string;
    attachment: Attachment;
    session?: RelaySession | undefined;
    source: string | undefined;
    cached?: boolean;
    onOpenReview?: (attachment: Attachment, seconds: number) => void;
    onOpenLink?: ((url: string) => boolean) | undefined;
    /** Pins the owning row in a virtualized list; returns the release. */
    keepMounted?: (() => () => void) | undefined;
}): import("react").JSX.Element;
