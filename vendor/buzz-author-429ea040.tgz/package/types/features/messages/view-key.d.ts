/** Presentation lifetimes reset on retarget/reconnect; persisted intent uses stable scope alone. */
export declare function messageViewKey(session: object, ...identity: (string | undefined)[]): string;
