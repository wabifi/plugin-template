import type { RelaySession } from "../relay/session";
type AsyncResult<F> = F extends (...args: infer A) => infer R ? (...args: A) => R | Promise<R> : never;
/** The editor consumes presentation and explicit chat operations, never a relay transport. */
export type ComposerSession = Pick<RelaySession, "viewer" | "media" | "scope"> & {
    names?: import("../identity-names/service").IdentityNameView | undefined;
    repositories: Pick<RelaySession["repositories"], "home" | "load" | "peekHome">;
    channels: Pick<RelaySession["channels"], "list" | "subscribeList" | "get" | "window" | "ensureList" | "refreshList" | "searchPublic" | "matchPublic"> & Partial<Pick<RelaySession["channels"], "subscribeWindow">>;
    profiles: RelaySession["profiles"];
    emoji: Pick<RelaySession["emoji"], "snapshot" | "subscribe" | "ensure" | "refresh">;
    agentChoices: Pick<RelaySession["agentChoices"], "snapshot" | "subscribe" | "ensure" | "retain" | "refresh">;
    agentLibrary: RelaySession["agentLibrary"];
    archives: Pick<RelaySession["archives"], "snapshot" | "subscribe" | "ensure" | "state" | "refresh">;
    typing: Pick<RelaySession["typing"], "snapshot" | "subscribe"> & Partial<Pick<RelaySession["typing"], "send">>;
    presence?: Pick<NonNullable<RelaySession["presence"]>, "status"> | undefined;
    directMessages: Pick<RelaySession["directMessages"], "people">;
    memberAdditions: Pick<RelaySession["memberAdditions"], "add">;
    channelWrites: Pick<RelaySession["channelWrites"], "refreshMembership" | "addAgents">;
    outbox: Pick<NonNullable<RelaySession["outbox"]>, "supports" | "snapshot" | "subscribe" | "retry"> | undefined;
    attachments: (NonNullable<RelaySession["attachments"]> & {
        /** A detached editor delegates native file preparation to its owning window. */
        prepare?(file: File, signal: AbortSignal): Promise<File>;
        release?(file: import("../relay/attachments").UploadedAttachment): void;
    }) | undefined;
    messages: {
        send: AsyncResult<RelaySession["messages"]["send"]>;
        reply: AsyncResult<RelaySession["messages"]["reply"]>;
        edit: RelaySession["messages"]["edit"];
    };
};
export declare function fullSession(session: RelaySession | ComposerSession | undefined): RelaySession | undefined;
export {};
