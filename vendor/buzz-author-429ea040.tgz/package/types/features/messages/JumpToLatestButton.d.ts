import { type ActivityLane } from "./activity-lane";
export type { ActivityLane } from "./activity-lane";
export declare function JumpToLatestButton({ visible, newMessageCount, onClick, activityLane, }: {
    visible: boolean;
    newMessageCount: number;
    onClick(): void;
    activityLane?: ActivityLane | undefined;
}): import("react").JSX.Element;
