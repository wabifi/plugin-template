import type { ChannelMessage, Profile } from "../relay/contracts";
export type TimelineRow = ChannelMessage & {
    membershipRows?: readonly ChannelMessage[];
};
/** A Solo chat implies the agents its owner started it with; omit the owner's
 * agent additions and removals before the first message once history reaches
 * the chat's start. Later changes, people and agents added by someone else
 * still show. */
export declare function withoutStartingAgents(rows: readonly ChannelMessage[], owner: string | undefined, agents: ReadonlySet<string>, complete: boolean): readonly ChannelMessage[];
/** Newest-anchored groups keep loaded keys stable when history is prepended.
 * Messages, local days and adjacent gaps over one hour always break a group. */
export declare function membershipRows(rows: readonly ChannelMessage[]): readonly TimelineRow[];
/** A prose segment; `id` marks a member name that may open that profile. */
export type MembershipPart = {
    text: string;
    id?: string;
};
export declare function membershipDescription(rows: readonly ChannelMessage[], profiles: ReadonlyMap<string, Profile>, viewer?: string, resolveName?: (id: string, fallback: string) => string): {
    targets: string[];
    parts: MembershipPart[];
    text: string;
    title: string;
};
