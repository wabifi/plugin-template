/** CSS chooses where to clip, so floating menus can escape the media surface. */
export declare function useMediaCorners(): (element: HTMLElement | null) => (() => void) | undefined;
