import type { RefObject } from "react";
/** The existing nearest-pane drop owner also owns its visible affordance. */
export declare function FileDropOverlay({ composer, }: {
    composer: RefObject<HTMLFormElement | null>;
}): import("react").ReactPortal | null;
