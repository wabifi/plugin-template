export declare function supportsImageCopy(): boolean;
export declare function copyImageToClipboard(image: HTMLImageElement, validated?: Promise<void>): Promise<void>;
