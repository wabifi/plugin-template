/** Only user edits call this; there is no heartbeat or deferred retry. */
export declare function useTypingBroadcast(send: ((channelId: string, rootId: string | undefined, signal: AbortSignal) => Promise<void>) | undefined, channelId: string, threadRootId: string | undefined, enabled: boolean): () => void;
