import { type RefObject } from "react";
/** Defer untouched desktop controls, then preserve their state for the row's life. */
export declare function useMessageActionBarReady(rowRef: RefObject<HTMLDivElement | null> | undefined): boolean;
/** Keep the controls in DOM/tab order while painting outside list containment. */
export declare function useFloatingActionBar(rowRef: RefObject<HTMLDivElement | null> | undefined, barRef: RefObject<HTMLDivElement | null>, slotRef: RefObject<HTMLDivElement | null>, open: boolean): boolean;
