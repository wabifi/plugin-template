import type { AttachmentRenderer, ContributionReader } from "../conversation/contracts";
import type { DraftAttachment } from "./attachment-draft";
export declare function ComposerAttachments({ items, renderers, disabled, remove, retry, media, onExitComplete, }: {
    renderers?: ContributionReader<AttachmentRenderer> | undefined;
    media(url: string): string | undefined;
    items: readonly DraftAttachment[];
    disabled: boolean;
    remove(id: string): void;
    retry(id: string): void;
    /** The section finished animating out after the last item was removed. */
    onExitComplete?: (() => void) | undefined;
}): import("react").JSX.Element;
