import type { RelaySession } from "../relay/session";
export declare function QueuedFollowUps({ session, channelId, disabled, focusComposer, }: {
    session: RelaySession;
    channelId: string;
    disabled: boolean;
    focusComposer(): void;
}): import("react").JSX.Element | null;
