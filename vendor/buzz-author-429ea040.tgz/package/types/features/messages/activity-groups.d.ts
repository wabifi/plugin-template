import type { ChannelMessage } from "../relay/contracts";
export declare const RECENT_ACTIVITY_COUNT = 5;
export type ActivityGroup = {
    ids: string[];
};
/** Only consecutive agent-only messages on one local day fold together.
 * Human messages, public agent replies and membership notices stay visible. */
export declare function activityGroups(rows: readonly ChannelMessage[]): ActivityGroup[];
