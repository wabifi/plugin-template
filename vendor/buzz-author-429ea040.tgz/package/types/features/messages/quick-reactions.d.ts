import { type CustomEmoji } from "../relay/emoji";
export declare function quickReactions(scope: string, catalog: readonly CustomEmoji[]): string[];
export declare function recordReaction(scope: string, emoji: string): void;
/** Forgets one community's shortcut history once the viewer has left it. */
export declare function forgetQuickReactions(scope: string): void;
/** Freeze shortcuts during use; reload or another window's update refreshes them. */
export declare function useQuickReactions(scope: string, catalog: readonly CustomEmoji[]): string[];
