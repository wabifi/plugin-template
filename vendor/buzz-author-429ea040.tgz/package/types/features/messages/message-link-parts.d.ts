type LinkPart = {
    text: string;
    url?: string;
    label?: string;
};
/** Display-only link syntax. Message storage and navigation keep the original destination. */
export declare function messageLinkParts(content: string, onLabeledLink?: (start: number, end: number, label: string, url: string) => void, onLink?: (start: number, end: number, url: string) => void): LinkPart[];
/** Repair pasted escaped/nested wrappers before Markdown, except in literal contexts. */
export declare function normalizeWrappedLinks(content: string, isLiteral: (start: number, end: number) => boolean): string;
export {};
