export type LiteralRange = Readonly<{
    start: number;
    end: number;
}>;
export type PreparedMarkdown = Readonly<{
    kind: "plain";
    content: string;
}> | Readonly<{
    kind: "markdown";
    content: string;
    literalRanges: readonly LiteralRange[];
    spoilerDelimiters: readonly number[];
}>;
export declare const isLiteralMarkdownContext: (type: string) => boolean;
/** Pure, immutable Markdown work whose lifetime is owned by the mounted body. */
export declare function prepareMarkdown(content: string): PreparedMarkdown;
