import { type ReactNode } from "react";
/** Replies expand once and remain readable lists, not a collapsible tree widget. */
export declare function ReplyBranch({ message, layout, summary, label, hasReplies, open, depth, onExpand, children, }: {
    message: ReactNode;
    layout: "thread" | "continuation";
    summary: ReactNode;
    label: string;
    hasReplies: boolean;
    open: boolean;
    depth: number;
    onExpand(): void;
    children: ReactNode;
}): import("react").JSX.Element;
