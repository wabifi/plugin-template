import type { RelaySession } from "../relay/session";
import type { ComposerSession } from "./composer-session";
import type { MessageLinkOrigin } from "./MessageRow";
/** Floating conversation activity over existing stores; no reads or capture. */
export declare function TypingIndicator({ session, channelId, threadRootId, canOpenActivity, clickOpensPanel, openActivity, }: {
    clickOpensPanel?: boolean | undefined;
    session: ComposerSession & Partial<Pick<RelaySession, "agentActivity">>;
    channelId: string;
    threadRootId?: string | undefined;
    canOpenActivity?: ((target: string) => boolean) | undefined;
    openActivity?: ((target: string, origin?: MessageLinkOrigin) => boolean) | undefined;
}): import("react").JSX.Element;
