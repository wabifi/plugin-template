/** Desktop Mac WebKit: Safari and Tauri's WKWebView. Desktop-mode iPad also
 * reports MacIntel, but keeps its touch policies. */
export declare const macWebKit: () => boolean;
