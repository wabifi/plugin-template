import type { ReactNode } from "react";
import type { Profile } from "../relay/contracts";
/** Shared summary contents for channel threads and collapsed reply branches. */
export declare function ReplySummary({ count, participants, profiles, agentPubkeys, resolveName, media, unreadLabel, unreadCount, workingParticipants, activity, hideEmptyLabel, }: {
    workingParticipants?: readonly string[];
    activity?: ReactNode;
    /** Activity-only triggers already have an accessible thread action label. */
    hideEmptyLabel?: boolean;
    count: number;
    participants: readonly string[];
    profiles?: ReadonlyMap<string, Profile> | undefined;
    agentPubkeys?: ReadonlySet<string> | undefined;
    resolveName(id: string, fallback: string): string;
    media(url: string, size?: "small"): string | undefined;
    unreadLabel?: string | undefined;
    unreadCount?: number;
}): import("react").JSX.Element;
