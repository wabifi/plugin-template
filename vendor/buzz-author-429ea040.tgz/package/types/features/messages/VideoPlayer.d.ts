import { type ReactNode, type RefObject } from "react";
export type VideoMarker = {
    id: string;
    seconds: number;
    label: string;
    author: string;
    picture?: string | undefined;
    text: string;
};
export declare function videoTime(seconds: number): string;
/** The same controls serve chat previews and review; the caller owns the video. */
export declare function VideoControls({ videoRef, inline, markers, onMarker, }: {
    videoRef: RefObject<HTMLVideoElement | null>;
    inline?: boolean;
    markers?: readonly VideoMarker[];
    onMarker?(id: string, seconds: number): void;
}): import("react").JSX.Element;
export declare function VideoPlayer({ source, poster, videoRef, initialTime, onTime, onError, markers, onMarker, children, }: {
    source: string;
    poster?: string | undefined;
    videoRef: RefObject<HTMLVideoElement | null>;
    initialTime?: number;
    onTime(seconds: number): void;
    onError(): void;
    markers?: readonly VideoMarker[];
    onMarker?(id: string, seconds: number): void;
    children?: ReactNode;
}): import("react").JSX.Element;
