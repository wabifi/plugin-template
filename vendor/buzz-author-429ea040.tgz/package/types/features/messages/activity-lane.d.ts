import type { ComposerSession } from "./composer-session";
/** The conversation whose composer, a following sibling of this history, shows activity. */
export type ActivityLane = Readonly<{
    session: ComposerSession;
    channelId: string;
    threadRootId?: string | undefined;
}>;
/** Publish, while `shown`, that this conversation's composer shows working agents. */
export declare function useActivityLanePublisher(session: ComposerSession, channelId: string, threadRootId: string | undefined, shown: boolean): void;
/** Whether a mounted composer shows working agents in the lane's conversation. */
export declare function useActivityLaneShown(target: ActivityLane | undefined): boolean;
