/** Composer-local candidates before a channel exists; delivery still validates membership. */
export declare const DraftMentionRoster: import("react").Context<readonly Readonly<{
    pubkey: string;
    name: string;
}>[] | undefined>;
