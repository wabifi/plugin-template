type Range = {
    start: number;
    end: number;
};
export type PlainLink = Range;
export type ComposerEdit = Range & {
    text: string;
};
/** Keep partially deleted links plain while shifting their ranges with other draft edits. */
export declare function updatePlainLinks(previous: string, text: string, links: readonly Range[], plain: readonly PlainLink[], edit?: ComposerEdit): PlainLink[];
export {};
