import type { ComposerSession } from "./composer-session";
/** Observe existing archive evidence; only an open chooser demands its lazy read. */
export declare function useMentionArchives(session: ComposerSession, demand?: boolean): Readonly<{
    status: "unavailable" | "idle" | "loading" | "ready" | "error";
    archived: readonly string[];
    eventId?: string;
    createdAt?: number;
    readAt?: number;
    error?: string;
}>;
