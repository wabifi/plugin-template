/** `text` reads well outside the app; `markdown` keeps identity locators and
 * the block syntax the composer understands; `html` is the semantic `text/html`
 * flavor. */
export type CopyFormat = "text" | "markdown" | "html";
/** Serialize every range of a live selection; ranges join like lines. */
export declare function serializeSelection(selection: Selection, format: CopyFormat): string;
/** Walk a DOM tree, clipped to `range` when given. The DOM is untrusted data:
 * identity travels only on validated `nostr:`, `buzz:` and credential-free
 * `http:` and `https:` destinations, and only when a chip's whole text is selected.
 * Unknown elements degrade to their text. */
export declare function serializeNode(node: Node, format: CopyFormat, range?: Range): string;
/** Engines omit computed `user-select: none` chrome from copies; so do we. */
export declare function unselectable(element: Element): boolean;
/** Timeline and thread surfaces share one document listener. */
export declare function useMessageSelectionCopy(): void;
