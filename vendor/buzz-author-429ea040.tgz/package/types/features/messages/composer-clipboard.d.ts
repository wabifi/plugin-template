import { type Node as EditorNode } from "prosemirror-model";
/** The identity locator a whole source is: `[@Name](nostr:npub…)`. */
export declare function identityLink(source: string): {
    pubkey: string;
    name: string;
} | undefined;
/** Both clipboard flavors of a composer document. `text` is the Markdown source
 * as a reader expects it; `html` carries every locator for this app's own paste
 * handler and other rich editors. */
export declare function composerClipboard(doc: EditorNode, document: Document): {
    text: string;
    html: string;
};
/** Markdown for this app's own `text/html` payload; other HTML is never read. */
export declare function buzzCopyMarkdown(html: string): string | undefined;
/** External HTML contributes web links, never Buzz identity metadata or styling. */
export declare function externalLinkMarkdown(html: string, plain?: string): string | undefined;
