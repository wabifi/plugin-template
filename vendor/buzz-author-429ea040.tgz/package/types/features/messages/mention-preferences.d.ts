export declare function rememberAgentsPreference(): boolean;
export declare function useRememberAgentsPreference(): boolean;
export declare function setRememberAgentsPreference(enabled: boolean): string | null;
