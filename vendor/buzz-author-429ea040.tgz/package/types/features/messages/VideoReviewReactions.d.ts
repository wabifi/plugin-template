import { type RefObject } from "react";
import type { RelaySession } from "../relay/session";
import type { ConversationExtensions } from "../conversation/contracts";
/** Quick review reactions are timecoded comments, using the existing reply writer. */
export declare function VideoReviewReactions({ session, scope, channelId, rootId, videoRef, extensions, }: {
    session: RelaySession;
    scope: string;
    channelId: string;
    rootId: string;
    videoRef: RefObject<HTMLVideoElement | null>;
    extensions?: ConversationExtensions | undefined;
}): import("react").JSX.Element;
