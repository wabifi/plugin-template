import { type ComponentType } from "react";
import type { ComposerCaptureProps } from "../conversation/contracts";
import { type AttachmentDraft } from "./attachment-draft";
/** Unaccepted microphone capture is revoked with its composer; accepted files use the shared draft. */
export declare function useVoiceCapture(store: AttachmentDraft, disabled: boolean, report: (error: string) => void): {
    begin: (component: ComponentType<ComposerCaptureProps>) => false | (() => void);
    capturing: boolean;
    isCapturing: () => boolean;
    element: import("react").JSX.Element | null;
};
