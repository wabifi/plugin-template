import { type RefObject } from "react";
/** Shared directional navigation recipe for sent images and draft media. */
export declare const galleryMotion: {
    distance: number;
    duration: number;
    ease: readonly [0.19, 1, 0.22, 1];
};
type DepartingImage = {
    url: string;
    source: string;
    transform: string;
    direction: number;
};
/** Keep the outgoing DOM image alive until its replacement can slide into view. */
export declare function useImageGalleryMotion(stage: RefObject<HTMLDivElement | null>, image: RefObject<HTMLImageElement | null>, url: string | undefined, source: string | undefined): {
    departing: DepartingImage | undefined;
    prepare: (direction: number) => void;
};
export {};
