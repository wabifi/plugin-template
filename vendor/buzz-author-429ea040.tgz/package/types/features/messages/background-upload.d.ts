import type { UploadedAttachment } from "../relay/attachments";
import type { ComposerSession } from "./composer-session";
import { type AttachmentDraft, type DraftAttachment } from "./attachment-draft";
type Notice = Readonly<{
    id: string;
    message: string;
    retry?: () => void;
}>;
export type BackgroundUploads = Readonly<{
    uploading: boolean;
    phase: "Preparing" | "Uploading" | "Finishing";
    /** Fraction of bytes sent, or null while the host reports no byte counts. */
    progress: number | null;
    notices: readonly Notice[];
    host: object | undefined;
}>;
/** Takes admitted files after Send; files upload in order, then publish once.
 * Every unpublished outcome hands the files back to `recover`. */
export declare function sendInBackground(session: ComposerSession, owner: string, channelId: string, files: readonly DraftAttachment[], publish: (uploaded: readonly UploadedAttachment[]) => void | Promise<void>, recover: (files: readonly DraftAttachment[], preparationError?: unknown) => boolean | "conflict", source?: AttachmentDraft): void;
/** Desktop's Cancel stops the newest send and restores it like a failure. */
export declare function cancelBackgroundUpload(session: ComposerSession): void;
/** Like Desktop, a conversation cannot send again until its upload settles. */
export declare function useBackgroundSendPending(session: ComposerSession, owner: string): boolean;
export declare function dismissBackgroundUploadNotice(session: ComposerSession, id: string): void;
/** Every composer shows progress; only the first mounted one hosts notices. */
export declare function useBackgroundUploads(session: ComposerSession): {
    uploading: boolean;
    phase: "Preparing" | "Uploading" | "Finishing";
    progress: number | null;
    host: object | undefined;
    notices: readonly Readonly<{
        id: string;
        message: string;
        retry?: () => void;
    }>[];
};
export {};
