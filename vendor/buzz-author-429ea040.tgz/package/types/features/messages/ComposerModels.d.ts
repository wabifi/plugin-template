import type { SessionPlace } from "../agents/service";
import type { MentionPicks } from "../relay/messages";
/** Model and effort for the next run of each mentioned agent of the viewer's
 * that offers a choice. Session controls act immediately on this conversation. */
export declare function ComposerModels({ pubkeys, value, disabled, onChange, onResolved, startsThread, place, }: {
    pubkeys: readonly string[];
    value: MentionPicks;
    disabled: boolean;
    onChange(value: MentionPicks): void;
    onResolved(value: MentionPicks): void;
    /** The message starts a thread of its own, as a channel's top-level one
     * does, so a thread-scoped agent has no session to act on. */
    startsThread: boolean;
    place: SessionPlace;
}): import("react").JSX.Element | null;
