/** One worker per pixel conversion: cancellation terminates synchronous Wasm work. */
export declare function encodeWebp(pixels: ImageData, signal: AbortSignal): Promise<Blob>;
