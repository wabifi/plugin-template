import type { ChannelLifecycleCapability } from "../relay/channel-lifecycle";
/** A public preview offers Join; the membership roster, not this notice, enables the composer.
 * Confirmed membership can unmount this notice before its run settles, so the
 * page records the join intent when the run starts, not when it resolves. */
export declare function ChannelJoinNotice({ channelId, ready, lifecycle, joinable, onJoin, onHeightChange, }: {
    channelId: string;
    ready?: boolean;
    lifecycle?: ChannelLifecycleCapability | undefined;
    joinable: boolean;
    onJoin(): void;
    onHeightChange?(height: number): void;
}): import("react").JSX.Element;
