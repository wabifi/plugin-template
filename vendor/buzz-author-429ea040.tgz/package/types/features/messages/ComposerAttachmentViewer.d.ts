import { type RefObject } from "react";
import type { AttachmentRenderer, ContributionReader } from "../conversation/contracts";
import type { DraftAttachment } from "./attachment-draft";
export declare function ComposerAttachmentViewer({ items, selected, select, media, renderers, restoreFocus, close, }: {
    items: readonly DraftAttachment[];
    selected: string;
    select(id: string): void;
    media(url: string): string | undefined;
    renderers?: ContributionReader<AttachmentRenderer> | undefined;
    restoreFocus: RefObject<HTMLElement | null>;
    close(): void;
}): import("react").JSX.Element | null;
