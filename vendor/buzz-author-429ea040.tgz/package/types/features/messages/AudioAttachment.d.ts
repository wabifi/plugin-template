import { type Attachment } from "../relay/contracts";
export declare function AudioAttachment({ attachment, source, }: {
    attachment: Attachment;
    source: string;
}): import("react").JSX.Element;
