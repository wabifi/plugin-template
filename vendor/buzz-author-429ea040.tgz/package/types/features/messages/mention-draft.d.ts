export type MentionRecipient = Readonly<{
    pubkey: string;
    name: string;
}>;
export type DraftRecipient = MentionRecipient & Readonly<{
    start: number;
    end: number;
}>;
export type ComposerSnapshot = {
    version: 1;
    content: unknown;
};
export type MentionDraft = {
    text: string;
    /** Session references staged above the editor; serialized with the caption. */
    sessionCards?: readonly string[];
    recipients: readonly DraftRecipient[];
    document?: ComposerSnapshot;
};
export declare const mentionBoundary: (text: string, end: number) => boolean;
/** Old text-only drafts remain text-only: restoring prose never creates notifications. */
export declare function mentionDraft(value: unknown): MentionDraft;
/** Prefill exact, already-selected identities; never infer recipients from prose. */
export declare function followupDraft(recipients: readonly MentionRecipient[]): MentionDraft;
/** Known editor replacement keeps only untouched spans. */
export declare function replaceMentionDraft(value: MentionDraft, start: number, end: number, inserted: string): MentionDraft;
export type MentionEdit = Readonly<{
    text: string;
    start: number;
    end: number;
    inputType: string;
}>;
/** Preserve identity only when the browser supplied the actual replacement range.
 * Matching before/after prose cannot distinguish a paste from untouched text. */
export declare function editMentionDraft(value: MentionDraft, text: string, edit?: MentionEdit): MentionDraft;
