import { type RefObject } from "react";
/** One reveal per request signal, never per row/profile/image update. */
export declare function useMessageReveal({ scroller, settled, messageId, signal, ready, complete, prepare, hold, focus, }: {
    scroller: RefObject<HTMLElement | null>;
    settled: RefObject<boolean>;
    messageId: string | undefined;
    signal: AbortSignal | undefined;
    ready: boolean;
    complete(): void;
    prepare?(): void;
    /** A covering modal owns focus; the underlying target still verifies/reveals. */
    focus?: boolean;
    /**
     * While this returns true after the reveal, keep the row where the reveal put
     * it. Rows mounted around the target can measure after verification and push
     * it out of view. The owner ends the hold on reader intent.
     */
    hold?: () => boolean;
}): RefObject<AbortSignal | undefined>;
