/** The host validates the URL again and owns the destination; never navigate the webview. */
export declare function downloadNativeMedia(source: string, name?: string): Promise<void>;
