/** Selected keys participate in naming even if no longer eligible for another selection. */
export declare const SelectedMentionContext: import("react").Context<readonly Readonly<{
    pubkey: string;
    name: string;
}>[]>;
