export declare function WorkflowByline({ ownerId, ownerName, signer, canOpenLink, onOpenLink, }: {
    ownerId: string;
    ownerName: string;
    signer: string;
    canOpenLink?: ((url: string) => boolean) | undefined;
    onOpenLink(url: string): boolean;
}): import("react").JSX.Element;
