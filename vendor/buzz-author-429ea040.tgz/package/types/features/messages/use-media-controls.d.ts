import { type RefObject } from "react";
/** Pointer activity reveals controls; CSS keeps keyboard and touch access intact. */
export declare function useMediaControls(stage: RefObject<HTMLElement | null>, source?: string, revealed?: boolean): boolean;
