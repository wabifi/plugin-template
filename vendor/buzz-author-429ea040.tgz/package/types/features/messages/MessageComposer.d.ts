import type { ChannelMessage } from "../relay/contracts";
import { type AttachmentDraft } from "./attachment-draft";
import { type ReactNode } from "react";
import { type ComposerSession } from "./composer-session";
import type { RelaySession } from "../relay/session";
import { type MentionDraft, type MentionRecipient } from "./mention-draft";
import type { ConversationExtensions } from "../conversation/contracts";
import type { MessageLinkOrigin } from "./MessageRow";
export type MessageComposerProps = {
    extensions?: ConversationExtensions | undefined;
    scope: string;
    session: ComposerSession | RelaySession;
    channelId: string;
    channelName: string;
    label?: string | undefined;
    placeholder?: string | undefined;
    soloConversation?: boolean | undefined;
    ownSoloConversation?: boolean | undefined;
    /** Seeds an empty new-chat draft; follow-ups use remembered mentions. */
    defaultMention?: MentionRecipient | undefined;
    /** Sending needs at least one tagged recipient. */
    requireMention?: boolean | undefined;
    chatPresentation?: boolean | undefined;
    activityClickOpensPanel?: boolean | undefined;
    trailingTool?: ReactNode;
    inviteAgents?: boolean | undefined;
    onSend?: (id: string) => void;
    /** Inbox may retire only after saving the replacement or confirming no draft remains. */
    onDraftSaved?: (() => void) | undefined;
    /** Threads supply their own retained rows; channels use the shared window. */
    editMessages?: readonly ChannelMessage[] | undefined;
    onOpenLink?: ((target: string, origin?: MessageLinkOrigin) => boolean) | undefined;
    canOpenLink?: ((target: string) => boolean) | undefined;
    threadRootId?: string;
    replyParentId?: string | undefined;
    replyContext?: ReactNode;
    mediaTimeSeconds?: number;
    clearMediaTime?(): void;
    /** Focus once when this conversation mounts, not when overlays close. */
    autoFocus?: boolean;
    focusRequest?: number;
    hideMediaTimeIndicator?: boolean;
    disabled?: boolean;
    /** A new conversation owns persistence and delivery before a channel exists. */
    submission?: {
        draftKey: string;
        initialDraft?: MentionDraft | string | undefined;
        /** A durable operation overrides disposable view state during recovery. */
        recoveredDraft?: MentionDraft | undefined;
        locked: boolean;
        disabled: boolean;
        /** Files upload before the conversation exists; submit sends them. */
        attachments?: boolean;
        submit: (draft: MentionDraft, attachments: AttachmentDraft) => void;
    };
};
/** Safe to retarget through ordinary props; callers do not own internal remount keys. */
export declare function MessageComposer(props: MessageComposerProps): import("react").JSX.Element;
