import { Schema, type Node as EditorNode } from "prosemirror-model";
import type { MentionDraft, DraftRecipient } from "./mention-draft";
import type { ComposerResource } from "../conversation/contracts";
/** The document owns editable marks and exact source tokens. Unimplemented
 * Markdown stays source text, never round-trips through an HTML serializer. */
export declare const composerSchema: Schema<"blockquote" | "bullet_list" | "code_block" | "doc" | "hard_break" | "list_item" | "ordered_list" | "paragraph" | "text" | "token", "bold" | "code" | "italic" | "link" | "literal" | "recipient" | "spoiler" | "strike">;
export type SourceToken = {
    start: number;
    end: number;
    editAsText?: boolean;
};
export type SourceRange = {
    start: number;
    end: number;
};
/** Source ranges the editor must not format: existing Markdown code, images,
 * definitions and HTML stay literal text. */
export declare function markdownRanges(text: string): {
    literal: {
        start: number;
        end: number;
    }[];
};
/** Draft text stays the editing/completion coordinate space. Formatting metadata
 * is local authoring state; message publication serializes it separately. */
export declare function readComposerDocument(draft: MentionDraft, tokens: readonly SourceToken[]): EditorNode;
/** Resource tokens whose source no longer parses as exactly their own link in
 * the surrounding Markdown (e.g. after `!`, inside backticks, or under a mark). */
export declare function brokenResources(doc: EditorNode, source?: {
    draft: {
        text: string;
        recipients: DraftRecipient[];
        document: {
            version: 1;
            content: any;
        };
    };
    positions: number[];
    tokens: (SourceToken & {
        from: number;
        to: number;
        node: EditorNode;
    })[];
    blocks: {
        from: number;
        to: number;
        start: number;
        code: boolean;
    }[];
    source(position: number): number;
    position(offset: number, bias?: number): number;
}): (SourceToken & {
    from: number;
    to: number;
    node: EditorNode;
})[];
/** Like mention provenance, a resource that would not be sent as its link
 * becomes the ordinary source text that will actually be sent. */
export declare function demoteBrokenResources(doc: EditorNode): EditorNode;
/** Marks under which a resource token's source is not sent as its link. */
export declare const resourceBlockingMarks: () => import("prosemirror-model").MarkType[];
/** A resource is sent as exactly `source`: one inline Markdown link whose text is
 * the escaped, single-line label (at most 120 code points) and whose destination
 * is the unchanged, navigation-safe URI. Anything else is rejected. */
export declare function composerResource(value: unknown): {
    resource: ComposerResource;
    source: string;
} | undefined;
/** Document positions, editable text offsets, and serialized Markdown offsets
 * are distinct. No generated Markdown delimiter enters this map. */
export declare function projectComposerDocument(doc: EditorNode): {
    draft: {
        text: string;
        recipients: DraftRecipient[];
        document: {
            version: 1;
            content: any;
        };
    };
    positions: number[];
    tokens: (SourceToken & {
        from: number;
        to: number;
        node: EditorNode;
    })[];
    blocks: {
        from: number;
        to: number;
        start: number;
        code: boolean;
    }[];
    source(position: number): number;
    position(offset: number, bias?: number): number;
};
/** Already-rich content is not Markdown syntax. Preserve UTF-16 offsets and
 * line breaks so raw prose can use the parser without borrowing rich delimiters. */
export declare function composerMarkdownContext(doc: EditorNode, source?: {
    draft: {
        text: string;
        recipients: DraftRecipient[];
        document: {
            version: 1;
            content: any;
        };
    };
    positions: number[];
    tokens: (SourceToken & {
        from: number;
        to: number;
        node: EditorNode;
    })[];
    blocks: {
        from: number;
        to: number;
        start: number;
        code: boolean;
    }[];
    source(position: number): number;
    position(offset: number, bias?: number): number;
}): {
    text: string;
    protected: SourceRange[];
};
/** Local persistence envelope. The schema, not parallel mark ranges, owns shape. */
export declare function readComposerSnapshot(value: unknown): EditorNode | undefined;
