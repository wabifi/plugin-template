import type { RelaySession } from "../relay/session";
export declare function StatusEmoji({ value, session, decorative, }: {
    value: string;
    session: RelaySession;
    decorative?: boolean;
}): import("react").JSX.Element | null;
