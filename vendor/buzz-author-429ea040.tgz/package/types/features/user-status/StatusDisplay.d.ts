import type { RelaySession } from "../relay/session";
import type { UserStatus } from "../relay/user-status";
export declare function StatusDisplay({ status, session, compact, focusable, }: {
    status: UserStatus | undefined;
    session: RelaySession;
    compact?: boolean;
    focusable?: boolean;
}): import("react").JSX.Element | null;
export declare function UserStatusDisplay({ session, userId, compact, focusable, }: {
    session: RelaySession;
    userId: string;
    compact?: boolean;
    focusable?: boolean;
}): import("react").JSX.Element;
