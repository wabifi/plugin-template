import { type OpenTarget } from "./targets";
/** Stable visit identity, distinct from the cancellable attempts to reveal it. */
export type NavigationEntry = Readonly<{
    id: string;
    target: OpenTarget;
}>;
export type HistorySnapshot = Readonly<{
    current: NavigationEntry;
    canGoBack: boolean;
    canGoForward: boolean;
    /** Host-address parsing failed; retained target is not a successful destination. */
    invalidAddress?: boolean;
}>;
/** A host uses exactly one driver. Traversal publishes; it never calls push. */
export interface NavigationHistory {
    snapshot(): HistorySnapshot;
    /** Exactly one controller attachment for the lifetime of this driver. UI observes Navigation. */
    attach(controller: () => void): () => void;
    push(target: OpenTarget): void;
    /** Normalize this visit's resolved destination without creating another visit. */
    resolve(target: OpenTarget): void;
    replace(target: OpenTarget): void;
    back(): void;
    forward(): void;
    /** Return to a retained in-document visit, without creating another entry. */
    returnTo(entryId: string): boolean;
    dispose(): void;
}
export declare const homeTarget: Readonly<{
    readonly version: 1;
    readonly kind: "home";
}>;
export declare function navigationEntry(target: OpenTarget): NavigationEntry;
/** Non-browser host driver. Browser hosts supply actual session-history traversal. */
export declare function createMemoryHistory(initial?: OpenTarget, capacity?: number): NavigationHistory;
