export type JsonValue = null | boolean | number | string | readonly JsonValue[] | {
    readonly [key: string]: JsonValue;
};
export type NavigationScope = Readonly<{
    viewer: string;
    communityOrigin: string;
}>;
export type OpenTarget = Readonly<{
    version: 1;
    kind: "home";
}> | Readonly<{
    version: 1;
    kind: "settings";
    section?: string;
    scope?: NavigationScope | null;
}> | Readonly<{
    version: 1;
    kind: "page";
    pluginId: string;
    pageId: string;
    /** null explicitly restores Personal space; omission leaves community selection alone. */
    scope?: NavigationScope | null;
    route?: Readonly<{
        version: number;
        params: JsonValue;
    }>;
}> | Readonly<{
    version: 1;
    kind: "conversation";
    scope: NavigationScope;
    channelId: string;
    messageId?: string;
    /** Hint only. Resolve the actual root from verified message evidence. */
    threadRootId?: string;
    /** Presentation within this conversation; never mutation or confirmation state. */
    panel?: "members" | "shared-sessions";
}>;
/** All bound ingresses use this parser. A valid address is not authorization. */
export declare function parseOpenTarget(input: unknown): OpenTarget;
export declare function targetKey(target: OpenTarget): string;
