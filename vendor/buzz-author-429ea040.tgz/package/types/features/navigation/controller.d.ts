import { type OpenTarget } from "./targets";
import type { NavigationEntry, NavigationHistory } from "./history";
/**
 * Shared abort reason. A reason-less abort() makes Blink mint a DOMException per
 * call, and V8 keeps its unformatted stack alive: that stack holds the start()
 * scope (so the next attempt) and the click dispatch (so the unmounted DOM).
 * One instance captures no per-abort stack, so its .stack points at module
 * evaluation, not the aborting site: do not use it for diagnostics.
 */
export declare const NAVIGATION_ABORTED: DOMException;
export type OpenFailure = "invalid-target" | "unavailable" | "denied" | "not-found" | "timeout" | "host-error";
export type OpenResult = Readonly<{
    status: "opened";
} | {
    status: "cancelled" | "superseded";
} | {
    status: "failed";
    reason: OpenFailure;
}>;
/** Focus is per opening, never part of a saved address or history entry. */
export type NavigationFocus = "content" | "preserve";
export type NavigationOpenOptions = {
    replace?: boolean;
    focus?: NavigationFocus;
};
export type OpenAttempt = Readonly<{
    id: string;
    entry: NavigationEntry;
    signal: AbortSignal;
    focus?: NavigationFocus;
}>;
export type NavigationSnapshot = Readonly<{
    entry: NavigationEntry;
    attempt: OpenAttempt;
    status: "opening" | OpenResult["status"];
    reason?: OpenFailure;
    /** An incoming URL failed before it could create a history destination. */
    ingress?: boolean;
    retryable?: boolean;
    canGoBack: boolean;
    canGoForward: boolean;
}>;
export type Navigation = Readonly<{
    snapshot(): NavigationSnapshot;
    subscribe(listener: () => void): () => void;
    open(target: OpenTarget, options?: NavigationOpenOptions): Promise<OpenResult>;
    back(): void;
    forward(): void;
    retry(): Promise<OpenResult>;
}>;
/** The host alone receives completion/cancellation authority. Plugins get Navigation. */
export declare function createNavigationController(history: NavigationHistory, timeoutMs?: number): {
    navigation: Readonly<{
        snapshot(): NavigationSnapshot;
        subscribe(listener: () => void): () => void;
        open(target: OpenTarget, options?: NavigationOpenOptions): Promise<OpenResult>;
        back(): void;
        forward(): void;
        retry(): Promise<OpenResult>;
    }>;
    /** Normalize a pending presentation, not a new intent; never reset its deadline. */
    resolve(attempt: OpenAttempt, input: OpenTarget): boolean;
    /** Acknowledge only the exact active attempt after actual presentation. */
    complete(attempt: OpenAttempt, result: Extract<OpenResult, {
        status: "opened" | "failed";
    }>): boolean;
    /** Host-only return from a modal destination to its retained workspace visit. */
    returnTo(entryId: string): boolean;
    cancel(): void;
    /** Keep pre-navigation recovery separate from the previous history visit. */
    fail(reason: OpenFailure, retry?: () => Promise<OpenResult>): void;
    dispose(): void;
};
