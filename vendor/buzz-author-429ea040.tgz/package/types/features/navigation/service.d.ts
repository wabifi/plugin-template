import type { Context } from "@deepseek-ai/cordis";
import { type Navigation, type OpenAttempt, type OpenResult, type NavigationFocus } from "./controller";
import { type JsonValue, type OpenTarget } from "./targets";
import type { RelayData, RelaySnapshot } from "../relay/service";
export type PageNavigation = Readonly<{
    entryId: string;
    target: OpenTarget;
    signal: AbortSignal;
    /** Suppress destination autofocus when the opening control retains focus. */
    focus?: NavigationFocus;
    /** Bind a domain subtree to the exact connection it renders, without another visit. */
    forSession(relay: RelayData, connection: RelaySnapshot): PageNavigation;
    /** Resolve the pending visit's default destination without replacing its caller. */
    resolve(target: OpenTarget): boolean;
    complete(result: Extract<OpenResult, {
        status: "opened" | "failed";
    }>): boolean;
}>;
declare module "@deepseek-ai/cordis" {
    interface Context {
        navigation: Navigation;
    }
}
export declare function provideNavigation(ctx: Context, host?: (Window & typeof globalThis) | undefined): {
    navigation: Readonly<{
        snapshot(): import("./controller").NavigationSnapshot;
        subscribe(listener: () => void): () => void;
        open(target: OpenTarget, options?: import("./controller").NavigationOpenOptions): Promise<OpenResult>;
        back(): void;
        forward(): void;
        retry(): Promise<OpenResult>;
    }>;
    resolve(attempt: OpenAttempt, input: OpenTarget): boolean;
    complete(attempt: OpenAttempt, result: Extract<OpenResult, {
        status: "opened" | "failed";
    }>): boolean;
    returnTo(entryId: string): boolean;
    cancel(): void;
    fail(reason: import("./controller").OpenFailure, retry?: () => Promise<OpenResult>): void;
    dispose(): void;
    /** Bounded per-visit state; never drafts, message bodies, credentials or authorization. */
    position(id: string): JsonValue | undefined;
    savePosition(id: string, value: JsonValue): void;
    request(attempt: OpenAttempt, owner: PresentationOwner, retainUnderSettings?: boolean): {
        /** Resume only the original visit; retained content cannot acknowledge Settings. */
        resume(next: OpenAttempt): boolean;
        request: Readonly<{
            entryId: string;
            target: OpenTarget;
            signal: AbortSignal;
            /** Suppress destination autofocus when the opening control retains focus. */
            focus?: NavigationFocus;
            /** Bind a domain subtree to the exact connection it renders, without another visit. */
            forSession(relay: RelayData, connection: RelaySnapshot): PageNavigation;
            /** Resolve the pending visit's default destination without replacing its caller. */
            resolve(target: OpenTarget): boolean;
            complete(result: Extract<OpenResult, {
                status: "opened" | "failed";
            }>): boolean;
        }>;
        dispose: () => void;
    };
};
/** Presentation authority is narrower than the pending visit's lifetime. */
export type PresentationOwner = {
    valid(): boolean;
    subscribe(listener: () => void): () => void;
};
