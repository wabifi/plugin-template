import { type EntityRoute } from "../repos/routes";
import { type NavigationScope, type OpenTarget } from "./targets";
type BuzzLink = {
    format: "removed";
} | {
    format: "entity";
    route: EntityRoute;
} | {
    format: "plugin";
    pluginId: string;
} | {
    format: "legacy";
    channelId: string;
    messageId?: string;
    threadRootId?: string;
};
/** True for any `buzz:` scheme link, regardless of case. Classification must
 * match `parseBuzzLink`, which normalizes the scheme via `URL`; a lowercase-only
 * `startsWith` check would misroute `BUZZ://…` to external handling. */
export declare function isBuzzLink(href: string): boolean;
/** Legacy links are relative to the receiving conversation's community, never an access grant. */
export declare function parseBuzzLink(href: string): BuzzLink | null;
/** A plugin link opens the directory's details dialog; it never grants or installs. */
export declare function pluginLinkTarget(pluginId: string, scope: NavigationScope): OpenTarget;
export declare function buzzLinkKind(href: string): "buzz" | "channel" | "message" | "thread" | null;
export declare function buzzLinkTarget(href: string, scope: NavigationScope): OpenTarget | null;
export {};
