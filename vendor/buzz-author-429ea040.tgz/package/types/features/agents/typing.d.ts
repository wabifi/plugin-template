import type { RelayEvent } from "../relay/events";
import type { AgentEventTemplate } from "./native";
/** One agent's pulses by conversation, each shared by the turns typing there,
 * so a second mention in a thread adds no second pulse. */
export type Pulses = Map<string, {
    turns: number;
    stop: () => void;
}>;
/** Pulses typing, signed as the agent, where it answers `event` until the
 * returned function is called: in the channel itself when `topLevel` settles
 * true, for a Solo chat, which reads as one conversation. It waits
 * for that answer, as its turn does, so both place it alike; a turn that cannot
 * tell where to answer fails, and shows no typing. The pulse ends with it:
 * clients drop typing when the agent replies, or a few seconds after its last
 * pulse. Turns in the same conversation share one pulse in `pulses`, which
 * lasts until the last of them stops. */
export declare function pulseTyping(publish: (event: AgentEventTemplate) => Promise<unknown>, topLevel: Promise<boolean>, event: RelayEvent, channelId: string, pulses: Pulses): () => void;
