import { type RelayEvent } from "../relay/events";
/** A plugin agent's identity as native custody reports it; never the key. The
 * saved identities are the agent list. */
export type AgentIdentity = Readonly<{
    pubkey: string;
    /** The canonical `wss://` community origin it was created for. */
    relay: string;
    owner: string;
    /** The agent type's key, `pluginId/typeId`, fixed at create. */
    type: string;
    name: string;
    /** Its profile picture, an HTTPS image URL. */
    picture?: string;
    /** Its key is gone; its community still has to drop it from its channels and
     * archive it, after which `forget` removes it. */
    deleted: boolean;
    /** Its Delete started and has not finished. It keeps its key, so it cannot
     * be imported again, and stays stopped until Delete is pressed again. */
    deleting?: true;
}>;
/** Where an earlier agent system saved an identity on this machine: this app's
 * harness agents, or the installed or development build of old Buzz. */
export type PortSource = "harness" | "installed" | "development";
/** An identity an earlier agent system saved, which Agents can take over. */
export type PortableAgent = Readonly<{
    source: PortSource;
    pubkey: string;
    name: string;
    picture?: string;
    /** The community it was saved for there, if valid. */
    relay: string;
}>;
/** An old Buzz team as old Buzz last saved it, keyed by its old ID. */
export type OldTeam = Readonly<{
    id: string;
    name: string;
    /** Its shared instructions, "" for none. */
    instructions: string;
    /** Each identity on it, named and sourced as the agent list has it, whether
     * or not it is here already. */
    members: readonly Readonly<{
        pubkey: string;
        name: string;
        source: PortSource;
    }>[];
}>;
/** What an agent kept in an earlier system that its new type may adopt. */
export type Carry = Readonly<{
    instructions?: string;
    /** Its working directory, absolute or `~/…`. */
    workspace?: string;
}>;
export type PortableAgents = Readonly<{
    agents: readonly PortableAgent[];
    /** Old Buzz's teams with a member, built-in ones left out. */
    teams: readonly OldTeam[];
    /** A store that could not be read; the others are still listed. */
    warnings: readonly string[];
}>;
export type AgentEventTemplate = Readonly<{
    kind: number;
    content: string;
    tags?: readonly (readonly string[])[];
}>;
/** The community's description of an uploaded blob. */
export type AgentUpload = Readonly<{
    url: string;
    sha256: string;
    size: number;
    type: string;
    dim?: string;
    blurhash?: string;
    thumb?: string;
    duration?: number;
}>;
/** A community media blob saved to a local file for the agent; `data`
 * (base64) is the image itself when the agent can be shown it. */
export type AgentMedia = Readonly<{
    path: string;
    type: string;
    size: number;
    data?: string;
}>;
/** A repository's URL and the `Authorization` header Git sends there. */
export type GitAuth = Readonly<{
    url: string;
    header: string;
}>;
export type AgentsNative = {
    list(): Promise<readonly AgentIdentity[]>;
    /** Generates a key, has the signed-in owner attest it, and saves both. */
    create(destination: string, owner: string, type: string, name: string): Promise<AgentIdentity>;
    /** Earlier agent systems' identities on this machine. */
    portable(): Promise<PortableAgents>;
    /** Takes one over with its key, name and picture, as `create` does, with
     * what it kept there for its new type. */
    port(source: PortSource, pubkey: string, destination: string, owner: string, type: string): Promise<Readonly<{
        agent: AgentIdentity;
        carry: Carry;
        notes?: readonly string[];
    }>>;
    rename(pubkey: string, name: string): Promise<void>;
    /** Sets its profile picture, an HTTPS image URL, or with `null` clears it. */
    setPicture(pubkey: string, picture: string | null): Promise<void>;
    /** Makes it an agent of another type, keeping its identity and profile. */
    setType(pubkey: string, type: string): Promise<void>;
    /** Marks its Delete as started; only `remove` finishing it clears that. */
    beginDelete(pubkey: string): Promise<void>;
    /** Deletes the key and marks the identity deleted. */
    remove(pubkey: string): Promise<void>;
    /** Drops a deleted identity. */
    forget(pubkey: string): Promise<void>;
    /** Signs one event as the agent (deletions, reactions, messages, edits,
     * canvases and DM opens only) with its owner attestation and posts it to the
     * agent's community. */
    publish(pubkey: string, event: AgentEventTemplate): Promise<RelayEvent>;
    /** Reads the agent's community as the agent: one to eight filters. */
    query(pubkey: string, filters: readonly object[]): Promise<RelayEvent[]>;
    /** Current audience decisions, forwarded separately from verified event arrays. */
    audienceAuthority?(pubkey: string, destination: string, sources: readonly string[]): Promise<unknown>;
    /** Finds profiles by `name` or `display_name` in the agent's community, as
     * the agent, best match first. `undefined` when the community has no
     * profile name search. */
    searchProfiles(pubkey: string, query: string, limit: number): Promise<RelayEvent[] | undefined>;
    /** Uploads base64 `data`, a file of any type its community accepts, as
     * the agent. `mime` is a hint; the community decides the type. */
    upload(pubkey: string, data: string, mime: string): Promise<AgentUpload>;
    /** Saves one of its community's media blobs, of any type, as the agent. */
    media(pubkey: string, url: string): Promise<AgentMedia>;
    /** A repository's URL in the agent's community and the Git header that
     * authorizes it there as the agent for a minute. */
    gitAuth(pubkey: string, owner: string, repo: string): Promise<GitAuth>;
    /** Writes memory entry `slug`, encrypted to the owner, newer than `after`. */
    remember(pubkey: string, slug: string, body: string, after: number): Promise<RelayEvent>;
    /** Publishes its name as its profile unless the community already has it. */
    publishProfile(pubkey: string): Promise<void>;
    /** Whether this app runs the agent: every copy of the app on this machine
     * shares the agent list, and one runs each agent. The installed app always
     * runs what it can; a dev build lets go while it does. */
    claim(pubkey: string): Promise<boolean>;
    /** Lets another copy run it. */
    release(pubkey: string): Promise<void>;
};
export declare const nativeAgents: () => AgentsNative | undefined;
