import type { LocalAgent } from "./local";
import type { Agent } from "./service";
/** CK fork (fork/always-on-choices.md): the selected community's hosted agents
 * whose setup finished, offered like the agents here. Their keys stay with
 * their provider. */
export declare const hostedAgents: (agents: readonly Agent[]) => Readonly<{
    pubkey: string;
    name: string;
    picture?: string;
    type: string;
    owner: string;
    relay: string;
    place: import("./service").AgentPlace;
    unfinished?: true;
    archiveUnchecked?: true;
    deleting?: true;
    attention: Readonly<Record<string, Readonly<{
        slug: string;
        value: import("./attention").AttentionValue;
        modifiedAt: number;
    }>>>;
    skipped: Readonly<Record<string, Readonly<{
        slug: string;
        value: unknown;
        modifiedAt: number;
        problem: string;
    }>>>;
    timers: Readonly<Record<string, Readonly<{
        armedAt: number;
        nextDue: number;
        used: number;
    }>>>;
    attentionEnabled: boolean;
    config: unknown;
}>[];
export declare const sameAgents: (a: readonly Agent[], b: readonly Agent[]) => boolean;
export declare const hostedLocalAgents: (agents: readonly Agent[]) => LocalAgent[];
