import { type ComponentProps } from "react";
import { Avatar } from "../../shared/design-system/ui/Avatar";
import type { RelaySession } from "../relay/session";
import "./agent-avatar.css";
type AgentAvatarProps = ComponentProps<typeof Avatar> & {
    session?: RelaySession | undefined;
    agentPubkey?: string | undefined;
    channelId?: string | undefined;
    working?: boolean | undefined;
    thinkingDescriptionId?: string | undefined;
};
export declare function AgentAvatar(props: AgentAvatarProps): import("react").JSX.Element;
export {};
