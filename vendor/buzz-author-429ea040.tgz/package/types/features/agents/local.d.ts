/** One agent this machine keeps, in any community. Names never grant control;
 * Agents owns its key and runtime. */
export type LocalAgent = Readonly<{
    pubkey: string;
    name: string;
    /** The community origin it was created for. */
    relayUrl: string;
    owner: string;
    /** Its profile picture, an HTTPS image URL. */
    picture?: string;
    /** CK fork (fork/always-on-choices.md): its provider runs it and holds its key. */
    hosted?: true;
}>;
export type LocalAgentsSnapshot = Readonly<{
    status: "unavailable" | "loading" | "ready" | "error";
    agents: readonly LocalAgent[];
    error?: string;
    /** CK fork (fork/always-on-choices.md): hosted agents are still being read. */
    partial?: true;
}>;
export type LocalAgents = {
    snapshot(): LocalAgentsSnapshot;
    subscribe(listener: () => void): () => void;
    /** Reads the list again, as Retry asks; the producer owns the read. */
    refresh(): Promise<void>;
};
/** Names and mentions are composed before Agents exists; this lets them
 * follow its list once `bind` connects it. */
export declare function createLocalAgents(): {
    agents: LocalAgents;
    bind(next: LocalAgents): () => void;
};
