import { type AgentConfigStore, type ArtifactState, type SettingsSchema, type Subject } from "./agent-config";
import type { Team } from "./store";
export type Mode = "local" | "migrating" | "synced";
/** One team config channel that lists the agent as a member. */
export type TeamSource = Readonly<{
    id: string;
    lifecycle: "active" | "archived" | "unreadable";
    subject: Subject;
    members: readonly string[];
}>;
export type StartInput<C extends object> = Readonly<{
    store: AgentConfigStore;
    /** This device's row: the launch source in `local`/`migrating`, and the
     * only source of `workspace` and unsynced fields in every mode. */
    local: C;
    agentType: string;
    /** Absent while the agent has no config channel: the type is `local`. */
    settings?: Readonly<{
        mode: Mode;
        subject: Subject;
        schema: SettingsSchema;
        withSynced: (config: C, settings: Readonly<Record<string, string>>) => C;
    }>;
    instructions?: Readonly<{
        mode: Mode;
        subject: Subject;
    }>;
    /** Teams from the synced store; `undefined` while teams are still local. */
    teams?: readonly TeamSource[];
}>;
export type Start<C> = Readonly<{
    ok: true;
    config: C;
    teams?: readonly Team[];
    /** The synced revisions this start used, for "Restart to apply". */
    revisions: readonly string[];
}> | Readonly<{
    ok: false;
    state: ArtifactState;
    reason: string;
}>;
/** Whether a side launches from its synced copy: explicitly synced, or this
 * device has had a synced revision of it, so a stale mode can't fall back. */
export declare const isSynced: (store: AgentConfigStore, side: Readonly<{
    mode: Mode;
    subject: Subject;
}> | undefined) => boolean;
/** Pure over storage: never reads the relay. Once this device has had any
 * synced revision of a type, its local field is never a launch source again.
 * A transport failure never changes a stored state, so a confirmed `present`
 * head keeps serving while the relay is unreachable (offline rule, §4.4);
 * `invalid`, `deleted` and lost access block. */
export declare function resolveStart<C extends object>(input: StartInput<C>): Start<C>;
/** Why a running agent's config changed. */
export type Change = "local" | "remote" | "team";
/** Tracks the synced revisions each agent's current run started from (§4.5):
 * a local save restarts that agent; a remote change only marks it "Restart to
 * apply"; a team save restarts no one, and the next start uses the new copy. */
export declare class Runs {
    private readonly started;
    private readonly stale;
    start(agent: string, revisions: readonly string[]): void;
    revisions: (agent: string) => readonly string[] | undefined;
    restartToApply: (agent: string) => boolean;
    /** What to do with `agent`'s run after a change whose current revisions are
     * `current`. */
    changed(agent: string, change: Change, current: readonly string[]): "restart" | "restart-to-apply" | "none";
}
