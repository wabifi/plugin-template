import type { ReactNode } from "react";
/** Shared working row: conversation navigation and activity are separate actions. */
export declare function AgentActivityRow({ name, picture, status, meta, scope, openLabel, onOpen, onOpenActivity, }: {
    name: string;
    picture?: string | undefined;
    status: string;
    meta?: ReactNode;
    scope?: string | undefined;
    openLabel: string;
    onOpen?: (() => void) | undefined;
    onOpenActivity?: (() => void) | undefined;
}): import("react").JSX.Element;
