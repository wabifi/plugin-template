import type { RelayData } from "../relay/service";
/** Whether a native agent's mention continues a Solo chat: one
 * channel-scoped conversation that posts at channel top level. The channel's
 * Solo label decides, as it does for every member and remote agent. A channel
 * not yet known fails rather than guess the routing. Callers freeze
 * the answer for the turn it admits. */
export declare function soloChat(relay: () => RelayData | undefined, owner: string, channelId: string, signal: AbortSignal): Promise<boolean>;
