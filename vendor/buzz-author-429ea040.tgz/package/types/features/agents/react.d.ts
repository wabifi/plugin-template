import type { ChannelQueries } from "../relay/contracts";
import type { ChannelChoice } from "./attention";
import type { Agents, Models, SessionPlace, SessionState } from "./service";
/** The selected community's agents and the registered types. */
export declare function useAgents(agents: Agents): {
    snapshot: Readonly<{
        status: "unavailable" | "loading" | "ready" | "error";
        classifier: import("./attention-objects").ClassifierAvailability;
        classifierKey: import("./attention-objects").ClassifierKey;
        agents: readonly import("./service").Agent[];
        running: readonly import("./service").Agent[];
        interrupted: readonly import("./service").Agent[];
        teams: readonly import("./store").Team[];
        error?: string;
    }>;
    types: readonly Readonly<import("./service").AgentType<unknown> & {
        key: string;
        pluginId: string;
        revision: string;
        source?: "bundled" | "external";
    }>[];
};
/** Agents' snapshot, or undefined without it. */
export declare function useAgentsSnapshot(agents: Agents | undefined): Readonly<{
    status: "unavailable" | "loading" | "ready" | "error";
    classifier: import("./attention-objects").ClassifierAvailability;
    classifierKey: import("./attention-objects").ClassifierKey;
    agents: readonly import("./service").Agent[];
    running: readonly import("./service").Agent[];
    interrupted: readonly import("./service").Agent[];
    teams: readonly import("./store").Team[];
    error?: string;
}> | undefined;
/** The owner's teams on this device, or none without Agents. */
export declare const useTeams: (agents: Agents | undefined) => readonly Readonly<{
    id: string;
    name: string;
    instructions: string;
    members: readonly string[];
}>[];
/** The agent at `pubkey`, with its type when that is registered. A saved
 * agent whose type plugin is disabled or reloading is still an agent. */
export declare function useAgent(agents: Agents | undefined, pubkey: string): {
    agent: Readonly<{
        pubkey: string;
        name: string;
        picture?: string;
        type: string;
        owner: string;
        relay: string;
        place: import("./service").AgentPlace;
        unfinished?: true;
        archiveUnchecked?: true;
        deleting?: true;
        attention: Readonly<Record<string, Readonly<{
            slug: string;
            value: import("./attention").AttentionValue;
            modifiedAt: number;
        }>>>;
        skipped: Readonly<Record<string, Readonly<{
            slug: string;
            value: unknown;
            modifiedAt: number;
            problem: string;
        }>>>;
        timers: Readonly<Record<string, Readonly<{
            armedAt: number;
            nextDue: number;
            used: number;
        }>>>;
        attentionEnabled: boolean;
        config: unknown;
    }>;
    type: Readonly<import("./service").AgentType<unknown> & {
        key: string;
        pluginId: string;
        revision: string;
        source?: "bundled" | "external";
    }> | undefined;
} | undefined;
/** The state of the targeted harness sessions. Any compaction blocks a send
 * to those targets; ordinary active turns keep accepting steering. */
export declare function useSessionState(agents: Agents | undefined, pubkeys: readonly string[], place: SessionPlace): SessionState;
/** The app's Agents, for surfaces such as the composer that plugins do not own. */
export declare const AgentsContext: import("react").Context<Agents | undefined>;
export declare const MentionModelsContext: import("react").Context<((pubkeys: readonly string[]) => Promise<readonly MentionModelChoice[]>) | undefined>;
export type MentionModelChoice = Models & Readonly<{
    pubkey: string;
    name: string;
    loading?: boolean;
    /** Its type offers immediate controls for sessions of this scope. */
    session?: "thread" | "channel";
}>;
/** The mentioned agents, of the viewer's own, whose type offers a choice of
 * model or effort, or session actions. */
export declare function useMentionModels(pubkeys: readonly string[]): readonly MentionModelChoice[];
/** Channels a watch can be scoped to, by name, from the viewer's joined roster. */
export declare function useChannelChoices(queries: ChannelQueries | undefined): readonly ChannelChoice[];
