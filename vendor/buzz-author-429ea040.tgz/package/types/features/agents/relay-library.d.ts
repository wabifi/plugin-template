import { type ReadFilter } from "../relay/events.ts";
import type { RelayReader } from "../relay/reader.ts";
import { type AgentLibrary } from "./library.ts";
/** Owner-authored agent definitions (30175) and identities (30177). */
export declare const INVENTORY_KINDS: readonly number[];
/** True only for the owner-scoped inventory read that `readRelayLibrary` issues. */
export declare function isOwnerInventoryFilter(filter: ReadFilter, owner: string | undefined): boolean;
/** Legacy persona_id uses the source ID; kind 30175 publishes its NIP-AP slug. */
export declare function definitionSlug(id: string): string;
/** Owner-authored inventory is discovery evidence, not agent custody or admission. */
export declare function readRelayLibrary(reader: RelayReader, owner: string, signal: AbortSignal): Promise<AgentLibrary>;
