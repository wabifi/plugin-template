import type { RelaySession } from "../relay/session";
import type { TypingEntry } from "../relay/typing";
type Snapshot = ReturnType<RelaySession["agentActivity"]["snapshot"]>;
export type CurrentActivity = {
    label: string;
    /** Null is the channel conversation; undefined is genuinely unknown. */
    roots: (string | null | undefined)[];
};
/** Existing live evidence only. Channel views include threads; thread views do not. */
export declare function currentActivity(snapshot: Snapshot | undefined, entries: readonly TypingEntry[], ownedAgents: ReadonlySet<string>, channelId: string, threadRootId?: string): ReadonlyMap<string, CurrentActivity>;
export {};
