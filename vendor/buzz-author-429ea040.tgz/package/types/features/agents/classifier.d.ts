import type { RelayEvent } from "../relay/events";
import { type EventWatch } from "./attention";
export declare const CLASSIFIER_MODEL = "jev-1.13.0";
/** What native returns: Jev's raw answers, or why there are none. */
export type NativeClassified = Readonly<{
    outcome: "answered";
    answers: unknown;
}> | Readonly<{
    outcome: "failed";
    reason: string;
}>;
export type ClassifierNative = Readonly<{
    /** Whether a key is saved. */
    status(): Promise<boolean>;
    /** Saves the key; it is never read back. */
    setKey(key: string): Promise<void>;
    clearKey(): Promise<void>;
    classify(state: object, questions: object): Promise<NativeClassified>;
}>;
export declare const nativeClassifier: () => ClassifierNative | undefined;
export type ClassifierAnswer = Readonly<{
    probability: number;
    threshold: number;
    pass: boolean;
}>;
/** What a classified watch's turn is told about its classifier. */
export type ClassifierOutcome = 
/** No key is set, so it did not run. */
Readonly<{
    outcome: "not-run";
    reason: string;
}>
/** It ran and failed, so the event passed unchecked. */
 | Readonly<{
    outcome: "failed";
    reason: string;
}>
/** Jev answered and at least one answer passed. */
 | Readonly<{
    outcome: "passed";
    model: string;
    answers: Readonly<Record<string, ClassifierAnswer>>;
    /** The pass rule: any question that says yes. */
    policy: string;
}>;
/** Facts about the event's surroundings. Names are unverified display text. */
export type ClassifierContext = Readonly<{
    channel: {
        name: string | null;
    };
    thread: {
        is_reply: boolean;
        parent: {
            author: {
                role: "owner" | "other" | "self";
                name: string | null;
            };
            content: string;
        } | null;
    };
    mentions: {
        agent: boolean;
        owner: boolean;
        others: number;
    };
}>;
export type ClassifierInput = Readonly<{
    classifier: NonNullable<EventWatch["classifier"]>;
    event: RelayEvent;
    author: {
        role: "owner" | "other";
        name: string | null;
    };
    context?: ClassifierContext;
}>;
/** Jev's questions, one `noul` (yes probability) per named question. */
export declare function jevQuestions(classifier: ClassifierInput["classifier"]): {
    [k: string]: {
        type: string;
        instructions: {
            question: string;
            guidance?: string;
            boundaries: string;
        };
        criteria: {
            true: string;
            false: string;
        };
    };
};
/** The state Jev judges. The Interest is not sent; the questions carry the
 * criteria, as in Janet. */
export declare function jevState(input: ClassifierInput): {
    event: {
        id: string;
        pubkey: string;
        created_at: number;
        kind: number;
        tags: string[][];
        content: string;
    };
    author: {
        role: "owner" | "other";
        name: string | null;
    };
    context?: Readonly<{
        channel: {
            name: string | null;
        };
        thread: {
            is_reply: boolean;
            parent: {
                author: {
                    role: "owner" | "other" | "self";
                    name: string | null;
                };
                content: string;
            } | null;
        };
        mentions: {
            agent: boolean;
            owner: boolean;
            others: number;
        };
    }>;
};
/** The outcome when no classifier can run. */
export declare const notRun: () => Readonly<{
    outcome: "not-run";
    reason: string;
}>;
/** Runs the classifier. Any failure lets the event pass, as in Janet. */
export declare function classify(native: ClassifierNative, input: ClassifierInput): Promise<{
    pass: boolean;
    result: ClassifierOutcome;
}>;
export declare function mentionFacts(tags: readonly (readonly string[])[], agent: string, owner: string): ClassifierContext["mentions"];
export declare const excerpt: (s: string) => string;
