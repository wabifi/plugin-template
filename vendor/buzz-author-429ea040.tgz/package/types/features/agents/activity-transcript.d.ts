/** Owner-only display projection of observer telemetry into turns and items.
 * Raw session retention is unchanged; this reads allowlisted ACP fields only. */
type Source = Readonly<{
    id: string;
    agent: string;
    receivedAt: number;
    plaintext: string;
}>;
export type TranscriptScope = Readonly<{
    agent: string;
    channelId?: string | undefined;
    /** Exact NIP-10 root. Omit for the whole channel, threads included. */
    threadRootId?: string | undefined;
}>;
export type PromptSection = Readonly<{
    tag: string;
    body: string;
}>;
type Base = {
    id: string;
    at: number;
};
/** ACP `diff` tool content; a missing old text is a new file. */
export type ToolDiff = {
    path: string;
    oldText?: string;
    newText: string;
};
/** Tool names and inputs are adapter-specific, so they are shown as sent;
 * only ACP's standard `kind`, `status`, `locations` and content are read. */
export type ToolItem = Base & {
    type: "tool";
    toolCallId: string;
    title: string;
    kind: string;
    status: string;
    input: string;
    output: string;
    diffs: ToolDiff[];
    paths: string[];
    completedAt?: number;
    truncated: boolean;
    permission?: {
        options: string[];
        outcome?: string;
    };
    /** Calls recorded while this script was executing, in recorded order. */
    children?: TranscriptItem[];
};
export type TranscriptItem = (Base & {
    type: "system";
    sections: PromptSection[];
}) | (Base & {
    type: "prompt";
    text: string;
    author?: string;
    sections: PromptSection[];
    steer: boolean;
}) | (Base & {
    type: "message" | "thought";
    text: string;
    messageId?: string;
    /** Posted to Buzz, rather than said only in the session. */
    posted?: boolean;
}) | ToolItem | (Base & {
    type: "plan";
    entries: {
        content: string;
        status: string;
    }[];
}) | (Base & {
    type: "status";
    text: string;
});
export type TranscriptTurn = {
    turnId: string;
    channelId: string | null;
    /** Null is the channel conversation; undefined means not recoverable. */
    threadRootId: string | null | undefined;
    source?: string;
    triggeringEventIds: string[];
    sessionId?: string;
    newSession: boolean;
    /** Selected ACP session config values, e.g. model and thinking level. */
    config: string[];
    startedAt: number;
    endedAt?: number;
    error?: string;
    stopReason?: string;
    context?: {
        used: number;
        size: number;
    };
    /** No turn_started frame is loaded, so earlier items may be missing. */
    partial: boolean;
    items: TranscriptItem[];
};
export type Transcript = Readonly<{
    turns: readonly TranscriptTurn[];
    /** Turns hidden from a thread scope because their thread is unknown. */
    unknownThread: number;
}>;
/** Split top-level `<tag attrs>` … `</tag>` prompt framing; other text is kept. */
export declare function promptSections(text: string): PromptSection[];
/** The triggering Buzz event(s): author label and content, without tags. */
export declare function promptMessage(sections: PromptSection[]): {
    text: string;
    author: string | undefined;
};
export declare function activityTranscript(records: readonly Source[], scope: TranscriptScope): Transcript;
export {};
