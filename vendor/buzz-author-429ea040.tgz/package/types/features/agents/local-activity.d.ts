export type LocalWorkState = "waiting" | "working" | "done" | "error" | "superseded" | "stopped";
export type WorkOutcome = Readonly<{
    ok: boolean;
    error?: string;
}>;
/** A harness step: its own tool name and, when known, what it acts on. */
export type WorkStep = Readonly<{
    tool: string;
    target?: string;
}>;
export type LocalWork = Readonly<{
    scope: string;
    agent: string;
    channelId: string;
    messageId: string;
    threadRootId: string;
    state: LocalWorkState;
    startedAt: number;
    error?: string;
    /** Latest live step, as the harness named it; display only. */
    step?: WorkStep;
    /** The owner hid this error here; the outcome remains as evidence. */
    dismissed?: true;
    /** Its harness can stop the turn it is in. */
    stoppable?: true;
}>;
export type LocalAgentSource = {
    work(): readonly LocalWork[];
    subscribeWork(listener: () => void): () => void;
    /** Hides one already-seen error on this device; never changes its outcome. */
    dismissError?(work: Pick<LocalWork, "scope" | "agent" | "messageId">): void;
    /** Stops the turn this unsettled request is in, then shows it stopped. */
    interrupt?(work: Pick<LocalWork, "scope" | "agent" | "messageId">): Promise<void>;
};
/** App-owned local facts. No relay publication, inference, polling or process control. */
export declare function createLocalAgentActivity(): {
    reader: LocalAgentSource;
    begin(input: Omit<LocalWork, "state" | "startedAt" | "error" | "dismissed" | "stoppable">): {
        started: () => void;
        supersede: () => void;
        /** Latest live step reported by the plugin; display only. */
        step: (tool: string, target?: string) => void;
        finish: (result: WorkOutcome) => void;
        /** The harness's way to stop this request's turn, offered as Stop. */
        interruptible: (stop: () => Promise<void>) => void;
        remove: () => void;
    };
    clear(scope?: string, agent?: string): void;
};
export type LocalAgentActivity = ReturnType<typeof createLocalAgentActivity>;
/** One aggregation for all local channel/thread/message status presentations. */
/** Received, or handed over but not yet on a first step: shown as breathing "Starting". */
export declare function breathing(row: Pick<LocalWork, "state" | "step"> | undefined): boolean;
export declare function localActivity(snapshot: {
    local?: readonly LocalWork[];
} | undefined, channelId: string, threadRootId?: string): Map<string, Readonly<{
    scope: string;
    agent: string;
    channelId: string;
    messageId: string;
    threadRootId: string;
    state: LocalWorkState;
    startedAt: number;
    error?: string;
    /** Latest live step, as the harness named it; display only. */
    step?: WorkStep;
    /** The owner hid this error here; the outcome remains as evidence. */
    dismissed?: true;
    /** Its harness can stop the turn it is in. */
    stoppable?: true;
}>>;
export declare function localWorkLabel(row: Pick<LocalWork, "state" | "error" | "step">): string;
export declare function stepText(step: WorkStep): string;
