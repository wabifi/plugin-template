import type { Profile } from "../relay/contracts";
import type { ComposerSession } from "../messages/composer-session";
/** One display-only projection per owning surface; exact keys, never display names.
 * Subscribes to existing evidence without initiating library reads. */
export declare function useKnownAgentPubkeys(session: ComposerSession, profiles: ReadonlyMap<string, Profile>): ReadonlySet<string>;
