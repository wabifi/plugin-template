/** Public identity locator, not a relay hint or an authority claim. */
export declare function profileTarget(pubkey: string, hint?: {
    agent: boolean;
}): string | undefined;
/** App-local avatar presentation only; never evidence of ownership or control. */
export declare function profileAgentHint(target: string): boolean;
export declare function profilePanelKey(target: string): string | undefined;
/** Public message/composer input must never supply an app-local avatar hint. */
export declare function profileKey(target: string): string | undefined;
/** App-local Activity destination, never a public identity or authority claim. */
export declare function profileActivityViewTarget(pubkey: string): string | undefined;
export declare function profileActivityViewKey(target: string): string | undefined;
