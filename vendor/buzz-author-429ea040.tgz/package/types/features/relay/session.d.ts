import type { LocalAgentSource } from "../agents/local-activity";
import type { LocalAgents } from "../agents/local";
import type { GitRead } from "../repos/git";
import { type ChannelCreationInput } from "../channel-templates/setup";
import type { PresenceActivity } from "../presence/activity";
import { type IdentityNames } from "../identity-names/service";
import { type ReadOptions, type RelayReader } from "./reader";
import { type ReadPublisherLock } from "./read-state";
import { type ReadStateStorage } from "./read-state-storage";
import type { IncomingListener, LiveListener } from "./incoming";
import type { ChannelSummary } from "./contracts";
import { type ChannelStoreOptions } from "./store";
import { type UploadedAttachment, type UploadProgress } from "./attachments";
import type { ReadTransport } from "./transport";
import { type ReadFilter, type RelayEvent, type EventData } from "./events";
import { type OutboxStorage } from "./outbox";
import { type RecoverySource } from "./recovery";
import { type VisibleEvent } from "./projection";
export type EventViewSnapshot = Readonly<{
    status: "idle" | "loading" | "ready" | "error";
    events: readonly VisibleEvent[];
    error?: string | undefined;
}>;
/** Compose once per relay/viewer. Plugins get one interface; the host owns disposal. */
export declare function createRelaySession(transport: ReadTransport | null, options?: ChannelStoreOptions & {
    identityNames?: IdentityNames | undefined;
    agentChoices?: LocalAgents | undefined;
    localAgents?: LocalAgentSource | undefined;
    presenceActivity?: PresenceActivity;
    outboxStorage?: OutboxStorage;
    readStateStorage?: ReadStateStorage;
    readPublisherLock?: ReadPublisherLock;
    deliveryTimeoutMs?: number;
}): {
    session: Readonly<{
        memberAdditions: Readonly<{
            snapshot: () => readonly Readonly<{
                channelId: string;
                pubkey: string;
                pending: boolean;
                confirmed: boolean;
                error?: string;
            }>[];
            subscribe(listener: () => void): () => void;
            add(channelId: string, pubkey: string): Promise<void>;
        }>;
        presence: {
            status(key: string): import("../presence/presence").PresenceStatus;
            limited: (key: string) => boolean;
            subscribe(key: string, listener: () => void, profile?: boolean): () => void;
            connected(value: boolean): void;
            clear: (publication?: boolean) => void;
            refresh: () => void;
            dispose(): void;
        };
        viewer: string | undefined;
        relayAuthor: string | undefined;
        audienceAuthorityCommunity: string | undefined;
        /** NIP-AP config artifacts: the relay's own verified answer, never merged
         * with live or local outgoing events or fed to any projection, and a
         * kind-45010 writer when the host has one. Each read starts fresh. */
        snapshotRead: ((filters: readonly Readonly<{
            [tag: `#${string}`]: readonly string[] | undefined;
            kinds?: readonly number[];
            ids?: readonly string[];
            limit: number;
            authors?: readonly string[];
            consistency?: "strong";
            artifact?: "current" | "history";
            offset?: number;
            until?: number;
            since?: number;
            "#h"?: readonly string[];
            "#d"?: readonly string[];
            "#p"?: readonly string[];
            top_level?: boolean;
            include_aux?: boolean;
            include_summaries?: boolean;
            before_id?: string;
            search?: string;
            search_mode?: "prefix" | "fulltext";
            search_sort?: "newest";
            page?: number;
            feed_types?: readonly string[];
            thread_window?: boolean;
            depth_limit?: number;
            thread_cursor?: number;
            thread_cursor_id?: string;
        }>[], { signal }: {
            signal?: AbortSignal | undefined;
        }) => Promise<readonly import("nostr-tools").VerifiedEvent[]>) | undefined;
        configArtifactWriter: import("./transport").RelayWriter | undefined;
        workflowAuthority: string | undefined;
        authorizeAgentLog: ((target: {
            id: string;
            pubkey: string;
            relayUrl: string;
        }, nonce: string) => Promise<string>) | undefined;
        authorizeGit: ((repository: string) => Promise<{
            repository: string;
            token: string;
        } | null>) | undefined;
        scope: string;
        /** Verified new live-route messages, after reconciliation. Never history or local intent. */
        subscribeIncoming(listener: IncomingListener): () => void;
        /** Verified, access-filtered live-phase events of any kind, after reconciliation.
         * Never finite reads or local intent, except the viewer's own messages in
         * a Solo chat this device is starting: those arrive here before the relay
         * has them, and their echo follows (see `hearStarting`). Replay only with
         * `replay`: the
         * recent history each subscription sends again before it goes live, as after
         * a reconnect, marked `replay` on its batch. Includes the viewer's own echoes.
         * Overlapping routes and replays can deliver one event more than once;
         * listeners dedupe by id. */
        subscribeLive(listener: LiveListener, options?: {
            replay?: boolean;
        }): () => void;
        typing: {
            snapshot: () => readonly Readonly<{
                channelId: string;
                threadRootId?: string;
                pubkey: string;
            }>[];
            subscribe: (listener: () => void) => () => void;
            send(channelId: string, threadRootId: string | undefined, signal: AbortSignal): Promise<void>;
        };
        /** Says the viewer's `agents` are online or offline, on the live socket:
         * ephemeral, so nothing is queued or retried. The relay keeps only the
         * agents the viewer owns. False when this session can never send it. */
        publishAgentPresence(status: "online" | "offline", agents: readonly string[], signal: AbortSignal): Promise<boolean>;
        channelCreation: Readonly<{
            available: boolean;
            subscribe: (listener: () => void) => () => void;
            snapshot: () => Readonly<{
                name: string;
                description?: string | undefined;
                visibility: "open" | "private";
                ttlSeconds?: number | undefined;
                labels?: readonly string[] | undefined;
                system?: true | undefined;
                setup?: import("../channel-templates/setup").ChannelSetup | undefined;
            }> | undefined;
            notices: () => readonly Readonly<{
                id: string;
                name: string;
                error: string;
            }>[];
            dismissNotice(id: string): void;
            create(input: ChannelCreationInput): Promise<string>;
        }>;
        channelKit: Readonly<{
            available: boolean;
            snapshot: () => {
                status: "idle" | "loading" | "ready" | "error" | "unavailable";
                entries: readonly import("../channel-templates/model").KitEntry[];
                error?: string | undefined;
                transient?: true | undefined;
            };
            subscribe(listener: () => void): () => void;
            ensure(): void;
            refresh: ({ after }?: {
                after?: boolean | undefined;
            }) => Promise<void>;
            save(value: import("../channel-templates/model").KitValue, expected: string | undefined, deleted?: boolean, operationSignal?: AbortSignal, resume?: import("../channel-templates/capability").Resume): Promise<string>;
        }>;
        canvas: Readonly<{
            available: boolean;
            read(channel: string, { strong }?: {
                strong?: boolean;
            }): Promise<import("nostr-tools").VerifiedEvent | undefined>;
            history(channel: string, cursor?: import("../channel-templates/capability").CanvasHistoryCursor): Promise<import("../channel-templates/capability").CanvasHistoryPage>;
            save(channel: string, content: string, expected: string | undefined): Promise<import("nostr-tools").VerifiedEvent>;
        }>;
        channelWrites: Readonly<{
            available: boolean;
            addAgents: (id: string, keys: readonly string[], active?: () => boolean) => Promise<void>;
            refreshMembership: (id: string) => Promise<Readonly<{
                id: string;
                name: string;
                description?: string | undefined;
                metadataPending?: boolean | undefined;
                visibility?: "public" | "private" | undefined;
                preview?: string | undefined;
                lastActivityAt?: number | undefined;
                activityKnown?: true;
                readOnly?: true;
                cached?: true;
                pending?: true;
                hidden?: true;
                channelType?: "stream" | "forum" | "dm" | "solo" | "system";
                private?: true;
                parentChannelId?: string | undefined;
                huddle?: true;
                updatedAt?: number;
                archived?: true;
                ttlSeconds?: number;
                members?: readonly string[];
                labels?: readonly string[];
                creator?: string;
                createdAt?: number;
                participants?: readonly string[];
            }>>;
            memberChannels: (pubkey: string, caller: AbortSignal) => Promise<string[]>;
            listsMember: (id: string, pubkey: string, caller: AbortSignal) => Promise<boolean>;
            createChannel(id: string, title: string, visibility: "open" | "private", description?: string, ttlSeconds?: number, active?: () => boolean, options?: Readonly<{
                labels?: readonly string[] | undefined;
                system?: boolean | undefined;
            }>): string;
            create(id: string, title: string, ttlSeconds?: number, named?: boolean, members?: readonly string[]): string;
            start(id: string, title: string, members: readonly string[], ttlSeconds?: number, named?: boolean, setup?: {
                canvas: string;
                apply(): Promise<unknown>;
            }): {
                create: string;
                ready: Promise<void>;
            };
            starting(id: string): Promise<void> | undefined;
            startingCanvas(id: string): string | undefined;
            failed(id: string): boolean;
            discardFailed(id: string): Promise<void>;
            delivered: (id: string, active?: () => boolean, addition?: boolean, retry?: boolean) => Promise<void>;
            refresh: (id: string, expected?: {
                member?: string;
                members?: readonly string[];
                system?: boolean | undefined;
            }, soloOnly?: boolean) => Promise<void>;
        }>;
        directMessages: Readonly<{
            available: boolean;
            subscribeOpened(listener: (id: string) => void): () => undefined;
            people(query: string, page: number, signal: AbortSignal): Promise<{
                people: {
                    pubkey: string;
                    name: string;
                    username?: string;
                    picture?: string;
                    isAgent?: true;
                }[];
                hasMore: boolean;
            }>;
            open(pubkeys: readonly string[], signal: AbortSignal): Promise<string>;
            delivery(id: string): import("./outbox").Delivery | undefined;
            delivered(id: string, channelId: string, signal: AbortSignal): Promise<void>;
        }>;
        unread: import("./unread").UnreadCapability;
        sidebarPreferences: Readonly<{
            available: boolean;
            readonly sectionRemovalWritable: any;
            removeSection(sectionId: string, callerSignal?: AbortSignal): Promise<void> | Promise<import("./sidebar-preferences").SidebarPreferences>;
            readonly sectionCreationWritable: boolean;
            createSection(section: Readonly<{
                id: string;
                name: string;
            }>): Promise<void>;
            readonly sectionOrderWritable: boolean;
            reorderSections(sectionId: string, sectionIds: readonly string[]): Promise<import("./sidebar-preferences").SidebarPreferences>;
            dismissOrderError(): void;
            dismissSortError(group: string): void;
            readonly sortWritable: boolean;
            setSort(group: string, mode: import("./sidebar-preferences").SidebarSortMode, sectionIds: readonly string[], signal?: AbortSignal): Promise<Readonly<Record<string, import("./sidebar-preferences").SidebarSortMode>>>;
            dismissFilterError(group: string): void;
            readonly filterWritable: boolean;
            setFilter(group: string, mode: import("./sidebar-preferences").SidebarFilterMode, sectionIds: readonly string[], signal?: AbortSignal, activeWindowSeconds?: number | null): Promise<Readonly<{
                filters: Readonly<Record<string, import("./sidebar-preferences").SidebarFilterMode>>;
                activeWindowSeconds: Readonly<Record<string, number>>;
            }>>;
            readonly muteWritable: boolean;
            setMute(channelId: string, muted: boolean, signal?: AbortSignal): Promise<readonly string[]>;
            retryMove(channelId: string): Promise<import("./sidebar-preferences").SidebarPreferences>;
            dismissMoveError(channelId: string): void;
            readonly writable: boolean;
            assign(channelId: string, sectionId?: string, signal?: AbortSignal): Promise<import("./sidebar-preferences").SidebarPreferences>;
            createAndAssign(channelId: string, section: {
                id: string;
                name: string;
            }, signal?: AbortSignal): Promise<import("./sidebar-preferences").SidebarPreferences>;
            readonly removeSectionWritable: boolean;
            readonly starWritable: boolean;
            setStar(channelId: string, starred: boolean, signal?: AbortSignal): Promise<readonly string[]>;
            read: (signal?: AbortSignal) => Promise<import("./sidebar-preferences").SidebarPreferences>;
            snapshot: () => Readonly<{
                status: "idle" | "loading" | "ready" | "error" | "unsupported";
                data?: import("./sidebar-preferences").SidebarPreferences;
                error?: string;
                transient?: true;
                cached?: true;
                sortErrors?: readonly Readonly<{
                    group: string;
                    mode: import("./sidebar-preferences").SidebarSortMode;
                    error: string;
                }>[];
                filterErrors?: readonly Readonly<{
                    group: string;
                    mode: import("./sidebar-preferences").SidebarFilterMode;
                    activeWindowSeconds?: number | null;
                    error: string;
                }>[];
                moves?: readonly (Readonly<{
                    id: number;
                    channelId: string;
                    destination: Omit<Readonly<{
                        channelId: string;
                        sectionId?: string;
                        createSection?: Readonly<{
                            id: string;
                            name: string;
                        }>;
                    }>, "channelId"> | {
                        starred: true;
                    };
                }> & {
                    pending: boolean;
                    error?: string;
                })[];
                orderError?: Readonly<{
                    sectionId: string;
                    sectionIds: readonly string[];
                    error: string;
                }>;
            }>;
            subscribe(listener: () => void): () => void;
            ensure: () => Promise<void>;
            refresh: () => Promise<void>;
        }>;
        soloPreferences: Readonly<{
            available: boolean;
            readonly sectionRemovalWritable: any;
            removeSection(sectionId: string, callerSignal?: AbortSignal): Promise<void> | Promise<import("./sidebar-preferences").SidebarPreferences>;
            readonly sectionCreationWritable: boolean;
            createSection(section: Readonly<{
                id: string;
                name: string;
            }>): Promise<void>;
            readonly sectionOrderWritable: boolean;
            reorderSections(sectionId: string, sectionIds: readonly string[]): Promise<import("./sidebar-preferences").SidebarPreferences>;
            dismissOrderError(): void;
            dismissSortError(group: string): void;
            readonly sortWritable: boolean;
            setSort(group: string, mode: import("./sidebar-preferences").SidebarSortMode, sectionIds: readonly string[], signal?: AbortSignal): Promise<Readonly<Record<string, import("./sidebar-preferences").SidebarSortMode>>>;
            dismissFilterError(group: string): void;
            readonly filterWritable: boolean;
            setFilter(group: string, mode: import("./sidebar-preferences").SidebarFilterMode, sectionIds: readonly string[], signal?: AbortSignal, activeWindowSeconds?: number | null): Promise<Readonly<{
                filters: Readonly<Record<string, import("./sidebar-preferences").SidebarFilterMode>>;
                activeWindowSeconds: Readonly<Record<string, number>>;
            }>>;
            readonly muteWritable: boolean;
            setMute(channelId: string, muted: boolean, signal?: AbortSignal): Promise<readonly string[]>;
            retryMove(channelId: string): Promise<import("./sidebar-preferences").SidebarPreferences>;
            dismissMoveError(channelId: string): void;
            readonly writable: boolean;
            assign(channelId: string, sectionId?: string, signal?: AbortSignal): Promise<import("./sidebar-preferences").SidebarPreferences>;
            createAndAssign(channelId: string, section: {
                id: string;
                name: string;
            }, signal?: AbortSignal): Promise<import("./sidebar-preferences").SidebarPreferences>;
            readonly removeSectionWritable: boolean;
            readonly starWritable: boolean;
            setStar(channelId: string, starred: boolean, signal?: AbortSignal): Promise<readonly string[]>;
            read: (signal?: AbortSignal) => Promise<import("./sidebar-preferences").SidebarPreferences>;
            snapshot: () => Readonly<{
                status: "idle" | "loading" | "ready" | "error" | "unsupported";
                data?: import("./sidebar-preferences").SidebarPreferences;
                error?: string;
                transient?: true;
                cached?: true;
                sortErrors?: readonly Readonly<{
                    group: string;
                    mode: import("./sidebar-preferences").SidebarSortMode;
                    error: string;
                }>[];
                filterErrors?: readonly Readonly<{
                    group: string;
                    mode: import("./sidebar-preferences").SidebarFilterMode;
                    activeWindowSeconds?: number | null;
                    error: string;
                }>[];
                moves?: readonly (Readonly<{
                    id: number;
                    channelId: string;
                    destination: Omit<Readonly<{
                        channelId: string;
                        sectionId?: string;
                        createSection?: Readonly<{
                            id: string;
                            name: string;
                        }>;
                    }>, "channelId"> | {
                        starred: true;
                    };
                }> & {
                    pending: boolean;
                    error?: string;
                })[];
                orderError?: Readonly<{
                    sectionId: string;
                    sectionIds: readonly string[];
                    error: string;
                }>;
            }>;
            subscribe(listener: () => void): () => void;
            ensure: () => Promise<void>;
            refresh: () => Promise<void>;
        }>;
        reminders: Readonly<{
            snapshot(): import("./reminders").RemindersState;
            subscribe(listener: () => void): () => void;
            refresh(): Promise<void>;
            create(target: import("./reminders").ReminderTarget, notBefore: number, note?: string): Promise<void>;
            snooze(id: string, notBefore: number): Promise<void>;
            complete(id: string): Promise<void>;
            cancel(id: string): Promise<void>;
        }> | undefined;
        live: Readonly<{
            snapshot: () => Readonly<{
                status: "unavailable" | "connecting" | "connected" | "retrying" | "error";
                routes: readonly import("./live").LiveRoute[];
                error?: string;
                authRefusal?: string;
            }> & Readonly<{
                roster: ReturnType<() => Readonly<{
                    state: "idle" | "pending" | "verified" | "deferred" | "error";
                    error?: string;
                    transient?: true;
                }>>;
                heads: readonly Readonly<{
                    channelId: string;
                    state: "pending" | "verified" | "deferred" | "error";
                    error?: string;
                    transient?: true;
                }>[];
                /** Public previews closed by the relay, awaiting a metadata recheck. A
                 * failed recheck keeps them suspended; recovery retries it. */
                previews?: "checking" | "suspended";
            }>;
            subscribe(listener: () => void): () => void;
            retry(): void;
        }>;
        /** The one automatic retry owner for background reads. Undefined offline. */
        recovery: Readonly<{
            snapshot(): import("./recovery").RecoverySnapshot;
            subscribe(listener: () => void): () => void;
            retryNow(except?: RecoverySource): void;
            dispose(): void;
        }> | undefined;
        profiling: Readonly<{
            start: (stage: string, id: string, count?: number) => (outcome?: "ok" | "error") => void;
            record: (sample: import("./profiling").RelayTiming) => void;
            snapshot: () => readonly Readonly<{
                stage: string;
                id: string;
                start: number;
                duration: number;
                outcome: "ok" | "error" | "pending";
                count?: number;
            }>[];
            clear: () => void;
            measure<T>(stage: string, id: string, work: () => T, count?: number): T;
            measureAsync<T>(stage: string, id: string, work: () => Promise<T>): Promise<T>;
        }>;
        attachments: Readonly<{
            upload(file: File, channelId: string, signal: AbortSignal, progress?: UploadProgress): Promise<Readonly<{
                name: string;
                url: string;
                type: string;
                size: number;
                sha256: string;
                voice?: Readonly<{
                    duration: number;
                    waveform: readonly number[];
                }>;
            }>>;
            uploadForNewChat?: (file: File, signal: AbortSignal, progress?: UploadProgress) => Promise<Readonly<{
                name: string;
                url: string;
                type: string;
                size: number;
                sha256: string;
                voice?: Readonly<{
                    duration: number;
                    waveform: readonly number[];
                }>;
            }>>;
        }> | undefined;
        feedbackUpload: Readonly<{
            origin: string;
            upload(file: File, signal: AbortSignal): Promise<UploadedAttachment>;
        }> | undefined;
        messages: Readonly<{
            send(channelId: string, content: string, mentions?: readonly string[], attachments?: readonly UploadedAttachment[], recovery?: import("./outbox").OutboxRecovery, references?: readonly string[], picks?: import("./messages").MentionPicks, sharedSessions?: readonly string[]): string;
            sendToChannel(row: import("./contracts").ChannelMessage, root?: import("./contracts").ChannelMessage): string;
            reply(channelId: string, rootId: string, content: string, mentions?: readonly string[], attachments?: readonly UploadedAttachment[], parentId?: string, references?: readonly string[], picks?: import("./messages").MentionPicks, sharedSessions?: readonly string[]): string;
            edit(messageId: string, content: string, attachmentSourceId: string): string;
            react(messageId: string, content: string, emoji?: import("./emoji").CustomEmoji): string;
            remove(eventIds: readonly string[], authorization?: import("./messages").AgentOwnerAuthorization): string;
            report: ((messageId: string, type: import("./messages").ReportType, note?: string) => Promise<void>) | undefined;
            reactionTarget(event: Pick<EventData, "kind" | "tags">): string | undefined;
            retry(id: string): void;
        }>;
        /** An owned bounded thread reader. Dispose on close; the session retains access/lifetime authority. */
        thread(channelId: string, messageId: string, options?: {
            exact?: boolean;
        }): {
            snapshot: () => Readonly<{
                status: "idle" | "loading" | "ready" | "error";
                root: import("./contracts").ChannelMessage | undefined;
                replies: readonly import("./contracts").ChannelMessage[];
                error: string | undefined;
                canLoadMore: boolean;
                limited: boolean;
                direction?: "older" | "forward";
                readKind?: "older" | "refresh" | undefined;
                target?: import("./contracts").ChannelMessage | undefined;
                targetStatus?: "loading" | "ready" | "unavailable" | "error" | undefined;
            }>;
            subscribe(listener: () => void): () => void;
            retarget: (id: string, signal: AbortSignal) => Promise<import("./threads").ThreadRetarget>;
            refresh: () => Promise<void>;
            loadMore: () => Promise<void>;
            dispose: () => void;
        };
        channels: Readonly<{
            get?(channelId: string): ChannelSummary | undefined;
            resolve?(channelIds: readonly string[], options?: import("./contracts").ChannelReadOptions): Promise<void>;
            searchPublic?(query: string, options?: ReadOptions & {
                limit?: number;
                exact?: boolean;
            }): Promise<import("./contracts").PublicChannelSearch>;
            findLabeled?(query: Readonly<{
                creator: string;
                label: string;
            }>, options?: import("./contracts").ChannelReadOptions): Promise<readonly ChannelSummary[]>;
            matchPublic?(query: string, options?: {
                exact?: boolean;
            }): readonly ChannelSummary[];
            describe?(channelId: string): import("./contracts").ChannelReference;
            refer?(channelId: string): () => void;
            refreshRoster?(channelId: string, options?: import("./contracts").ChannelReadOptions): Promise<boolean>;
            start?(channel: Readonly<{
                id: string;
                name: string;
                members: readonly string[];
                labels: readonly string[];
                ttlSeconds?: number | undefined;
            }>): void;
            abandon?(channelId: string): void;
            window(channelId: string): import("./contracts").ChannelWindow;
            subscribeWindow(channelId: string, listener: () => void): () => void;
            ensureList(): void;
            ensure(channelId: string): void;
            loadOlder(channelId: string): void;
            refresh?(channelId: string): void;
            prepare?(channelId: string): void;
            warm?(preferred: readonly string[]): void;
            refreshList?(options?: Pick<import("./contracts").ChannelReadOptions, "consistency">): void;
            list(): Readonly<{
                status: import("./contracts").ListStatus;
                coverage?: "partial";
                asOf?: number;
                activityStatus?: "idle" | "loading" | "ready" | "error" | "unavailable";
                channels: readonly ChannelSummary[];
                error?: string;
            }>;
            subscribeList(listener: () => void): () => void;
        }>;
        names: import("../identity-names/service").IdentityNameView & {
            dispose(): void;
        };
        profiles: import("./profile-directory").ProfileQueries;
        emoji: Readonly<{
            snapshot: () => Readonly<{
                status: "idle" | "loading" | "ready" | "error";
                entries: readonly import("./emoji").CustomEmoji[];
                mine: readonly import("./emoji").CustomEmoji[];
                error?: string | undefined;
            }>;
            subscribe(listener: () => void): () => void;
            ensure: () => Promise<void>;
            refresh: () => Promise<void>;
            remove?: (name: string) => Promise<void>;
            upload?: (file: File, signal: AbortSignal) => Promise<UploadedAttachment>;
            add?: (name: string, url: string) => Promise<string>;
        }>;
        statuses: Readonly<{
            snapshot: () => ReadonlyMap<string, Readonly<{
                userId: string;
                text: string;
                emoji: string;
                updatedAt: number;
                expiresAt?: number;
            }>>;
            subscribe(listener: () => void): () => void;
            watch: (ids: readonly string[]) => () => void;
            current(userId: string): Promise<Readonly<{
                userId: string;
                text: string;
                emoji: string;
                updatedAt: number;
                expiresAt?: number;
            }> | undefined>;
            save: (input: import("./user-status").StatusInput) => Promise<void>;
            writable: boolean;
            refresh(): void;
        }>;
        agentLibrary: Readonly<{
            snapshot: () => import("../agents/library").AgentLibrarySnapshot;
            refresh: () => Promise<void>;
            retain({ refresh: refreshOnRetain }?: {
                refresh?: boolean | undefined;
            }): () => void;
            subscribe(listener: () => void): () => void;
        }>;
        agentChoices: Readonly<{
            snapshot: () => import("../agents/choices").AgentChoicesSnapshot;
            subscribe(listener: () => void): () => void;
            ensure(includeLegacy?: boolean, archive?: boolean): void;
            refresh(source?: "templates" | boolean): Promise<void>;
            retain(): () => void;
        }>;
        inboxFeed: Readonly<{
            snapshot: () => Readonly<{
                status: "idle" | "loading" | "ready" | "error";
                error?: string | undefined;
                incomplete: readonly string[];
            }>;
            subscribe(listener: () => void): () => void;
            ensure: () => Promise<void>;
            refresh: () => Promise<void>;
            stale(): void;
            reconnect(): void;
            clear: () => void;
            purge: () => void;
            dispose(): void;
        }>;
        workflows: Readonly<import("../workflows/types").WorkflowCapability>;
        repositories: {
            peekHome: (channelId: string) => import("../repos/destinations").RepositoryHome | undefined;
            clearHomes(): void;
            home(channelId: string, signal: AbortSignal): Promise<import("../repos/destinations").RepositoryHome>;
            load(route: import("../repos/routes").EntityRoute, signal: AbortSignal): Promise<import("../repos/destinations").EntityDetail>;
        };
        projectGit: {
            read(input: GitRead, signal: AbortSignal): Promise<import("../repos/git").GitSnapshot>;
        } | undefined;
        channelLifecycle: import("./channel-lifecycle").ChannelLifecycleCapability;
        channelDetails: import("./channel-details").ChannelDetailsCapability;
        memberAdministration: Readonly<{
            available: boolean;
            snapshot: (id: string) => Readonly<{
                status: "idle" | "loading" | "ready" | "error";
                authority: import("../channel-members/administration-protocol").MemberAuthority;
                operation?: Readonly<{
                    change: import("../channel-members/administration-protocol").MemberChange;
                    status: "pending" | "uncertain" | "confirmed" | "failed";
                }>;
                error?: string | undefined;
            }>;
            subscribe(listener: () => void): () => void;
            refresh(id: string): Promise<void>;
            run(id: string, intent: import("../channel-members/administration-protocol").MemberChange): Promise<void>;
        }>;
        agentActivity: Readonly<{
            snapshot: () => Readonly<{
                status: "unavailable" | "disabled" | "connecting" | "listening" | "interrupted";
                records: readonly (Readonly<{
                    id: string;
                    agent: string;
                    createdAt: number;
                    plaintext: string;
                    envelope?: RelayEvent;
                }> & Readonly<{
                    receivedAt: number;
                    kind: string;
                    channelIds: readonly string[];
                }>)[];
                turns: readonly import("../agents/activity").ActivityTurn[];
                local?: readonly import("../agents/local-activity").LocalWork[];
                typing: readonly Readonly<{
                    agent: string;
                    channelId: string;
                    threadRootId: string | undefined;
                    timestamp: number;
                    startedAt: number;
                    working: boolean;
                    expiresAt: number;
                }>[];
                trimmed: number;
            }>;
            dismissError(agent: string, channelId: string, messageId: string): boolean;
            interrupt(agent: string, channelId: string, messageId: string): Promise<void>;
            workingSnapshot: () => string;
            subscribeWorking(listener: () => void): () => void;
            subscribe(listener: () => void): () => void;
            activate(): () => void;
        }>;
        agentMemories: Readonly<{
            open: (agent: string) => {
                snapshot: () => Readonly<{
                    status: "idle" | "blocked" | "loading" | "ready" | "error" | "denied" | "unavailable";
                    listing?: import("../agents/memory").MemoryListing;
                }>;
                subscribe(listener: () => void): () => void;
                refresh(): Promise<void>;
                clear: () => void;
                dispose(): void;
            };
            read: (agent: string, signal: AbortSignal, slug?: string) => Promise<Readonly<{
                partial: boolean;
                entries: readonly import("../agents/memory").MemoryEntry[];
            }>>;
        }>;
        archives: Readonly<{
            snapshot: () => Readonly<{
                status: "unavailable" | "idle" | "loading" | "ready" | "error";
                archived: readonly string[];
                eventId?: string;
                createdAt?: number;
                readAt?: number;
                error?: string;
            }>;
            subscribe(listener: () => void): () => void;
            state: (pubkey: string) => "unknown" | "archived" | "not-archived";
            ensure: () => Promise<void>;
            refresh: () => Promise<void>;
            supported: boolean;
            writable: boolean;
            consent: (target: string, signal: AbortSignal) => Promise<{
                auth?: readonly string[];
                admin?: true;
            } | null>;
            request: (action: import("./identity-archive-protocol").IdentityArchiveAction, target: string, caller?: AbortSignal) => Promise<void>;
        }>;
        media: (url: string, size?: "small") => string | undefined;
        /** A plugin may request writes from this same interface when the host supports them. */
        outbox: import("./outbox").Outbox | undefined;
        /** People by profile name only; see `createProfileSearch`. */
        searchProfiles: (query: string, { limit, page, signal, priority }: import("./profile-search").ProfileSearchOptions, reader?: RelayReader) => Promise<readonly RelayEvent[]>;
        /** A fresh verified remote page under the normal access guards, without
         * merging live observations or local outbox intent into paging evidence. */
        readRemote(filters: readonly ReadFilter[], settings?: ReadOptions): Promise<readonly import("nostr-tools").VerifiedEvent[]>;
        read(filters: readonly ReadFilter[], settings?: ReadOptions): Promise<readonly VisibleEvent[]>;
        /** Transport-page count precedes visibility filtering and local/live projection. */
        readPage(filters: readonly ReadFilter[], settings?: ReadOptions): Promise<{
            events: readonly VisibleEvent[];
            relayCount: number;
        }>;
        /** Whether read() search filters may ask for `search_sort: "newest"`. */
        searchSort: boolean;
        /** An owned retained event view, not a replacement query snapshot. Limits bound
         * requests, not retained results. Ranked search/feed filters require read().
         * Subscribe, refresh and dispose with the plugin's scope. */
        observe(input: readonly ReadFilter[]): {
            snapshot: () => Readonly<{
                status: "idle" | "loading" | "ready" | "error";
                events: readonly VisibleEvent[];
                error?: string | undefined;
            }>;
            subscribe(listener: () => void): () => void;
            refresh(): Promise<void>;
            dispose: () => void;
        };
    }>;
    restore(): Promise<void>;
    clearCache(): Promise<void>;
    dispose(): void;
    retainedChannels: () => string[];
    diagnostics: () => {
        heads: {
            entries: number;
            bytes: number;
        };
        media: {
            active: number;
            queued: number;
            prefetched: number;
            decoded: number;
        };
        historyRows: number;
        profiles: {
            entries: number;
            bytes: number;
        };
    };
};
export type RelaySession = ReturnType<typeof createRelaySession>["session"];
