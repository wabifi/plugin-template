import type { EventData } from "./events";
import type { OutgoingEvent } from "./outbox";
import type { RelayProfiler } from "./profiling";
import { MessageClock } from "./message-order";
/** Per-window indexes. New evidence folds only affected messages; status updates never fold. */
export declare class MessageProjection {
    private channelId;
    private relayAuthor;
    private profiling;
    private clock;
    private signingAuthority?;
    private inputs;
    private overlays;
    private messages;
    private deliveries;
    private rows;
    constructor(channelId: string, relayAuthor: string, profiling: RelayProfiler, clock?: MessageClock, signingAuthority?: string | undefined);
    snapshot(): readonly Readonly<{
        id: string;
        channelId: string;
        delivery?: import("./outbox").Delivery | undefined;
        deliveryError?: string | undefined;
        authorId: string;
        signerId?: string | undefined;
        workflowOwnerId?: string | undefined;
        createdAt: number;
        createdAtMs?: number;
        content: string;
        sourceContent?: string;
        agentEnvelope?: true;
        audience?: "agents";
        diff?: Readonly<{
            filePath?: string | undefined;
            repoUrl?: string | undefined;
            commitSha?: string | undefined;
            description?: string | undefined;
            truncated: boolean;
        }>;
        membership?: import("./contracts").MembershipChange;
        huddle?: Readonly<{
            room: string;
            state: "started" | "ended";
            endedAt?: number;
        }>;
        edited?: true;
        attachmentSeams?: readonly number[];
        mentions: readonly string[];
        mentionReferences?: readonly string[];
        attachmentSourceId?: string;
        attachments: readonly import("./contracts").Attachment[];
        emoji?: readonly import("./emoji").CustomEmoji[];
        reactions: readonly import("./contracts").MessageReaction[];
        threadRootId?: string | undefined;
        replyParentId?: string | undefined;
        sentFromThread?: Readonly<{
            rootId: string;
            excerpt?: string | undefined;
        }> | undefined;
        replyCount: number;
        participants: readonly string[];
    }>[];
    reconcile(events: readonly EventData[], operations: readonly OutgoingEvent[]): readonly Readonly<{
        id: string;
        channelId: string;
        delivery?: import("./outbox").Delivery | undefined;
        deliveryError?: string | undefined;
        authorId: string;
        signerId?: string | undefined;
        workflowOwnerId?: string | undefined;
        createdAt: number;
        createdAtMs?: number;
        content: string;
        sourceContent?: string;
        agentEnvelope?: true;
        audience?: "agents";
        diff?: Readonly<{
            filePath?: string | undefined;
            repoUrl?: string | undefined;
            commitSha?: string | undefined;
            description?: string | undefined;
            truncated: boolean;
        }>;
        membership?: import("./contracts").MembershipChange;
        huddle?: Readonly<{
            room: string;
            state: "started" | "ended";
            endedAt?: number;
        }>;
        edited?: true;
        attachmentSeams?: readonly number[];
        mentions: readonly string[];
        mentionReferences?: readonly string[];
        attachmentSourceId?: string;
        attachments: readonly import("./contracts").Attachment[];
        emoji?: readonly import("./emoji").CustomEmoji[];
        reactions: readonly import("./contracts").MessageReaction[];
        threadRootId?: string | undefined;
        replyParentId?: string | undefined;
        sentFromThread?: Readonly<{
            rootId: string;
            excerpt?: string | undefined;
        }> | undefined;
        replyCount: number;
        participants: readonly string[];
    }>[];
    private overlayIds;
    private withDelivery;
    private delivery;
}
