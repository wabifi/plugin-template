import { type RelayEvent } from "./events";
import { type ReadState } from "./read-state-model";
export type ReadJournal = Readonly<{
    version: 1;
    slot: string;
    clientId: string;
    state: ReadState;
    /** Explicitly local-only intent; the counter fences older reading handles. */
    localUnread: Readonly<Record<string, number>>;
    /** Local interaction order, bounded with retained frontier hints. */
    recent?: Readonly<Record<string, number>>;
    /** Local-only evicted receipts, deleted with this partition even by old builds. */
    reserve?: Readonly<Record<string, number>>;
    /** Local-only: the channel of each message that a kept mark names (see
     * `markMessage`), taken from a signed event. A mark does not carry its
     * channel, so this lets a channel mark cover it while the message is not
     * loaded. */
    homes?: Readonly<Record<string, string>>;
    revision: number;
    acceptedRevision: number;
    lastCreatedAt: number;
    pending?: Readonly<{
        event: RelayEvent;
        revision: number;
    }>;
}>;
/** Mutations run against the latest record in one strict transaction (including other tabs). */
export interface ReadStateStorage {
    update(change: (current: ReadJournal | undefined) => ReadJournal): Promise<ReadJournal>;
    close(): void;
}
export declare function newReadJournal(): ReadJournal;
/** Storage is untrusted. Corrupt intent is an error, never an empty journal to overwrite. */
export declare function readJournal(raw: unknown, viewer: string): ReadJournal;
/** Forgets one partition's journal after its session is disposed, so a left
 * community's read markers do not outlive the membership on this device. */
export declare function purgeReadStateStorage(scope: string): Promise<void>;
export declare function browserReadStateStorage(scope: string, viewer: string): ReadStateStorage;
