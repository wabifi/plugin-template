/** Explicit thread choices on this device, keyed `channel:root`: `true`
 * follows without replying, `false` unfollows even after participating.
 * Threads without a choice keep automatic participation. */
export type ThreadFollows = ReadonlyMap<string, boolean>;
export type ThreadFollowStorage = Readonly<{
    read(): ThreadFollows;
    /** Throws when the choices were not saved. */
    write(choices: ThreadFollows): void;
    /** Another window saved new choices. */
    subscribe(listener: () => void): () => void;
}>;
/** Newest choices win, as the reference keeps its newest roots. */
export declare const THREAD_FOLLOW_LIMIT = 1000;
export declare function memoryThreadFollows(): ThreadFollowStorage;
/** Device-local and partitioned by community and viewer, like read state. */
export declare function browserThreadFollows(scope: string): ThreadFollowStorage;
/** Forgets one community's thread choices once the viewer has left it. */
export declare function forgetThreadFollows(scope: string): void;
