export { threadReference } from "./thread-reference";
import type { ChannelMessage } from "./contracts";
import type { RelayEvent } from "./events";
import type { LocalEvents } from "./outbox";
import type { RelayReader } from "./reader";
import { MessageClock } from "./message-order";
export type ThreadSnapshot = Readonly<{
    status: "idle" | "loading" | "ready" | "error";
    root: ChannelMessage | undefined;
    replies: readonly ChannelMessage[];
    error: string | undefined;
    /** Continuation is possible, not a claim about total thread size or exhaustion. */
    canLoadMore: boolean;
    limited: boolean;
    /** Older pages are demand-loaded; forward is the legacy bounded walk. */
    direction?: "older" | "forward";
    /** The in-flight or failed read, distinct from the traversal direction. */
    readKind?: "older" | "refresh" | undefined;
    /** Exact navigation target, folded independently of bounded thread traversal. */
    target?: ChannelMessage | undefined;
    targetStatus?: "loading" | "ready" | "unavailable" | "error" | undefined;
}>;
export type ThreadRetarget = "selected" | "different" | "unavailable" | "error" | "cancelled";
export type ThreadView = {
    snapshot(): ThreadSnapshot;
    subscribe(listener: () => void): () => void;
    refresh(): Promise<void>;
    loadMore(): Promise<void>;
    /** Change exact selection only when verified ancestry belongs to this thread. */
    retarget(messageId: string, signal: AbortSignal): Promise<ThreadRetarget>;
    dispose(): void;
};
/** Session-owned evidence. Finite page cursors NEVER come from the live/local display union. */
export declare function createThreadView({ channelId, messageId, relayAuthor, signingAuthority, reader, targetReader, admitTarget, seed, local, canAccess, visible, notify, exact, admit, clock, }: {
    channelId: string;
    messageId: string;
    relayAuthor: string;
    /** Explicit NIP-11 self; only it may attribute messages to others. */
    signingAuthority?: string | undefined;
    reader: RelayReader;
    targetReader?: RelayReader;
    admitTarget?: (events: readonly RelayEvent[]) => readonly RelayEvent[];
    seed: RelayEvent | undefined;
    local: LocalEvents | undefined;
    canAccess(): boolean;
    visible(events: readonly RelayEvent[]): readonly RelayEvent[];
    notify(listener: () => void): void;
    exact?: boolean;
    /** The session's send clock; rendered replies raise its channel watermark. */
    clock?: MessageClock;
    /** Exact finite reads enter session reconciliation only after a complete fold. */
    admit?: ((events: readonly RelayEvent[]) => readonly RelayEvent[]) | undefined;
}): {
    channelId: string;
    event: (id: string) => import("nostr-tools").VerifiedEvent | undefined;
    receive: (events: readonly RelayEvent[]) => void;
    purge: (clear?: boolean) => void;
    changed: () => void;
    view: {
        snapshot: () => Readonly<{
            status: "idle" | "loading" | "ready" | "error";
            root: ChannelMessage | undefined;
            replies: readonly ChannelMessage[];
            error: string | undefined;
            /** Continuation is possible, not a claim about total thread size or exhaustion. */
            canLoadMore: boolean;
            limited: boolean;
            /** Older pages are demand-loaded; forward is the legacy bounded walk. */
            direction?: "older" | "forward";
            /** The in-flight or failed read, distinct from the traversal direction. */
            readKind?: "older" | "refresh" | undefined;
            /** Exact navigation target, folded independently of bounded thread traversal. */
            target?: ChannelMessage | undefined;
            targetStatus?: "loading" | "ready" | "unavailable" | "error" | undefined;
        }>;
        subscribe(listener: () => void): () => void;
        retarget: (id: string, signal: AbortSignal) => Promise<ThreadRetarget>;
        refresh: () => Promise<void>;
        loadMore: () => Promise<void>;
        dispose(): void;
    };
};
