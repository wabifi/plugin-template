import type { ReminderHost } from "./reminders";
import { type MemoryReader } from "../agents/memory";
import { type AttachmentUpload } from "./attachments";
import type { ChannelKitHost } from "../channel-templates/host";
import { type RepoGit } from "../repos/git";
import type { WorkflowHost } from "../workflows/host";
import { type ReadStateHost } from "./read-state-host";
import type { AgentLibraryReader } from "../agents/library";
import { type SidebarAssignmentMutator, type SidebarSectionOrderMutator, type SidebarSectionRemovalMutator, type SidebarStarMutator, type SidebarSortMutator, type SidebarFilterMutator, type SidebarDecoder, type SidebarMuteMutator } from "./sidebar-preferences";
import { type RelayProfiler } from "./profiling";
import { type LiveCallbacks, type LiveSubscription } from "./live";
import type { EventTemplate, VerifiedEvent } from "nostr-tools";
import { type ReadFilter, type RelayEvent } from "./events";
/** Relay connection. Implementations verify signatures; callers never see raw JSON. */
export interface RelayWriter {
    readonly kinds?: readonly number[];
    sign(event: EventTemplate, signal: AbortSignal): Promise<RelayEvent>;
    /** Accepted receipt text is ephemeral; callers must never journal it. */
    publish(event: RelayEvent, signal: AbortSignal): Promise<string> | Promise<void>;
}
export interface ReadTransport {
    readonly projectGit?: RepoGit;
    readonly readAgentMemories?: MemoryReader;
    /** Session-scoped owner proof, not an arbitrary signing capability. */
    readonly authorizeAgentLog?: (target: {
        id: string;
        pubkey: string;
        relayUrl: string;
    }, nonce: string) => Promise<string>;
    /** One-repository Git authorization for this community's Buzz git; null for any other URL.
     * The token is the NIP-98 value after `Authorization: Nostr `. */
    readonly authorizeGit?: (repository: string) => Promise<{
        repository: string;
        token: string;
    } | null>;
    readonly uploadAttachment?: AttachmentUpload;
    /** Host-owned idempotent DM opening. The session verifies membership before use. */
    readonly openDirectMessage?: (pubkeys: readonly string[], signal: AbortSignal) => Promise<string>;
    readonly workflows?: WorkflowHost;
    /** Narrow lifecycle signer/publisher; never supplied to the message outbox. */
    readonly channelLifecycle?: RelayWriter;
    /** Name/about/private-only metadata writer, separate from lifecycle and outbox. */
    readonly channelDetails?: RelayWriter;
    readonly memberAdministration?: RelayWriter;
    /** NIP-AR kind-45010 config artifacts only; never supplied to the outbox. */
    readonly configArtifacts?: RelayWriter;
    /** Narrow NIP-IA 9035/9036 signer/publisher; never supplied to the message outbox. */
    readonly identityArchive?: RelayWriter;
    /** Purpose-bound observer decoding on the shared host live stream. */
    readonly agentActivity?: boolean;
    /** Explicit relay-advertised session command support. */
    /** Host-projected local library; display only, never relay authority. */
    readonly readAgentLibrary?: AgentLibraryReader;
    /** Host-only decoder of the viewer's signed sidebar preference coordinates. */
    readonly decodeSidebarPreferences?: SidebarDecoder;
    readonly writeSidebarSort?: SidebarSortMutator;
    readonly writeSidebarFilter?: SidebarFilterMutator;
    readonly readState?: ReadStateHost;
    /** Purpose-bound NIP-ER codec; never a general NIP-44 or signing primitive. */
    readonly reminders?: ReminderHost;
    readonly channelKit?: ChannelKitHost;
    /** The relay advertises NIP-CL (`nip-cl` in NIP-11 `supported_extensions`):
     * it keeps channel labels and answers label lookups. */
    readonly channelIdentity?: true;
    /** The relay advertises `buzz-search-sort`: bridge search accepts
     * `search_sort: "newest"`. Older relays silently rank by relevance. */
    readonly searchSort?: true;
    /** Strictly validated atomic writer snapshot; never an ordinary event-array query. */
    readStateSnapshot?(signal: AbortSignal, requestId: string, priority: "foreground" | "background"): Promise<RelayEvent[]>;
    /** Demand-scoped verified ephemeral events on the session-owned socket. */
    observePresence?(authors: readonly string[], receive: (event: RelayEvent) => void): () => void;
    /** Complete bounded presence read. null is a local admission skip. */
    presenceSnapshot?(authors: readonly string[], signal: AbortSignal): Promise<ReadonlyMap<string, "online" | "away" | "offline" | "unknown"> | null>;
    readonly writeSidebarMute?: SidebarMuteMutator;
    /** Host-only, relay-scoped mutation of one existing sidebar group assignment. */
    readonly writeSidebarAssignment?: SidebarAssignmentMutator;
    readonly removeSidebarSection?: SidebarSectionRemovalMutator;
    readonly writeSidebarSectionOrder?: SidebarSectionOrderMutator;
    readonly writeSidebarStar?: SidebarStarMutator;
    readonly profiling?: RelayProfiler;
    /** Verified incoming traffic. The session owns this subscription and fences late delivery. */
    subscribe?(callbacks: LiveCallbacks): LiveSubscription;
    /** Stable community endpoint identity for durable session partitioning. */
    readonly scope?: string;
    /** Relay HTTP base for display only, such as a workflow's webhook address. */
    readonly relayHttpUrl?: string;
    /** Optional host-owned write capability, exposed to plugins only through the outbox. */
    readonly writer?: RelayWriter;
    /** The signed-in viewer whose channel roster is authoritative. */
    readonly viewer: string;
    /** Relay authority that signs discovery and window-bounds events. */
    readonly relayAuthor: string;
    readonly audienceAuthorityCommunity?: string | undefined;
    /** Explicit NIP-11 self from this community, never a contact-key fallback. */
    readonly archiveAuthority?: string;
    /** Purpose-bound authoritative recency, verified and max 128 channel IDs. */
    channelActivity?(channelIds: readonly string[], signal: AbortSignal): Promise<RelayEvent[]>;
    query(filters: readonly ReadFilter[], signal?: AbortSignal, requestId?: string, priority?: "foreground" | "background"): Promise<RelayEvent[]>;
    /** Relay `POST /profiles/search`: one page of current kind:0 profiles whose
     * `name` or `display_name` matches `query` by the NIP-50 prefix rule, best
     * match first. A relay without the endpoint fails with a 404 or 405
     * `ReadError`. */
    searchProfiles?(query: string, limit: number, page: number, signal: AbortSignal, priority: "foreground" | "background"): Promise<RelayEvent[]>;
    /** Display URL for a media URL, or undefined when this transport cannot fetch it. */
    media(url: string, size?: "small"): string | undefined;
}
/** Third-party https images load directly; relay-hosted media needs a signed read. */
export declare function mediaUrl(url: string, relayProxy: ((url: string) => string | undefined) | undefined, relayOrigin: string | undefined, size?: "small"): string | undefined;
export interface Signer {
    getPublicKey(): Promise<string>;
    signEvent(event: EventTemplate): Promise<VerifiedEvent>;
    /** The host authenticates and sends exact bytes without exposing credentials to JS. */
    request(url: string, body: string, signal?: AbortSignal): Promise<Response>;
    /** Native hosts sign and send `PUT /upload` for these exact bytes. */
    upload?(file: File, signal: AbortSignal): Promise<Response>;
    /** Native hosts serve relay `/media/` URLs through an authenticated proxy;
     * the browser host answers undefined until its signed fetch settles. */
    media?(url: string): string | undefined;
}
/** The host's explicit HTTP base wins; otherwise translate the ws(s) relay URL's scheme. */
export declare function relayHttpBase(explicit: unknown, relayUrl: unknown): string | undefined;
/** Register trusted-app-origin intent before contacting a new destination. No remote join. */
export declare function registerBrokerCommunity(community: string, signal?: AbortSignal, base?: string): Promise<void>;
/** Dev-only: a same-origin broker (see browser-host/relay-broker.mjs) holds the key and signs reads. */
export declare function connectBrokerTransport(base?: string, signal?: AbortSignal, community?: string): Promise<ReadTransport>;
/** A native purpose-bound read shares signed HTTP capacity and server cooldowns. */
export declare function admittedSignedWorkflowRead(origin: string, viewer: string, request: () => Promise<Response>, signal: AbortSignal): Promise<Response>;
export declare const admitSignedRequest: (origin: string, viewer: string, request: () => Promise<Response>, signal?: AbortSignal, priority?: "foreground" | "background", reason?: (body: unknown) => string | undefined) => Promise<Response>;
/** NIP-98 signed reads and writes through a host that owns the signer and authenticates each HTTP request. Reads and writes use the same identity and relay scope. */
export declare function connectSignedTransport(signer: Signer, httpOrigin: string, relayAuthor: string, socketFactory?: (url: string) => WebSocket): Promise<ReadTransport>;
export declare function acceptReadStatePublish(response: Response, id: string): Promise<string>;
/** A transport failure is an unknown outcome; only a definitive rejection is a failed write. */
export declare function acceptPublish(response: Response, id: string): Promise<string>;
