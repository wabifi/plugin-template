import { type ReadFilter, type RelayEvent } from "./events";
export type WindowCursor = Readonly<{
    createdAt: number;
    eventId: string;
}>;
export type WindowPage = Readonly<{
    events: RelayEvent[];
    cursor: WindowCursor | null;
    hasMore: boolean;
}>;
export declare const WINDOW_PAGE_SIZE = 20;
/** NIP-CW window request: top-level rows plus aux closure and thread summaries, paged by the relay's composite cursor. */
export declare function windowFilter(channelId: string, cursor: WindowCursor | null, limit?: number): ReadFilter;
/** The relay answers each served window with exactly one signed kind 39006 bounds event. Anything else is rejected;
 * an absent or malformed bound must never be mistaken for "no more history". */
export declare function parseWindow(channelId: string, cursor: WindowCursor | null, relayAuthor: string, events: readonly RelayEvent[]): WindowPage;
