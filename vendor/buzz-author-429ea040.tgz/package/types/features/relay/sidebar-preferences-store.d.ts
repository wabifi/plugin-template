import type { HeadPersistence } from "./persistence";
import type { SidebarAssignmentMutator, SidebarAssignmentIntent, SidebarSectionOrderMutator, SidebarSectionRemovalMutator, SidebarSectionCreationMutator, SidebarStarMutator, SidebarMuteMutator, SidebarPreferences, SidebarSortMode, SidebarSortMutator, SidebarFilterMode, SidebarFilterMutator } from "./sidebar-preferences";
type MoveDestination = {
    starred: true;
} | Omit<SidebarAssignmentIntent, "channelId">;
type MoveIntent = Readonly<{
    id: number;
    channelId: string;
    destination: MoveDestination;
}>;
type SortFailure = Readonly<{
    group: string;
    mode: SidebarSortMode;
    error: string;
}>;
type FilterFailure = Readonly<{
    group: string;
    mode: SidebarFilterMode;
    activeWindowSeconds?: number | null;
    error: string;
}>;
type OrderFailure = Readonly<{
    sectionId: string;
    sectionIds: readonly string[];
    error: string;
}>;
/** One bounded account-preference projection per relay session, not per page. */
export declare function createSidebarPreferencesStore({ read, available, write, writeStar, notify, writeMute, writeSort, persistence, removeSection, groupsOnly, writeOrder, createSection, writeFilter, }: Readonly<{
    read: (signal?: AbortSignal) => Promise<SidebarPreferences>;
    available: boolean;
    write?: SidebarAssignmentMutator | undefined;
    writeStar?: SidebarStarMutator | undefined;
    notify?: ((listener: () => void) => void) | undefined;
    writeMute?: SidebarMuteMutator | undefined;
    writeSort?: SidebarSortMutator | undefined;
    persistence?: HeadPersistence | undefined;
    removeSection?: SidebarSectionRemovalMutator | undefined;
    /** Solo groups have no Star coordinate; do not write Messages stars on moves. */
    groupsOnly?: boolean | undefined;
    writeOrder?: SidebarSectionOrderMutator | undefined;
    createSection?: SidebarSectionCreationMutator | undefined;
    writeFilter?: SidebarFilterMutator | undefined;
}>): {
    ready: Promise<void> | undefined;
    queries: Readonly<{
        available: boolean;
        readonly sectionRemovalWritable: any;
        removeSection(sectionId: string, callerSignal?: AbortSignal): Promise<void> | Promise<SidebarPreferences>;
        readonly sectionCreationWritable: boolean;
        createSection(section: Readonly<{
            id: string;
            name: string;
        }>): Promise<void>;
        readonly sectionOrderWritable: boolean;
        /** Optimistic whole-list order; the latest intent supersedes older ones. */
        reorderSections(sectionId: string, sectionIds: readonly string[]): Promise<SidebarPreferences>;
        dismissOrderError(): void;
        dismissSortError(group: string): void;
        readonly sortWritable: boolean;
        setSort(group: string, mode: SidebarSortMode, sectionIds: readonly string[], signal?: AbortSignal): Promise<Readonly<Record<string, SidebarSortMode>>>;
        dismissFilterError(group: string): void;
        readonly filterWritable: boolean;
        setFilter(group: string, mode: SidebarFilterMode, sectionIds: readonly string[], signal?: AbortSignal, activeWindowSeconds?: number | null): Promise<Readonly<{
            filters: Readonly<Record<string, SidebarFilterMode>>;
            activeWindowSeconds: Readonly<Record<string, number>>;
        }>>;
        readonly muteWritable: boolean;
        setMute(channelId: string, muted: boolean, signal?: AbortSignal): Promise<readonly string[]>;
        retryMove(channelId: string): Promise<SidebarPreferences>;
        dismissMoveError(channelId: string): void;
        readonly writable: boolean;
        assign(channelId: string, sectionId?: string, signal?: AbortSignal): Promise<SidebarPreferences>;
        createAndAssign(channelId: string, section: {
            id: string;
            name: string;
        }, signal?: AbortSignal): Promise<SidebarPreferences>;
        readonly removeSectionWritable: boolean;
        readonly starWritable: boolean;
        setStar(channelId: string, starred: boolean, signal?: AbortSignal): Promise<readonly string[]>;
        read: (signal?: AbortSignal) => Promise<SidebarPreferences>;
        snapshot: () => Readonly<{
            status: "idle" | "loading" | "ready" | "error" | "unsupported";
            data?: SidebarPreferences;
            error?: string;
            /** Set with an error that a later retry can fix; see isTransientFailure. */
            transient?: true;
            cached?: true;
            sortErrors?: readonly SortFailure[];
            filterErrors?: readonly FilterFailure[];
            moves?: readonly (MoveIntent & {
                pending: boolean;
                error?: string;
            })[];
            orderError?: OrderFailure;
        }>;
        subscribe(listener: () => void): () => void;
        ensure: () => Promise<void>;
        refresh: () => Promise<void>;
    }>;
    clear(): void;
    dispose(): void;
};
export {};
