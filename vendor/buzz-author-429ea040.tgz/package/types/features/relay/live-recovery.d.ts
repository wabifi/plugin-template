import type { RecoveryStatus } from "./recovery";
import type { LiveSnapshot } from "./live";
/** The parts of a session's live view that recovery classifies. */
export type LiveRecoveryView = LiveSnapshot & Readonly<{
    roster: Readonly<{
        state: string;
        transient?: true;
    }>;
    heads: readonly Readonly<{
        state: string;
        transient?: true;
    }>[];
    previews?: "checking" | "suspended";
}>;
/** A route failure that a later attempt can clear. Anything not known to
 * need action counts: relays use other and unprefixed reasons for outages,
 * and a capped retry costs little next to a live view that never recovers. */
export declare function isTransientLiveError(reason: string | undefined): boolean;
/** How the live layer looks to session recovery. Only failures a retry can
 * fix count as failed. A terminal sign-in error, a denial or invalid traffic
 * is settled here and stays visible in live status instead. */
export declare function liveRecoveryStatus(view: LiveRecoveryView): RecoveryStatus;
