import type { Outbox } from "./outbox";
import type { Profile } from "./contracts";
import type { RelayEvent } from "./events";
import type { Priority, RelayReader } from "./reader";
/** Shared profile reads for any feature, independent of channel history. */
export interface ProfileQueries {
    snapshot(): ReadonlyMap<string, Profile>;
    subscribe(listener: () => void): () => void;
    /** Fetch missing profiles; optional enrichment can yield to conversation reads. */
    ensure(ids: readonly string[], priority?: Priority): Promise<void>;
    /** The winning signed kind 0 retained for one identity, for provenance checks. */
    event?(pubkey: string): RelayEvent | undefined;
}
/** One bounded source of signed profile events. Display values are derived from it. */
export declare function createProfileDirectory(reader: RelayReader, local?: Pick<Outbox, "snapshot" | "subscribe">, notify?: (listener: () => void) => void): {
    queries: ProfileQueries;
    ensure: (ids: readonly string[], priority?: Priority, refresh?: boolean) => Promise<void>;
    accept: (incoming: readonly RelayEvent[]) => void;
    clear: () => void;
    reconnect(): Promise<void>;
    event: (id: string) => import("nostr-tools").VerifiedEvent | undefined;
    stats: () => {
        entries: number;
        bytes: number;
    };
    dispose(): void;
};
export type ProfileDirectory = ReturnType<typeof createProfileDirectory>;
