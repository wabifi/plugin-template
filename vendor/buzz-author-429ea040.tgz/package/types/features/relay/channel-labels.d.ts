import { type RelayEvent } from "./events.ts";
/** NIP-CL channel labels: grouping hints any channel admin can set. Never trust. */
export declare const MAX_CHANNEL_LABELS = 8;
/** Refusal for NIP-CL writes and lookups on a relay that does not advertise
 * `nip-cl`. Such a relay drops label tags, so nothing is sent. */
export declare function channelIdentityUnsupported(): Error;
/** A label must not equal a channel type, so it cannot make a channel look like another type. */
export declare function validChannelLabel(value: unknown): value is string;
/** Canonical label tags for kind:9007 and kind:9002: deduplicated, in caller order. */
export declare function channelLabelTags(labels: readonly string[]): string[][];
/** Relay-written identity facts on kind:39000–39003. The first `t` tag is the
 * channel type; later `t` tags are labels. `P` is the creator, `created_at`
 * (39000 only) is the creation time. */
export declare function channelIdentity(event: RelayEvent): Readonly<{
    type?: string;
    labels: readonly string[];
    creator?: string;
    createdAt?: number;
}>;
/** NIP-CL oldest-channel rule: lowest `created_at` tag, then lowest ID. A
 * channel without a creation time ranks after every channel that has one. */
export declare function compareChannelAge(a: Readonly<{
    id: string;
    createdAt?: number | undefined;
}>, b: Readonly<{
    id: string;
    createdAt?: number | undefined;
}>): number;
