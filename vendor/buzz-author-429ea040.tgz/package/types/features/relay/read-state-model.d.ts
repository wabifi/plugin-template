import type { RelayEvent } from "./events.ts";
/** NIP-RS timestamps/counters are uint32, not timeline event-ID cursors. */
export declare const READ_STATE_MAX = 4294967295;
export declare const READ_STATE_KEYS = 10000;
export declare const READ_STATE_EVENT_BYTES: number;
export declare const READ_STATE_PLAINTEXT_BYTES: number;
export declare const uint32: (value: unknown) => value is number;
export declare const record: (value: unknown) => value is Record<string, unknown>;
export declare const contextId: (value: unknown) => value is string;
export declare const slotId: (value: unknown) => value is string;
export type ReadTarget = Readonly<{
    kind: "channel";
    channelId: string;
}> | Readonly<{
    kind: "thread";
    channelId: string;
    rootId: string;
}> | Readonly<{
    kind: "message";
    channelId: string;
    messageId: string;
}>;
export declare function targetKey(target: ReadTarget): string;
export type Override = Readonly<{
    set: number;
    clear: number;
    baseline: number;
}>;
export type ReadState = Readonly<{
    frontiers: Readonly<Record<string, number>>;
    overrides: Readonly<Record<string, Override>>;
}>;
export type ReadBlob = Readonly<{
    v: 1;
    client_id: string;
    contexts: Readonly<Record<string, number>>;
}>;
export type ParsedReadBlob = Readonly<{
    clientId: string;
    state: ReadState;
}>;
export declare const EMPTY_READ_STATE: ReadState;
/** Signature verification belongs to the transport. This is a structural selector only. */
export declare function readCoordinate(event: Pick<RelayEvent, "kind" | "tags">): string | undefined;
/** Groups override siblings BEFORE invalid-entry dropping. Unknown versions fail closed. */
export declare function parseReadBlob(raw: unknown): ParsedReadBlob;
/** No coordinate replacement, duplicate, or replay can rewind already merged intent. */
export declare function mergeReadStates(...states: readonly ReadState[]): ReadState;
/** The graph-supplied parent/root is never read from encrypted caller ancestry. */
export declare function effectiveFrontier(state: ReadState, key: string, channelId?: string, rootId?: string): number | undefined;
export declare function overrideActive(value: Override | undefined, frontier: number | undefined): boolean;
export declare function advanceRead(state: ReadState, key: string, timestamp: number): ReadState;
/** Requires a complete snapshot at the command boundary; this pure function cannot prove it. */
export declare function changeOverride(state: ReadState, key: string, unread: boolean, frontier: number): ReadState;
/** Canonical floors are permanent. Never call on a partial snapshot for publication. */
export declare function readBlob(clientId: string, state: ReadState, frontier: (key: string) => number | undefined): ReadBlob;
/** Wait rather than manufacture unbounded future timestamps on rapid/backward clocks. */
export declare function readVersion(now: number, previous: number): number;
