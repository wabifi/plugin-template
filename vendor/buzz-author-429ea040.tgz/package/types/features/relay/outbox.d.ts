import { type EventTemplate } from "nostr-tools";
import { type EventData, type RelayEvent } from "./events";
import type { RelayWriter } from "./transport";
import { type RelayProfiler } from "./profiling";
import { MessageClock } from "./message-order";
export type Delivery = "sending" | "accepted" | "unknown" | "failed" | "seen";
/** Durable, caller-owned recovery state committed with the operation. */
export type OutboxRecovery = Readonly<{
    key: string;
    value: string;
}>;
export type OutgoingEvent = Readonly<{
    event: EventData;
    signed?: RelayEvent;
    recovery?: OutboxRecovery | undefined;
    /** Caller verified the operation’s domain outcome, not merely delivery. */
    acknowledged?: true;
    /** A caller-scoped admission requires renewed live eligibility for retry. */
    guarded?: boolean;
    delivery: Delivery;
    error?: string | undefined;
    /** The relay refused the last attempt, rather than it failing on this
     * device, being asked to wait, or going unanswered. */
    refused?: true | undefined;
}>;
export interface Outbox {
    /** Outstanding operations only. Confirmed events live in the session's retained data. */
    snapshot(): readonly OutgoingEvent[];
    subscribe(listener: () => void): () => void;
    /** Capture fresh send intent synchronously; returned work runs once after
     * receipt/verified echo, never history hydration. It cannot affect delivery. */
    observeSend(listener: SendObserver): () => void;
    supports(kind: number): boolean;
    ready(): Promise<void>;
    send(input: Pick<EventTemplate, "kind" | "content" | "tags"> & {
        /** NIP-AP: created_at of the newest observed head this event replaces. */
        supersedes?: number;
    }, recovery?: OutboxRecovery, active?: () => boolean): string;
    /** Attach caller-owned recovery to an existing receipt before resuming it. */
    recover(id: string, recovery: OutboxRecovery): Promise<void>;
    acknowledge(id: string): Promise<void>;
    retry(id: string, active?: () => boolean): void;
    dismiss(id: string): Promise<void>;
    /** Durable explicit dismissal, with delivery evidence at removal. */
    observeDismiss(listener: (item: OutgoingEvent) => void): () => void;
}
type SendObserver = (event: EventData, signal: AbortSignal) => ((pending: readonly EventData[]) => void) | undefined;
export type LocalEvents = Pick<Outbox, "snapshot" | "subscribe">;
export interface OutboxStorage {
    close?(): void;
    load(): readonly OutgoingEvent[] | Promise<readonly OutgoingEvent[]>;
    save(operations: readonly OutgoingEvent[]): void | Promise<void>;
}
export declare class PublishRejected extends Error {
    readonly reason?: string | undefined;
    /** The relay's own refusal text, when it sent one; `message` stays the
     * display summary. Bounded by the transport that read it. */
    constructor(message: string, reason?: string | undefined);
}
/** Proven not delivered, but not refused: the request never left this
 * device, or the relay asked it to wait. Retrying may succeed. */
export declare class PublishNotSent extends PublishRejected {
}
export { browserOutboxStorage } from "./outbox-storage";
/** One journal owns pending delivery and bounded confirmed retention. Views receive one change stream. */
export declare function createOutbox(viewer: string, writer: RelayWriter, storage: OutboxStorage, { timeoutMs, onAccepted, profiling, notifyListener, preparePublish, holdPublish, needsReceipt, onReceipt, clock, }?: {
    /** The session's send clock, shared with its rendered views. */
    clock?: MessageClock;
    timeoutMs?: number;
    /** Commands await their receipt even after a verified echo. Never persisted. */
    needsReceipt?: (event: EventData) => boolean;
    onReceipt?: (event: EventData, message: string | undefined) => void;
    onAccepted?: (event: RelayEvent) => void;
    profiling?: RelayProfiler;
    notifyListener?: (listener: () => void) => void;
    /** Read-only pre-dispatch work under the attempt deadline. The returned
     * synchronous check runs with no await between it and publisher entry. */
    preparePublish?: (event: RelayEvent, signal: AbortSignal) => Promise<(() => void) | undefined>;
    /** Work a signed event waits for before it publishes, such as its
     * channel's creation. A held event takes no delivery slot, and its
     * deadline starts when the hold ends; a rejected hold fails it. */
    holdPublish?: (event: RelayEvent) => Promise<void> | undefined;
}): {
    outbox: Outbox;
    local: Readonly<{
        snapshot: () => readonly Readonly<{
            event: EventData;
            signed?: RelayEvent;
            recovery?: OutboxRecovery | undefined;
            /** Caller verified the operation’s domain outcome, not merely delivery. */
            acknowledged?: true;
            /** A caller-scoped admission requires renewed live eligibility for retry. */
            guarded?: boolean;
            delivery: Delivery;
            error?: string | undefined;
            /** The relay refused the last attempt, rather than it failing on this
             * device, being asked to wait, or going unanswered. */
            refused?: true | undefined;
        }>[];
        subscribe: (listener: () => void) => () => void;
    }>;
    ready: Promise<void>;
    /** Fetched/confirmed evidence is disposable; pending intent is not. A revoke
     * during async hydration fences that old confirmed cache, not its writes. */
    purgeConfirmed(keep: (event: EventData) => boolean): void;
    observe(events: readonly RelayEvent[]): void;
    dispose(): void;
};
