import type { ReadFilter } from "./events.ts";
import type { RelayEvent } from "./events.ts";
import type { RelayReader } from "./reader.ts";
export declare const SIDEBAR_COORDINATES: readonly ["channel-sections", "channel-stars", "channel-mutes", "channel-sort", "channel-filter"];
/** Only the complete bounded account-preference batch may exceed the ordinary four-filter limit. */
export declare function isSidebarPreferencesBatch(filters: readonly ReadFilter[]): boolean;
export type SidebarGroups = Readonly<{
    sections: readonly Readonly<{
        id: string;
        name: string;
        icon?: string;
        order: number;
    }>[];
    assignments: Readonly<Record<string, string>>;
}>;
export type SidebarFilterMode = "all" | "unreads" | "active";
export declare const DEFAULT_ACTIVE_WINDOW_SECONDS: number;
export declare const MAX_ACTIVE_WINDOW_SECONDS: number;
export declare function validActiveWindow(value: unknown): value is number;
export type SidebarFilterSettings = Readonly<{
    filters: Readonly<Record<string, SidebarFilterMode>>;
    activeWindowSeconds: Readonly<Record<string, number>>;
}>;
export type SidebarFilterMutator = (group: string, mode: SidebarFilterMode, sectionIds: readonly string[], signal: AbortSignal, activeWindowSeconds?: number | null) => Promise<SidebarFilterSettings>;
export type SidebarSortMode = "alpha" | "recent";
export type SidebarSortMutator = (group: string, mode: SidebarSortMode, sectionIds: readonly string[], signal: AbortSignal) => Promise<Readonly<Record<string, SidebarSortMode>>>;
export type SidebarMuteMutator = (intent: Readonly<{
    channelId: string;
    muted: boolean;
}>, signal: AbortSignal) => Promise<readonly string[]>;
export type SidebarPreferences = SidebarGroups & Readonly<{
    starred: readonly string[];
    muted: readonly string[];
    sort?: Readonly<Record<string, SidebarSortMode>>;
    filters?: Readonly<Record<string, SidebarFilterMode>>;
    activeWindowSeconds?: Readonly<Record<string, number>>;
}>;
export type SidebarAssignmentIntent = Readonly<{
    channelId: string;
    sectionId?: string;
    createSection?: Readonly<{
        id: string;
        name: string;
    }>;
}>;
export type SidebarAssignmentMutator = (intent: SidebarAssignmentIntent, signal: AbortSignal) => Promise<SidebarGroups>;
export type SidebarSectionRemovalMutator = (sectionId: string, signal: AbortSignal) => Promise<SidebarGroups>;
export type SidebarSectionOrderMutator = (sectionIds: readonly string[], signal: AbortSignal) => Promise<SidebarGroups>;
/** Adds an empty section; only Solo groups support this today. */
export type SidebarSectionCreationMutator = (section: Readonly<{
    id: string;
    name: string;
}>, signal: AbortSignal) => Promise<SidebarGroups>;
export type SidebarStarMutator = (intent: Readonly<{
    channelId: string;
    starred: boolean;
}>, signal: AbortSignal) => Promise<readonly string[]>;
export type SidebarDecoder = (events: readonly RelayEvent[], signal: AbortSignal) => Promise<SidebarPreferences>;
/** Read-only legacy projection. Never merge, migrate, or publish account preferences. */
export declare function projectSidebarPreferences(sections: unknown, stars: unknown, mutes?: unknown, sort?: unknown, sortSectionIds?: readonly string[], filters?: unknown): SidebarPreferences;
export declare function readSidebarPreferences(reader: RelayReader, viewer: string, decode: SidebarDecoder, signal: AbortSignal): Promise<SidebarPreferences>;
