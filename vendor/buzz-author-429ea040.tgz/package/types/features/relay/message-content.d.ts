export declare const MAX_MARKDOWN_LENGTH = 100000;
export declare const MAX_MARKDOWN_DEPTH = 100;
/** Active links accept credential-free HTTP(S) destinations. */
export declare function safeLinkUrl(value: string): string | undefined;
/** Projected attachments and imeta media stay HTTPS-only. */
export declare function safeMessageUrl(value: string): string | undefined;
type MarkdownNode = {
    type: string;
    value?: string;
    url?: string;
    identifier?: string;
    children?: MarkdownNode[];
    position?: {
        start: {
            offset?: number;
        };
        end: {
            offset?: number;
        };
    };
};
type MarkdownScan = {
    tree: MarkdownNode;
    tooDeep: boolean;
    definitions: Map<string, string>;
    images: MarkdownNode[];
    links: MarkdownNode[];
};
/** Raw HTML in chat is shown as the typed text, except complete HTML
 * comments. Comments are hidden markup by Markdown convention, and clients
 * put protocol markers in them (Buzz Desktop waves start with
 * `<!-- buzz:wave:v1 -->`). An unclosed `<!--` stays visible.
 * This is text projection, not HTML sanitization: callers must render the
 * result as text. Remove only authored comments once; joining their neighbors
 * can form new HTML syntax that must remain visible literal text. */
export declare function visibleHtmlSource(value: string): string;
export declare const MAX_ATTACHMENT_NAME_LENGTH = 256;
export declare const RELAY_HASH_BASENAME: RegExp;
export declare function relayHashBasename(value: string): boolean;
export declare function safeAttachmentName(value: string): string | undefined;
/** Parse once and bound attacker-controlled nesting before recursive render stages. */
export declare function scanMarkdown(content: string): MarkdownScan;
export type ProjectedAttachmentLinkName = Readonly<{
    url: string;
    name: string;
}>;
export declare function projectMarkdownAttachments(content: string, attachmentUrls: ReadonlySet<string>): {
    content: string;
    seams: readonly number[];
    urls: readonly string[];
    names: readonly ProjectedAttachmentLinkName[];
};
export {};
