/** Yield CPU batches without the delay browsers impose on nested timers. */
export declare function yieldToHost(): Promise<void>;
