export declare const VIDEO_PREPARATION_MS = 600000;
/** Container bytes choose a fixed demuxer, never a caller-supplied ffmpeg argument. */
export declare function videoDemuxer(bytes: Uint8Array): string | undefined;
/** Match old Buzz's HEIF brands, plus the filename fallback for unfamiliar brands. */
export declare function isHeic(bytes: Uint8Array, name?: string): boolean;
export declare function isVoiceNote(name: string): boolean;
/** Fixed audio demuxers for the old voice-note filename exception, not generic audio uploads. */
export declare function audioDemuxer(bytes: Uint8Array): string | undefined;
