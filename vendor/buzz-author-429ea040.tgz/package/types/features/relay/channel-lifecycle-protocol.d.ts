import type { EventTemplate } from "nostr-tools";
import { type RelayEvent } from "./events.ts";
export type ChannelLifecycleAction = "archive" | "unarchive" | "delete" | "leave" | "hide";
/** Join is not a confirmed member action: it starts from a nonmember preview. */
export type ChannelLifecycleCommand = ChannelLifecycleAction | "join";
export declare const CHANNEL_LIFECYCLE_KINDS: readonly [9002, 9008, 9021, 9022, 41012];
export declare const DM_VISIBILITY_KIND = 30622;
export declare function lifecycleChannelId(value: string): string;
export declare function lifecycleTemplate(action: ChannelLifecycleCommand, channelId: string): EventTemplate;
/** The host never accepts generic metadata edits or other-member removal. */
export declare function validateLifecycleTemplate(event: EventTemplate): void;
export declare function exactLifecycleTag(event: RelayEvent, name: string): string | undefined;
/**
 * The channel type of relay-signed channel state. NIP-CL puts the type in
 * the first `t` tag; later `t` tags are channel labels, not a second type.
 */
export declare function channelTypeTag(event: RelayEvent): string | undefined;
export declare function lifecycleRecord(events: readonly RelayEvent[], kind: number, id: string, relayAuthor: string): import("nostr-tools").VerifiedEvent | undefined;
export type ChannelLifecycleSettings = Readonly<{
    channelId: string;
    channelType: "stream" | "forum" | "dm" | "system";
    canArchive: boolean;
    canUnarchive: boolean;
    canDelete: boolean;
    deleteUnavailable?: boolean;
    canLeave: boolean;
    canHide: boolean;
    leaveReason?: string;
}>;
export declare function lifecycleSettings(events: readonly RelayEvent[], id: string, viewer: string, relayAuthor: string): ChannelLifecycleSettings;
