export declare function validatedBlurhash(value: unknown): string | undefined;
