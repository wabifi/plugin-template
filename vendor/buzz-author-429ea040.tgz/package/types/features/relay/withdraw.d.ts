import type { Outbox } from "./outbox";
/** Removes a queued operation once its delivery attempt has ended; the outbox
 * keeps one that is still being attempted. */
export declare function withdraw(outbox: Pick<Outbox, "snapshot" | "subscribe" | "dismiss">, id: string): Promise<void>;
