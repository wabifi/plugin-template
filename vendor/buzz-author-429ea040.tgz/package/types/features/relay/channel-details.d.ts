import type { RelayReader } from "./reader";
import type { RelayWriter } from "./transport";
import type { RelayEvent } from "./events";
import { type ChannelDetails, type ChannelDetailsDraft } from "./channel-details-protocol";
export type DetailsAttempt = Readonly<{
    draft: ChannelDetailsDraft;
    status: "saving" | "unconfirmed";
}>;
export interface ChannelDetailsCapability {
    readonly available: boolean;
    load(id: string, signal?: AbortSignal): Promise<ChannelDetails>;
    save(base: ChannelDetails, draft: ChannelDetailsDraft, signal?: AbortSignal): Promise<void>;
    check(id: string, signal?: AbortSignal): Promise<void>;
    snapshot(id: string): DetailsAttempt | undefined;
    subscribe(listener: () => void): () => void;
}
/** Session owns uncertain intent through panel close/reopen; no automatic publication retry. */
export declare function createChannelDetails({ reader, writer, labels, viewer, relayAuthor, canAccess, acceptDiscovery, }: {
    reader?: RelayReader | undefined;
    writer?: RelayWriter | undefined;
    /** The relay keeps channel labels (NIP-CL). Without it, label edits are refused. */
    labels?: boolean;
    viewer: string;
    relayAuthor: string;
    canAccess(id: string): boolean;
    acceptDiscovery(events: readonly RelayEvent[]): void;
}): {
    capability: ChannelDetailsCapability;
    cancel: () => void;
    clear: () => void;
    dispose(): void;
};
