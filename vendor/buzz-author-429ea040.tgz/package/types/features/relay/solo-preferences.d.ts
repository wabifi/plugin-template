import type { ChannelKit } from "../channel-templates/capability";
import { type KitEntry } from "../channel-templates/model";
export declare function soloGroups(entries: readonly KitEntry[]): KitEntry | undefined;
/** Reuse recipe revision checks/outbox and preference lifecycle; never read Messages groups. */
export declare function createSoloPreferences(kit: ChannelKit, lifetime: AbortSignal): {
    ready: Promise<void> | undefined;
    queries: Readonly<{
        available: boolean;
        readonly sectionRemovalWritable: any;
        removeSection(sectionId: string, callerSignal?: AbortSignal): Promise<void> | Promise<import("./sidebar-preferences").SidebarPreferences>;
        readonly sectionCreationWritable: boolean;
        createSection(section: Readonly<{
            id: string;
            name: string;
        }>): Promise<void>;
        readonly sectionOrderWritable: boolean;
        reorderSections(sectionId: string, sectionIds: readonly string[]): Promise<import("./sidebar-preferences").SidebarPreferences>;
        dismissOrderError(): void;
        dismissSortError(group: string): void;
        readonly sortWritable: boolean;
        setSort(group: string, mode: import("./sidebar-preferences").SidebarSortMode, sectionIds: readonly string[], signal?: AbortSignal): Promise<Readonly<Record<string, import("./sidebar-preferences").SidebarSortMode>>>;
        dismissFilterError(group: string): void;
        readonly filterWritable: boolean;
        setFilter(group: string, mode: import("./sidebar-preferences").SidebarFilterMode, sectionIds: readonly string[], signal?: AbortSignal, activeWindowSeconds?: number | null): Promise<Readonly<{
            filters: Readonly<Record<string, import("./sidebar-preferences").SidebarFilterMode>>;
            activeWindowSeconds: Readonly<Record<string, number>>;
        }>>;
        readonly muteWritable: boolean;
        setMute(channelId: string, muted: boolean, signal?: AbortSignal): Promise<readonly string[]>;
        retryMove(channelId: string): Promise<import("./sidebar-preferences").SidebarPreferences>;
        dismissMoveError(channelId: string): void;
        readonly writable: boolean;
        assign(channelId: string, sectionId?: string, signal?: AbortSignal): Promise<import("./sidebar-preferences").SidebarPreferences>;
        createAndAssign(channelId: string, section: {
            id: string;
            name: string;
        }, signal?: AbortSignal): Promise<import("./sidebar-preferences").SidebarPreferences>;
        readonly removeSectionWritable: boolean;
        readonly starWritable: boolean;
        setStar(channelId: string, starred: boolean, signal?: AbortSignal): Promise<readonly string[]>;
        read: (signal?: AbortSignal) => Promise<import("./sidebar-preferences").SidebarPreferences>;
        snapshot: () => Readonly<{
            status: "idle" | "loading" | "ready" | "error" | "unsupported";
            data?: import("./sidebar-preferences").SidebarPreferences;
            error?: string;
            transient?: true;
            cached?: true;
            sortErrors?: readonly Readonly<{
                group: string;
                mode: import("./sidebar-preferences").SidebarSortMode;
                error: string;
            }>[];
            filterErrors?: readonly Readonly<{
                group: string;
                mode: import("./sidebar-preferences").SidebarFilterMode;
                activeWindowSeconds?: number | null;
                error: string;
            }>[];
            moves?: readonly (Readonly<{
                id: number;
                channelId: string;
                destination: Omit<Readonly<{
                    channelId: string;
                    sectionId?: string;
                    createSection?: Readonly<{
                        id: string;
                        name: string;
                    }>;
                }>, "channelId"> | {
                    starred: true;
                };
            }> & {
                pending: boolean;
                error?: string;
            })[];
            orderError?: Readonly<{
                sectionId: string;
                sectionIds: readonly string[];
                error: string;
            }>;
        }>;
        subscribe(listener: () => void): () => void;
        ensure: () => Promise<void>;
        refresh: () => Promise<void>;
    }>;
    clear(): void;
    dispose(): void;
};
