import type { RelayEvent } from "./events";
export declare const CHANNEL_ACTIVITY_KINDS: readonly [9, 40002, 40008, 45001, 45003];
export type ChannelActivityReader = (channelIds: readonly string[], signal: AbortSignal) => Promise<readonly RelayEvent[]>;
/** One roster-scoped activity projection. Authoritative reads may clear unchanged
 * values; verified live activity can only advance them. */
export declare function createChannelActivity(read: ChannelActivityReader | undefined, notify?: (listener: () => void) => void): {
    status: () => "error" | "idle" | "loading" | "ready" | "unavailable";
    last: (channelId: string) => number | undefined;
    known: (channelId: string) => boolean;
    revision: () => number;
    subscribe(listener: () => void): () => void;
    accept: (events: readonly RelayEvent[]) => void;
    refresh(input: readonly string[]): Promise<void>;
    cancel(): void;
    /** Access loss fences reads and drops only channels no longer readable;
     * the others keep their values, so Recent sections keep their order. */
    retain(readable: (channelId: string) => boolean): void;
    clear(): void;
    dispose(): void;
};
