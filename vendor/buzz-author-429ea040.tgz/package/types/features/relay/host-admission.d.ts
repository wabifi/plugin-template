import { createLiveAdmission } from "./live.ts";
import { createApiAdmission } from "./http-admission.ts";
/** In-memory host ownership, not a cross-app quota promise. Capacity eviction
 * never forgets an active stream, queued work or server cooldown. */
export declare function createHostAdmission(): (endpoint: string, viewer: string) => {
    live: ReturnType<typeof createLiveAdmission>;
    api: ReturnType<typeof createApiAdmission>;
    streams: number;
};
