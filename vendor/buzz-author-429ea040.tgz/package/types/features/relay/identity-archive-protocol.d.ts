import type { EventTemplate } from "nostr-tools";
export type IdentityArchiveAction = "archive" | "unarchive";
/** NIP-IA 9035/9036 wire form. The relay chooses and re-verifies the consent path. */
export declare function archiveRequestTemplate(action: IdentityArchiveAction, target: string, auth?: readonly string[]): EventTemplate;
/** The host signs only this exact shape: no reason, rotation or other tags. */
export declare function validateArchiveRequestTemplate(event: EventTemplate): void;
