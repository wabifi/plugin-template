/** NIP-10 matches relay ingest: last valid marked root/reply wins; a lone root is not a reply. */
export declare function threadReference(event: {
    readonly tags: readonly (readonly string[])[];
}): {
    rootId: string;
    parentId: string;
} | undefined;
