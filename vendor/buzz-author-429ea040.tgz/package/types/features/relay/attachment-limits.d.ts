/** Old Buzz relay defaults. The relay may enforce a lower deployment policy. */
export declare const MIB: number;
export declare const UPLOAD_MAX_BYTES: number;
export declare const UPLOAD_TIMEOUT_MS = 600000;
export declare function mediaByteLimit(type: string): number;
/** MIME hints never grant acceptance: the relay still sniffs and validates content. */
export declare function imageType(bytes: Uint8Array): string | undefined;
export declare function relayRejection(text: string): "codec" | "duration" | "metadata" | "rejected" | "resolution";
