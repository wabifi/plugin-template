import { type UploadedAttachment } from "./attachments";
/** Private deployment inbox protocol. No channel tag, event view, or NIP-56 report. */
export declare const PRODUCT_FEEDBACK_KIND = 42000;
export type FeedbackCategory = "bug" | "praise" | "needs-work";
export declare function feedbackEvent(message: string, category: FeedbackCategory | null, attachments?: readonly UploadedAttachment[], origin?: string): {
    kind: number;
    content: string;
    tags: string[][];
};
