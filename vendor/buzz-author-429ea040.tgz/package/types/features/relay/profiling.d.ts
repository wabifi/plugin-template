/** Bounded, payload-free timings. Event/request IDs correlate stages without logging content. */
export type RelayTiming = Readonly<{
    stage: string;
    id: string;
    start: number;
    duration: number;
    outcome: "ok" | "error" | "pending";
    count?: number;
}>;
export declare function createRelayProfiler(now?: () => number): Readonly<{
    start: (stage: string, id: string, count?: number) => (outcome?: "ok" | "error") => void;
    record: (sample: RelayTiming) => void;
    snapshot: () => readonly Readonly<{
        stage: string;
        id: string;
        start: number;
        duration: number;
        outcome: "ok" | "error" | "pending";
        count?: number;
    }>[];
    clear: () => void;
    measure<T>(stage: string, id: string, work: () => T, count?: number): T;
    measureAsync<T>(stage: string, id: string, work: () => Promise<T>): Promise<T>;
}>;
export type RelayProfiler = ReturnType<typeof createRelayProfiler>;
