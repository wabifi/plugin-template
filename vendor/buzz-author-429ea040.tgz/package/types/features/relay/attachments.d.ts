import { UPLOAD_MAX_BYTES, UPLOAD_TIMEOUT_MS } from "./attachment-limits.ts";
export { UPLOAD_MAX_BYTES, UPLOAD_TIMEOUT_MS };
export type UploadedAttachment = Readonly<{
    name: string;
    url: string;
    type: string;
    size: number;
    sha256: string;
    voice?: Readonly<{
        duration: number;
        waveform: readonly number[];
    }>;
}>;
/** Bytes of the transferred file handed to the connection so far. */
export type UploadProgress = (sent: number, total: number) => void;
export type AttachmentUpload = (file: File, signal: AbortSignal, progress?: UploadProgress) => Promise<UploadedAttachment>;
export declare const UPLOAD_FAILURES: {
    readonly unavailable: "Uploads are unavailable on this connection.";
    readonly size: "File exceeds the supported limit: images 50 MiB, GIFs 10 MiB, documents 100 MiB, videos 500 MiB. The relay may enforce a lower limit.";
    readonly image: "Image conversion failed. This HEIC/HEIF photo could not be prepared.";
    readonly ffmpeg: "Media conversion requires ffmpeg on this computer (version 8 or newer for HEIC images). Install or update it, then restart the app.";
    readonly io: "Media preparation could not access temporary storage. Check available disk space and retry.";
    readonly video: "Video preparation failed. This recording could not be converted to MP4.";
    readonly capacity: "Uploads are busy. Retry this file shortly.";
    readonly metadata: "This file needs metadata cleanup before it can be uploaded. Choose an exported copy without metadata, or remove it for now.";
    readonly resolution: "This video is larger than 4K (3840×2160). Export it at a smaller size, then retry.";
    readonly duration: "Videos can be at most 10 minutes long. Trim this recording, then retry.";
    readonly codec: "This file’s codec isn’t supported. Use H.264 video and AAC audio, then retry.";
    readonly rejected: "The server could not accept this file. Its format or metadata may not be supported.";
    readonly denied: "You don’t have permission to upload here.";
    readonly failed: "Upload did not finish. Retry or remove this file.";
    readonly invalid: "The server returned an invalid upload result. Retry this file.";
    readonly cancelled: "Upload cancelled. Retry to upload this file.";
};
export type UploadCode = keyof typeof UPLOAD_FAILURES;
export declare class UploadError extends Error {
    readonly code: UploadCode;
    constructor(code: UploadCode);
}
export declare function validateUploadResult(value: unknown, origin: string, size: number, name: string): UploadedAttachment;
/** A file's name as relay filename metadata takes it: a basename capped at
 * 255 UTF-8 bytes. */
export declare function attachmentName(file: string): string;
/** An uploaded file's Markdown link: inline media embeds, others link. */
export declare function attachmentMarkdown(name: string, result: Pick<UploadedAttachment, "url" | "type">): string;
export declare function brokerUpload(endpoint: string, origin: string): AttachmentUpload;
/** Shared upload policy for any host that signs and sends the exact bytes it
 * is given: limits, timeout, error mapping and descriptor validation. */
export declare function hostUpload(send: (file: File, signal: AbortSignal, progress?: UploadProgress) => Promise<Response>, origin: string, prepare?: (file: File, signal: AbortSignal) => Promise<File>): AttachmentUpload;
/** One relay-status and bounded-body policy for raw and host-prepared uploads. */
export declare function readUploadResponse(response: Response): Promise<unknown>;
/** Only completed uploads enter the existing message/outbox contract. */
export declare function attachmentMessage(content: string, attachments: readonly UploadedAttachment[], origin?: string): {
    content: string;
    tags: string[][];
};
