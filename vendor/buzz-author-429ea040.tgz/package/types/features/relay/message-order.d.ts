import type { EventData } from "./events";
/** Sub-second send order: `ms` is a canonical 0–999 offset within the signed second. */
export declare function eventMs(event: Pick<EventData, "created_at" | "tags">): number;
/** The one rendered message order: effective ms ascending, then event id ascending. */
export declare function compareMessages(a: Readonly<{
    id: string;
    createdAt: number;
    createdAtMs?: number;
}>, b: Readonly<{
    id: string;
    createdAt: number;
    createdAtMs?: number;
}>): number;
/**
 * Per-session send clock: per-channel high-water marks from rendered evidence
 * (anyone) and from this device's own sends. One relay session owns one clock,
 * so channel keys never mix across communities or viewers.
 */
export declare class MessageClock {
    private latest;
    private sent;
    /** Record rendered channel/thread evidence so the next send sorts after it. */
    observe(channelId: string, ms: number): void;
    /**
     * Allocate a send time after everything known in the channel. Other authors'
     * evidence may push it at most 5s past the clock; this device's own sends in
     * the channel stay strictly increasing (up to a 60s lead), so a burst never
     * rewinds or ties even when evidence is far in the future.
     */
    next(channelId: string, now?: number): number;
}
