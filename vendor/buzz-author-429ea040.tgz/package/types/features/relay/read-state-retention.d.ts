import { type ReadState } from "./read-state-model";
/** The mark that already reads all `key` reads, if any. `frontier` looks up
 * marks that are being kept, plus `key` itself. */
export type CoveredFrontier = (key: string, frontier: (key: string) => number | undefined) => string | undefined;
/** The message a mark is about. Message, thread and thread catch-up marks
 * each name one message (a thread names its root); other marks name none. */
export declare function markMessage(key: string): string | undefined;
/** Frontier hints are bounded recent activity, not an everlasting receipt log (NIP-RS).
 * Up to `SCOPED_SHARE` of the budget, channel marks outrank thread marks, then
 * catch-up marks, then message marks. The rest goes by local interaction order,
 * which wins over event time so reading old history still synchronizes.
 * Every override group and its direct frontier is protected; pressure can never lose a floor.
 *
 * Marks that `covered` proves redundant are dropped only after the budget has
 * chosen what to keep, and only when their covering mark was kept. The freed
 * space then goes to the next marks in line. A dropped mark gives its recency
 * to its cover, so a smaller limit later (such as the synced one) protects the
 * cover as it would have protected the dropped read.
 */
export declare function retainRead(states: readonly ReadState[], recent: Readonly<Record<string, number>>, clientId: string, maxBytes?: number, covered?: CoveredFrontier): {
    state: ReadState;
    recent: Readonly<Record<string, number>>;
};
/** `retainRead` when the caller keeps no recency, such as a publication. */
export declare function retainReadState(states: readonly ReadState[], recent: Readonly<Record<string, number>>, clientId: string, maxBytes?: number, covered?: CoveredFrontier): ReadState;
/** Local-only receipts evicted from the sync journal. Never passed to publication. */
export declare const READ_RESERVE_KEYS = 5000;
export declare const READ_RESERVE_BYTES: number;
export declare function retainLocalRead(states: readonly ReadState[], recent: Readonly<Record<string, number>>, clientId: string, reserve?: Readonly<Record<string, number>>, covered?: CoveredFrontier): {
    state: ReadState;
    recent: Readonly<Record<string, number>>;
    reserve: Readonly<{
        [k: string]: number;
    }>;
};
