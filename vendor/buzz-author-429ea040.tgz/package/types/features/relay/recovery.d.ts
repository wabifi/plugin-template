/** One automatic recovery owner for a relay session's background reads.
 *
 * Each source reports whether it currently shows a failure. While any source
 * fails, recovery retries every failed source with a capped exponential delay.
 * It never gives up. A wake, network or success signal retries at once.
 *
 * Sources are background reads only. User actions (sends, moves, deletes) own
 * their own Retry because repeating them silently could repeat a user intent. */
export type RecoveryStatus = "failed" | "busy" | "settled";
export type RecoverySource = Readonly<{
    status(): RecoveryStatus;
    subscribe(listener: () => void): () => void;
    retry(): void;
}>;
export type RecoverySnapshot = Readonly<{
    /** True while at least one source shows a failure. */
    recovering: boolean;
    /** Backoff index. retryNow restarts it; it does not hide the notice. */
    attempt: number;
    /** True from the first automatic retry until every source settles. Kept
     * apart from `attempt` so a manual or signal retry keeps the notice up. */
    shown: boolean;
}>;
export type RelayRecovery = Readonly<{
    snapshot(): RecoverySnapshot;
    subscribe(listener: () => void): () => void;
    /** Retry failed sources now and restart the delay sequence. `except` skips
     * a source that already owns its own recovery for the triggering event. */
    retryNow(except?: RecoverySource): void;
    dispose(): void;
}>;
export declare const RECOVERY_DELAYS_MS: readonly number[];
export declare function createRecovery(sources: readonly RecoverySource[], timers?: Readonly<{
    setTimeout(callback: () => void, ms: number): unknown;
    clearTimeout(handle: unknown): void;
}>): RelayRecovery;
