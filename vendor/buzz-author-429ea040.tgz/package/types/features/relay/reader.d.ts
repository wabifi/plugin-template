import { type RelayProfiler } from "./profiling";
import type { ReadFilter, RelayEvent } from "./events";
import type { ReadTransport } from "./transport";
export type Priority = "foreground" | "background";
export type ReadOptions = {
    signal?: AbortSignal;
    priority?: Priority;
    /** A write preflight must start after its intent, never join an older in-flight read. */
    fresh?: boolean;
};
/** Finite, verified event reads. No retained event cache or claim of live freshness. */
export type RelayReader = {
    readStateSnapshot?(options?: ReadOptions): Promise<readonly RelayEvent[]>;
    /** One page of the relay's name-only profile search (see
     * `ReadTransport.searchProfiles`), under the same deadline and cancellation
     * as `read`. Absent when the transport has no such endpoint. */
    searchProfiles?(query: string, limit: number, page: number, options?: ReadOptions): Promise<readonly RelayEvent[]>;
    read(filters: readonly ReadFilter[], options?: ReadOptions): Promise<readonly RelayEvent[]>;
};
/** Session-owned scheduling and cancellation. Equal concurrent reads share work;
 * cancelling one consumer never cancels another. Completion releases all request state. */
export declare function createRelayReader(transport: ReadTransport | null, { timeoutMs, maxPending, profiling, }?: {
    timeoutMs?: number;
    maxPending?: number;
    profiling?: RelayProfiler;
}): {
    reader: RelayReader;
    /** Promote existing queued work without creating a consumer or a new deadline. */
    promote(matches: (filters: readonly ReadFilter[]) => boolean): void;
    invalidate(matches?: (filters: readonly ReadFilter[]) => boolean): void;
    dispose(): void;
};
