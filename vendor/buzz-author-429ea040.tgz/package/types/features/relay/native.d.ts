import { type ReadTransport, type Signer } from "./transport";
export declare const nativeWriteKinds: readonly [30078, 7, 9, 1984, 9000, 9001, 30030, 30175, 30177, 30178, 30315, 40003, 40100, 42000, 45010, 36211, 30620, 46020, 5];
/** Cancellation fences JS results; a dispatched native write may still complete. */
export declare function nativeRelayRequest(community: string, path: string, body?: unknown, signal?: AbortSignal): Promise<Response>;
/** Relay media through the native `buzz-media` scheme (`src-tauri/src/relay.rs`),
 * which signs each Blossom `get`, including every `Range` request. */
export declare function nativeMediaUrl(url: string): string;
export declare function nativeRelaySigner(community: string): Signer;
export declare function nativeRelayInfo(community: string, signal?: AbortSignal): Promise<Record<string, unknown>>;
export declare function connectNativeTransport(community: string, signal?: AbortSignal): Promise<ReadTransport>;
