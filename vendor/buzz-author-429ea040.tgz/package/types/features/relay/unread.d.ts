import type { InboxSnapshot } from "./inbox";
import type { ChannelQueries } from "./contracts";
import type { RelayEvent } from "./events";
import { type ReadTarget } from "./read-state-model";
import type { createReadState, ReadMutationResult, ReadSyncSnapshot } from "./read-state";
import type { RelayReader } from "./reader";
import { type ThreadFollowStorage } from "./thread-follows";
export type UnreadSnapshot = Readonly<{
    target: ReadTarget;
    /** Latest verified content evidence, including read and self-authored messages. */
    latestMessage?: Readonly<{
        id: string;
        createdAt: number;
    }>;
    /** null means unobserved/denied, never a fabricated zero or an exact relay total. */
    observedCount: number | null;
    attentionCount: number | null;
    coverage: "unknown" | "observed";
    freshness: "unknown" | "observed" | "stale";
    manual: "none" | "local-only" | "remote";
    error?: string | undefined;
}>;
export type MessageAttention = Readonly<{
    status: "unknown" | "ineligible" | "eligible";
    category?: "mention" | "direct" | "thread";
    /** The event mentions the viewer, excluding trusted workflow-owner attribution. */
    mentioned?: boolean;
    rootId?: string;
    /** The reply's conversation is still being looked up; it may become thread
     * attention when the lookup finishes. */
    pending?: boolean;
    unread: boolean;
    /** This row is explicitly forced unread during the current channel visit. */
    forced: boolean;
    viewing: boolean;
}>;
export type ThreadActivityItem = Readonly<{
    channelId: string;
    rootId: string;
    latestMessageId: string;
    authorId: string;
    workflowOwnerId?: string | undefined;
    createdAt: number;
    preview: string;
    unreadCount: number;
}>;
export type ThreadActivitySnapshot = Readonly<{
    channelId: string;
    /** null means activity evidence is unknown or access is denied. */
    items: readonly ThreadActivityItem[] | null;
    coverage: "unknown" | "observed";
    freshness: "unknown" | "observed" | "stale";
    error?: string | undefined;
}>;
export type ReadingHandle = Readonly<{
    /** Qualified visible rows only. This publishes no read intent and ends with the lease. */
    view(messageIds: readonly string[], visible: () => boolean): void;
    /** Only message IDs actually visible to the active consumer; no caller timestamps. */
    observe(messageIds: readonly string[]): Promise<void>;
    /** Bottom dwell through verified evidence; channel catch-up excludes attention. */
    catchUp(messageId: string, rootId?: string): Promise<void>;
    dispose(): void;
}>;
export interface UnreadCapability {
    inbox(): InboxSnapshot;
    subscribeInbox(listener: () => void): () => void;
    snapshot(target: ReadTarget): UnreadSnapshot;
    /** Same verified attention/frontier policy as badges, not a notification event source. */
    attention(channelId: string, messageId: string): MessageAttention;
    subscribe(target: ReadTarget, listener: () => void): () => void;
    activity(channelId: string): ThreadActivitySnapshot;
    subscribeActivity(channelId: string, listener: () => void): () => void;
    sync(): ReadSyncSnapshot;
    subscribeSync(listener: () => void): () => void;
    ensure(): Promise<void>;
    refresh(): Promise<void>;
    retrySync(): Promise<void>;
    /** Durable local intent revision, not sync-health changes. */
    revision(): number;
    /** Access/cache/connection retirement fence. */
    generation(): number;
    reading(channelId: string): ReadingHandle;
    /** Whether the viewer follows this canonical root: an explicit choice,
     * otherwise writing or replying anywhere in its thread. */
    following(channelId: string, rootId: string): boolean;
    /** Saves an explicit choice on this device; throws, unchanged, if not saved.
     * Wakes `subscribeSync` listeners. */
    follow(channelId: string, rootId: string, following: boolean): void;
    /** Explicit prefix intent, unlike individual-message visibility observations. */
    markThrough(target: ReadTarget, messageId: string): Promise<ReadMutationResult>;
    /** One immediate menu action over the selected verified message and loaded reply subtree. */
    markMessageUnread(channelId: string, messageId: string): Promise<ReadMutationResult>;
    markMessageRead(channelId: string, messageId: string): Promise<ReadMutationResult>;
    /** End the channel visit; the device-local sidebar force remains until next open. */
    leaveChannel(channelId: string): void;
    /** Reconcile the previous visit's sidebar force without clearing independent channel intent. */
    enterChannel(channelId: string): Promise<void>;
    /** Explicit channel prefix through retained verified evidence, including replies. */
    markChannelRead(channelId: string): Promise<ReadMutationResult>;
    /** Capture one prefix/time cut; each invocation queues that same intent for retry. */
    prepareChannelRead(channelId: string): () => Promise<ReadMutationResult>;
    /** `markChannelRead` serialised over every accessible listed channel that still
     * shows unread evidence or a local mark. Channels with nothing to clear are
     * skipped, so an already-read community costs no writes. One failing channel
     * does not stop the rest; the first failure is rethrown after the sweep. */
    markAllChannelsRead(): Promise<readonly ReadMutationResult[]>;
    markUnreadLocal(target: ReadTarget): Promise<ReadMutationResult>;
    clearUnreadLocal(target: ReadTarget): Promise<ReadMutationResult>;
    readonly syncedManualUnread: false;
}
/** Bounded verified evidence and one projection; no sidebar counters, sockets or implicit reads. */
export declare function createUnread({ reads, channels, reader, viewer, relayAuthor, signingAuthority, workflowAuthority, notify, follows, observeCatchUp, }: {
    reads: ReturnType<typeof createReadState>;
    channels: ChannelQueries;
    reader: RelayReader;
    viewer: string;
    relayAuthor?: string;
    signingAuthority?: string;
    workflowAuthority?: string | undefined;
    notify?: (listener: () => void) => void;
    follows?: ThreadFollowStorage;
    /** Catch-up rows of channels this unread state admits, for channel recency. */
    observeCatchUp?: (events: readonly RelayEvent[]) => void;
}): {
    capability: UnreadCapability;
    event(id: string): import("nostr-tools").VerifiedEvent | undefined;
    retainedEditIds(ids: readonly string[]): string[];
    accept: (batch: readonly RelayEvent[]) => boolean;
    purge: () => void;
    reconnect(): void;
    stale(): void;
    clear(): void;
    dispose(): void;
};
