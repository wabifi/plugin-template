import type { RelayReader } from "./reader";
import type { RelayWriter } from "./transport";
import { type RelayEvent } from "./events";
import { type ChannelLifecycleCommand, type ChannelLifecycleSettings } from "./channel-lifecycle-protocol";
/** No automatic or same-dialog retry after a request may have reached the relay. */
export declare class ChannelLifecycleUnconfirmed extends Error {
    constructor(reason: unknown);
}
export type DmVisibility = Readonly<{
    status: "idle" | "loading" | "ready" | "error";
    hidden: readonly string[];
    error?: string;
    /** Set with an error that a later retry can fix; see isTransientFailure. */
    transient?: true;
}>;
export interface ChannelLifecycleCapability {
    readonly available: boolean;
    load(channelId: string, signal?: AbortSignal): Promise<ChannelLifecycleSettings>;
    run(action: ChannelLifecycleCommand, channelId: string, signal?: AbortSignal): Promise<void>;
    snapshot(): DmVisibility;
    subscribe(listener: () => void): () => void;
    refreshVisibility(): Promise<void>;
    observeRemoval(listener: (channelId: string) => void): () => void;
}
export declare function createChannelLifecycle({ reader, writer, viewer, relayAuthor, canAccess, acceptDiscovery, removed, }: {
    reader?: RelayReader | undefined;
    writer?: RelayWriter | undefined;
    viewer: string;
    relayAuthor: string;
    canAccess(id: string): boolean;
    acceptDiscovery(events: readonly RelayEvent[]): void;
    removed(id: string): void;
}): {
    capability: ChannelLifecycleCapability;
    /** Abort work on `ids` and id-less visibility reads; without `ids`, everything. */
    cancel(ids?: readonly string[]): void;
    clear(): void;
    dispose(): void;
};
