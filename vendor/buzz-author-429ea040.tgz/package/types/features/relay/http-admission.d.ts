import type { ReadFilter } from "./events.ts";
import { ReadError } from "./errors.ts";
/** Admission owns starts, not retries or delivery semantics. An admitted write is
 * still sent once; a lost response is never permission to repeat it. */
export declare class ApiPaused extends ReadError {
    constructor(retryAfterMs: number);
}
export declare class ApiNotSent extends Error {
}
export declare class ApiCapacity extends ApiNotSent {
    constructor();
}
export type ApiFailure = Readonly<{
    error: string;
    quota?: "api";
    paused?: true;
    retryAfterMs?: number;
    sent?: false;
    /** A relay-shaped 401/403. An edge or proxy page (for example a VPN still
     * reconnecting) has the same status but is not the relay's answer. */
    denied?: true;
}>;
/** Only a correlated relay quota reason becomes a shared API cooldown. Local
 * broker concurrency 429 and arbitrary response text must not impersonate it. */
export declare function apiFailure(status: number, value: unknown): ApiFailure;
/** Consumes one bounded error body; success payloads remain their owner's concern.
 * `reason` may keep an exact, caller-allowed upstream refusal from that body. */
export declare function readApiFailure(response: Response, reason?: (body: unknown) => string | undefined): Promise<ApiFailure>;
type Ticket = {
    priority: "foreground" | "background";
    signal?: AbortSignal | undefined;
    start(): void;
    reject(error: Error): void;
    abort(): void;
};
/** One host/principal API lane, bounded like the broker's six-request ceiling.
 * Available capacity dispatches immediately; only server cooldowns pause starts.
 * Cooldowns reject queued work rather than spending a read's 10s deadline. */
export declare function createApiAdmission(): {
    /** Lossy snapshot lease; never consumes ordinary slots or start credit. */
    tryPresence(): (() => void) | undefined;
    presenceIdle: () => boolean;
    /** Retain bounded ownership across asynchronous auth and its final dispatch.
     * A cancelled unabortable signer keeps its slot until it settles: repeatedly
     * cancelling must not admit an unbounded number of outstanding sign prompts. */
    prepare<T>(work: () => Promise<T>): Promise<T>;
    idle: () => boolean;
    pause(milliseconds: number): void;
    run<T>(work: () => Promise<T>, signal?: AbortSignal, priority?: Ticket["priority"]): Promise<T>;
};
/** Wrap the actual fetch boundary in both hosts. No transparent request retry.
 * Normalize bounded error evidence while preserving the original status/headers. */
export declare function admittedApiRequest(lane: ReturnType<typeof createApiAdmission>, request: () => Promise<Response>, signal?: AbortSignal, priority?: Ticket["priority"], reason?: (body: unknown) => string | undefined): Promise<Response>;
/** The optional lane accepts only this bounded presence shape, never a priority hint. */
export declare function presenceFilter(raw: unknown): raw is ReadFilter[];
export declare function presenceText(response: Response): Promise<string>;
export {};
