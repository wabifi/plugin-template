export declare const OUTBOX_INPUT_MAX_BYTES: number;
/** Deterministic UTF-8 budget, used for both warm data and persisted records. */
export declare const byteSize: (value: unknown) => number;
/** `byteSize` of a list whose members never change, such as verified events.
 * A live window checks its budget on every message; each member is serialized
 * once instead of the whole window each time. */
export declare function listByteSize(values: readonly object[]): number;
export declare class ByteLru<T> {
    readonly maxEntries: number;
    readonly maxBytes: number;
    private items;
    private bytes;
    constructor(maxEntries: number, maxBytes: number);
    get(key: string): T | undefined;
    peek(key: string): T | undefined;
    set(key: string, value: T, bytes?: number): boolean;
    delete(key: string): void;
    clear(): void;
    keys(): string[];
    entries(): [string, T][];
    stats(): {
        entries: number;
        bytes: number;
    };
}
