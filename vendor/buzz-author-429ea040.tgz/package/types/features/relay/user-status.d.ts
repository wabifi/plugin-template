import { type RelayEvent } from "./events";
import type { RelayReader } from "./reader";
import type { RelayWriter } from "./transport";
export { USER_STATUS_KIND, STATUS_TEXT_LIMIT } from "./user-status-policy";
export type UserStatus = Readonly<{
    userId: string;
    text: string;
    emoji: string;
    updatedAt: number;
    expiresAt?: number;
}>;
export type StatusInput = Pick<UserStatus, "text" | "emoji" | "expiresAt">;
/** One community session owns replacement evidence, including clears and expired values.
 * Never discard a tombstone while retaining older values for the same author. */
export declare function createUserStatuses(reader: RelayReader, viewer?: string, writer?: RelayWriter, notify?: (listener: () => void) => void): {
    queries: Readonly<{
        snapshot: () => ReadonlyMap<string, Readonly<{
            userId: string;
            text: string;
            emoji: string;
            updatedAt: number;
            expiresAt?: number;
        }>>;
        subscribe(listener: () => void): () => void;
        watch: (ids: readonly string[]) => () => void;
        current(userId: string): Promise<Readonly<{
            userId: string;
            text: string;
            emoji: string;
            updatedAt: number;
            expiresAt?: number;
        }> | undefined>;
        save: (input: StatusInput) => Promise<void>;
        writable: boolean;
        refresh(): void;
    }>;
    accept: (events: readonly RelayEvent[]) => void;
    clear: () => void;
    reconnect(): void;
    dispose(): void;
};
export type UserStatuses = ReturnType<typeof createUserStatuses>["queries"];
