import type { RelayEvent } from "./events";
export type TypingEntry = Readonly<{
    channelId: string;
    threadRootId?: string;
    pubkey: string;
}>;
/** Session-owned activity from verified events; no event payloads or persistence. */
export declare function createTyping(viewer: string, canAccess: (channelId: string) => boolean, notify: (listener: () => void) => void): {
    capability: Readonly<{
        snapshot: () => readonly Readonly<{
            channelId: string;
            threadRootId?: string;
            pubkey: string;
        }>[];
        subscribe(listener: () => void): () => void;
    }>;
    accept: (events: readonly RelayEvent[], live?: boolean) => void;
    clear: () => void;
    dispose(): void;
};
