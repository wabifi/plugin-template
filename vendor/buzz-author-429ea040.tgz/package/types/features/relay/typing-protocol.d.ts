import type { EventTemplate } from "nostr-tools";
/** Typing carries conversation scope only, never draft content or recipients. */
export declare function validTypingTemplate(value: unknown): value is EventTemplate;
