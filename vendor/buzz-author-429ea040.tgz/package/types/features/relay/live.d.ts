import { type ObserverFrame } from "../agents/observer.ts";
import type { EventTemplate, VerifiedEvent } from "nostr-tools";
export declare const LIVE_CHANNEL_CAPACITY = 1022;
export declare const LIVE_BATCH_SIZE = 10;
export declare const LIVE_REPLAY_LIMIT = 500;
export declare const LIVE_RECOVERY_INTERVAL = 60000;
/** Flutter's RelaySocket.pingInterval: probe this often, and drop a socket that
 * stays silent for one more interval. Browsers expose no WebSocket ping, so the
 * probe is a CLOSE the relay always answers, outside its admission quota. */
export declare const LIVE_PING_INTERVAL = 30000;
/** Channel REQs awaiting EOSE at once. `scripts/live-setup-probe.mjs` compares others. */
export declare const SETUP_CONCURRENCY = 4;
/** How long one channel REQ may wait for EOSE before its route fails. */
export declare const SETUP_TIMEOUT_MS = 10000;
/** Host-owned server cooldown survives socket/POST replacement.
 * Healthy traffic has no inter-request delay; outstanding work is bounded below. */
export declare function createLiveAdmission(): {
    delay: () => number;
    setup(owner: object, busy: boolean): void;
    presenceReady: () => boolean;
    presenceDelay: () => number;
    tryPresence(): (() => void) | undefined;
    presenceSent(): void;
    presenceIdle: () => boolean;
    pause(seconds: number): void;
};
export type LiveAdmission = ReturnType<typeof createLiveAdmission>;
export type LiveRoute = Readonly<{
    id: string;
    channelId?: string;
    status: "pending" | "live" | "error" | "limited";
    /** EOSE establishes a stream, never proves historical completeness. */
    replay: "unknown" | "limited";
    error?: string;
}>;
export type LiveSnapshot = Readonly<{
    status: "unavailable" | "connecting" | "connected" | "retrying" | "error";
    routes: readonly LiveRoute[];
    error?: string;
    /** The relay's verbatim reason for refusing AUTH (`["OK", id, false, reason]`),
     * e.g. "restricted: …" or "error: …"; present only on the error it caused. */
    authRefusal?: string;
}>;
/** Transport provenance, not a history-completeness claim or permission to alert. */
export type LiveProvenance = Readonly<{
    phase: "replay" | "live";
    channelId?: string;
    /** Original wire scope for ambiguous channel traffic; never alert attribution. */
    sourceChannels?: readonly string[];
}>;
export declare function liveProvenance(value: unknown): LiveProvenance;
export type LiveCallbacks = {
    /** Legacy/missing provenance reconciles quietly; it is never implicitly fresh. */
    receive(events: readonly VerifiedEvent[], provenance?: LiveProvenance): void;
    /** Host-only encrypted telemetry route; never ordinary history reconciliation. */
    telemetry?(event: VerifiedEvent, generation: number): void;
    /** Decoded host DTO on the browser transport. */
    observer?(frame: ObserverFrame, generation: number): void;
    presence?(event: VerifiedEvent): void;
    state(snapshot: LiveSnapshot): void;
    established(channels?: string | readonly string[]): void;
    /** Periodic repair hint, not membership or historical-completeness evidence. */
    recover?(): void;
    denied(channelId: string, reason: string): void;
};
export type LiveSubscription = {
    /** Local broker handle; not a relay subscription ID. */
    identity?(): string | undefined;
    publish?(event: VerifiedEvent, signal: AbortSignal): Promise<string>;
    /** Purpose-bound host path when generic socket publication is unavailable. */
    publishTyping?(event: VerifiedEvent, signal: AbortSignal): Promise<string>;
    update(channels: readonly string[], joined?: readonly string[]): void;
    /** Host demand only: reorder existing pending routes, never grant new interests. */
    prioritize?(channels: readonly string[]): void;
    observe?(generation: number | null): void;
    /** Ephemeral status: true = accepted, false = unconfirmed/refused, null = unsent.
     * Admission skips report their remaining delay; no durable queue is created. */
    publishPresence?(status: "online" | "away" | "offline", signal: AbortSignal): Promise<boolean | null | {
        retryAfterMs: number;
    }>;
    watchPresence?(authors: readonly string[]): void;
    retry(): void;
    dispose(): void;
};
/** Demand-scoped ephemeral authors, never a channel/history interest. */
export declare function livePresenceAuthors(input: unknown): string[];
/** IDs, not names/previews, define interest identity. Never silently truncate. */
export declare function liveChannels(input: unknown): string[];
/** Batchability is part of the same interest snapshot, not a priority hint. */
export declare function liveJoined(channels: readonly string[], input: unknown): string[];
export declare const CHANNEL_KINDS: number[];
/** One authenticated socket, bounded joined-channel batches, singleton previews and two globals.
 * Recent replay is opportunistic: finite reads own catch-up and history bounds. */
export declare function subscribeRelayTraffic(url: string, sign: (event: EventTemplate) => Promise<VerifiedEvent>, viewer: string, callbacks: LiveCallbacks, socketFactory?: (url: string) => WebSocket, admission?: LiveAdmission, setupConcurrency?: number, setupTimeoutMs?: number): LiveSubscription;
