import { type SidebarAssignmentIntent, type SidebarSortMode, type SidebarFilterMode } from "./sidebar-preferences.ts";
/** Tombstone the section and reset its live placements in the same record. */
export declare function editSidebarSectionRemoval(current: Record<string, unknown>, createdAt: number, sectionId: string, now?: number): Record<string, unknown>;
/** Requested live sections first, then unlisted live ones; every order is restamped. */
export declare function editSidebarSectionOrder(current: Record<string, unknown>, createdAt: number, sectionIds: readonly string[], now?: number): Record<string, unknown>;
export declare function validSidebarChannelId(channelId: string): boolean;
export declare function validSidebarAssignment(intent: SidebarAssignmentIntent): boolean;
export declare function validSidebarSectionRemoval(sectionId: string): boolean;
export declare function validSidebarSectionOrder(sectionIds: readonly string[]): boolean;
export declare function validSidebarSort(group: string, mode: SidebarSortMode, sectionIds: readonly string[]): boolean;
export declare function validSidebarFilter(group: string, mode: SidebarFilterMode, sectionIds: readonly string[], activeWindowSeconds?: number | null): boolean;
export declare function editSidebarAssignment(current: Record<string, unknown>, createdAt: number, intent: SidebarAssignmentIntent, now?: number): Record<string, unknown>;
export declare function editSidebarSort(current: Record<string, unknown>, createdAt: number, group: string, mode: SidebarSortMode, now?: number): Record<string, unknown>;
export declare function editSidebarFilter(current: Record<string, unknown>, createdAt: number, group: string, mode: SidebarFilterMode, now?: number, activeWindowSeconds?: number | null): Record<string, unknown>;
export declare function editSidebarToggle(current: Record<string, unknown>, channelId: string, field: "starred" | "muted", enabled: boolean, now?: number): Record<string, unknown>;
