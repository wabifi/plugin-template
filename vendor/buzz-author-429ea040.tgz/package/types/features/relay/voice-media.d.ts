/** Host-owned media boundary. Audio bytes never become event content. */
export declare const MAX_VOICE_SECONDS = 300;
export declare const MAX_VOICE_BYTES: number;
export type VoiceRecording = Readonly<{
    file: File;
    duration: number;
    waveform: readonly number[];
}>;
export declare function validateRecording(value: VoiceRecording): void;
