/** One community and viewer's durable partition, persisted as `origin:viewer`
 * by the outbox, read state, view state and preference stores. Changing these
 * bytes orphans saved data that leaving a community can no longer purge. */
export declare function relayPartition(origin: string, viewer: string): string;
/** The inverse of `relayPartition`. Origins may contain `:`; viewers never do. */
export declare function splitPartition(partition: string): {
    communityOrigin: string;
    viewer: string;
} | undefined;
type PartitionedTransport = Readonly<{
    scope?: string | undefined;
    relayAuthor: string;
    viewer: string;
}>;
/** Supported transports set `scope` to the normalized community origin; the
 * relay author only partitions transports that omit it. */
export declare function transportOrigin(transport: PartitionedTransport): string;
export declare function transportPartition(transport: PartitionedTransport): string;
export {};
