/** Lightweight application-body boundary, for verified records or session-owned local intent. */
export declare function objectBody(content: string): Record<string, unknown> | undefined;
export declare function isObject(value: unknown): value is Record<string, unknown>;
