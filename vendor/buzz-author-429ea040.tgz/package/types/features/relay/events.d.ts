import { type VerifiedEvent } from "nostr-tools";
/** A relay event whose signature has been verified at the transport boundary. */
export type RelayEvent = VerifiedEvent;
/** Event payload shared by locally authored intent and verified relay records.
 * Only RelayEvent carries signature verification; local intent never establishes relay authority. */
export type EventData = Readonly<Pick<RelayEvent, "id" | "pubkey" | "created_at" | "kind" | "content" | "tags">>;
export type ReadFilter = Readonly<{
    kinds?: readonly number[];
    ids?: readonly string[];
    /** NIP-01 single-letter tag filters, including references (#e/#a) and topics (#t). */
    [tag: `#${string}`]: readonly string[] | undefined;
    limit: number;
    authors?: readonly string[];
    /** Read from the writer when resolving uncertain publication or admission. */
    consistency?: "strong";
    /** NIP-AR artifact reads: current heads only, or a `d`'s revision history. */
    artifact?: "current" | "history";
    /** NIP-AR artifact page offset (≤ 10,000). */
    offset?: number;
    until?: number;
    since?: number;
    "#h"?: readonly string[];
    "#d"?: readonly string[];
    "#p"?: readonly string[];
    /** Buzz relay extensions for channel history windows. */
    top_level?: boolean;
    include_aux?: boolean;
    include_summaries?: boolean;
    before_id?: string;
    /** HTTP bridge finite search, home-feed, and thread traversal extensions. */
    search?: string;
    search_mode?: "prefix" | "fulltext";
    /** Only for relays advertising `buzz-search-sort`. */
    search_sort?: "newest";
    page?: number;
    feed_types?: readonly string[];
    thread_window?: boolean;
    depth_limit?: number;
    thread_cursor?: number;
    thread_cursor_id?: string;
}>;
export declare function hasEventProof(event: EventData): boolean;
export declare function eventDto(value: unknown): RelayEvent;
/** A whole query response; one bad event rejects it, as relay reads do. */
export declare function eventsDto(value: unknown): RelayEvent[];
/** One HTTP connection's bounded proof memo, not an event/result cache. Only a
 * matching content hash AND exact signature can reuse a successful verification.
 * Retains no payload, authorization, freshness or caller-supplied proof symbols. */
export declare function createEventVerifier(): (value: unknown) => RelayEvent;
export declare const tag: (event: RelayEvent, name: string) => string | undefined;
export declare const hasTag: (event: RelayEvent, name: string, value: string) => boolean;
/** Later created_at wins; ties break on lower id so replay order cannot flip the result. */
export declare function newer<T extends EventData>(current: T | undefined, candidate: T): T;
