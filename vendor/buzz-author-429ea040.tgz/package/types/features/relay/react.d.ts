import type { ChannelMessage, ChannelQueries } from "./contracts";
import type { ProfileQueries } from "./profile-directory";
export declare function useChannelList(queries: ChannelQueries): Readonly<{
    status: import("./contracts").ListStatus;
    coverage?: "partial";
    asOf?: number;
    activityStatus?: "idle" | "loading" | "ready" | "error" | "unavailable";
    channels: readonly import("./contracts").ChannelSummary[];
    error?: string;
}>;
export declare function useChannelWindow(queries: ChannelQueries, channelId: string): Readonly<{
    channelId: string;
    status: import("./contracts").WindowStatus;
    rows: readonly ChannelMessage[];
    hasMore: boolean;
    loadingOlder: boolean;
    error: string | undefined;
    freshness?: "cached" | "verified";
    historyLimited?: boolean;
    refreshing?: boolean | undefined;
}>;
export declare function useRowProfiles(queries: ProfileQueries, rows: readonly ChannelMessage[]): ReadonlyMap<string, Readonly<{
    name: string;
    nameIsFallback?: true;
    username?: string;
    picture?: string;
    about?: string;
    nip05?: string;
    isAgent?: true;
    ownerPubkey?: string;
}>>;
/** Subscribe to replacement as well as connection readiness; never capture a startup session once. */
export declare function useRelayConnection(relay: import("./service").RelayData): Readonly<{
    status: "disconnected" | "connecting" | "ready" | "error";
    generation: number;
    scope?: string;
    origin?: string;
    session: import("./session").RelaySession;
    viewer?: string;
    error?: string;
    cached?: true;
    restoring?: true;
}>;
