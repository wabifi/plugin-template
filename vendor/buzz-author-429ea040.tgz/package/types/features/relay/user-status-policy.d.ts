export declare const USER_STATUS_KIND = 30315;
export declare const STATUS_TEXT_LIMIT = 100;
/** Wire limits use UTF-16 units. Callers own trimming and optional-tag policy. */
export declare function validStatusText(text: string, emoji: string): boolean;
