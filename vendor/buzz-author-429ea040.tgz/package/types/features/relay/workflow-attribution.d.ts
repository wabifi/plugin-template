import { type EventData } from "./events";
/** Verified ownership attribution. Callers must enforce recipients and permissions.
 * Authority must be the configured community's explicit NIP-11 self, not its contact key. */
export declare function workflowOwner(event: EventData, authority: string | undefined): string | undefined;
/** Compact surfaces still identify automation, never the owner as the sender. */
export declare function workflowLabel(ownerName: string): string;
/** Delegated mention provenance. Normal `p` tags can originate in template
 * substitutions; only explicit owner-authored targets grant prompt authority. */
export declare function workflowMentionOwner(event: EventData, authority: string | undefined, agent: string): string | undefined;
