import { type RelayEvent } from "./events";
import { type ReadStateHost } from "./read-state-host";
import { type ReadJournal, type ReadStateStorage } from "./read-state-storage";
import type { Priority, RelayReader } from "./reader";
export type ReadSyncSnapshot = Readonly<{
    capability: "unsupported" | "read-only" | "frontier-sync";
    status: "loading" | "local" | "pending" | "accepted" | "reconciled" | "stale" | "error";
    /** Atomic marker enumeration only; says nothing about completeness of message history. */
    completeness: "unknown" | "snapshot" | "bounded";
    error?: string | undefined;
}>;
export type ReadMutationResult = Readonly<{
    operationId: string;
    durability: "saved";
    sync: "pending" | "local-only";
}>;
export type ReadPublisherLock = (signal: AbortSignal, work: () => Promise<void>) => Promise<void>;
export declare function browserReadPublisherLock(scope: string): ReadPublisherLock | undefined;
/** Which broader mark covers a mark, as in `CoveredFrontier`. `home` gives
 * the channel of a top-level message when it is known: from a loaded message,
 * or from a channel saved with the mark. */
export type MarkCoverage = Readonly<{
    covered: (key: string, frontier: (key: string) => number | undefined, home: (id: string) => string | undefined) => string | undefined;
    /** The channel of a loaded, verified top-level message. */
    home: (id: string) => string | undefined;
}>;
/** One durable domain owner. Read intent is not cache; one tab never saves over another's intent. */
export declare function createReadState({ viewer, reader, host, storage, lock, notify, now, debounceMs, broadcastName, }: {
    viewer: string;
    reader: RelayReader;
    host: ReadStateHost | undefined;
    storage: ReadStateStorage;
    lock?: ReadPublisherLock | undefined;
    notify?: (listener: () => void) => void;
    now?: () => number;
    debounceMs?: number;
    broadcastName?: string | undefined;
}): {
    ready: Promise<void>;
    snapshot: () => Readonly<{
        capability: "unsupported" | "read-only" | "frontier-sync";
        status: "loading" | "local" | "pending" | "accepted" | "reconciled" | "stale" | "error";
        /** Atomic marker enumeration only; says nothing about completeness of message history. */
        completeness: "unknown" | "snapshot" | "bounded";
        error?: string | undefined;
    }>;
    state: () => Readonly<{
        frontiers: Readonly<Record<string, number>>;
        overrides: Readonly<Record<string, import("./read-state-model").Override>>;
    }>;
    localUnread: (key: string) => number | undefined;
    revision: () => number;
    /** Lets the next save drop marks that broader marks already cover. */
    setCoverage(next: MarkCoverage | undefined): void;
    /** The saved channel of a message that a kept mark names. */
    home: (id: string) => string | undefined;
    /** Saves channels found for marked messages (from signed events) and
     * drops the marks that they show are covered. Like a synced update, this
     * changes no read, so it publishes nothing. */
    learnHomes: (found: Readonly<Record<string, string>>) => Promise<void>;
    subscribe(listener: () => void): () => void;
    refresh: (priority?: Priority) => Promise<void>;
    ensure: () => Promise<void>;
    flush: () => Promise<void>;
    read: (key: string, timestamp: number, valid: (current: ReadJournal) => boolean, explicit?: boolean, clearLocalKeys?: readonly string[]) => Promise<Readonly<{
        operationId: string;
        durability: "saved";
        sync: "pending" | "local-only";
    }>>;
    clearLocalUnread: (key: string, keys: readonly string[], valid: (current: ReadJournal) => boolean) => Promise<Readonly<{
        operationId: string;
        durability: "saved";
        sync: "pending" | "local-only";
    }>>;
    /** Atomic explicit subtree read; local-only hosts clear intent without fabricating frontiers. */
    readMessages: (messages: readonly Readonly<{
        key: string;
        timestamp: number;
        channelId: string;
        rootId?: string | undefined;
    }>[], clearForce: string | undefined, valid: (current: ReadJournal) => boolean) => Promise<{
        operationId: string;
        durability: "saved";
        sync: "local-only" | "pending";
    }>;
    markLocalUnread: (key: string, valid: () => boolean) => Promise<Readonly<{
        operationId: string;
        durability: "saved";
        sync: "pending" | "local-only";
    }>>;
    accept(events: readonly RelayEvent[]): void;
    stale(): void;
    dispose(): void;
};
