import type { UploadedAttachment } from "./attachments";
import { type CustomEmoji } from "./emoji";
import { type RelayEvent } from "./events";
import type { RelayReader } from "./reader";
import type { RelayWriter } from "./transport";
export type EmojiSnapshot = Readonly<{
    status: "idle" | "loading" | "ready" | "error";
    entries: readonly CustomEmoji[];
    /** The viewer's own latest set: the only one this client may republish. */
    mine: readonly CustomEmoji[];
    error?: string | undefined;
}>;
export type EmojiAuthoring = Readonly<{
    writer: RelayWriter;
    upload?(file: File, signal: AbortSignal): Promise<UploadedAttachment>;
}>;
/** Community-owned latest complete member sets, including empty replacement evidence.
 * No LRU eviction: forgetting a replacement can resurrect a removed shortcode. */
export declare function createEmojiDirectory(reader: RelayReader, notify?: (listener: () => void) => void, viewer?: string, authoring?: EmojiAuthoring): {
    queries: Readonly<{
        snapshot: () => Readonly<{
            status: "idle" | "loading" | "ready" | "error";
            entries: readonly CustomEmoji[];
            /** The viewer's own latest set: the only one this client may republish. */
            mine: readonly CustomEmoji[];
            error?: string | undefined;
        }>;
        subscribe(listener: () => void): () => void;
        ensure: () => Promise<void>;
        refresh: () => Promise<void>;
        remove?: (name: string) => Promise<void>;
        upload?: (file: File, signal: AbortSignal) => Promise<UploadedAttachment>;
        add?: (name: string, url: string) => Promise<string>;
    }>;
    accept: (incoming: readonly RelayEvent[]) => void;
    clear: () => void;
    reconnect(): void;
    tags(content: string): string[][];
    dispose(): void;
};
