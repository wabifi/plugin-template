import type { Context, Inject } from "@deepseek-ai/cordis";
import type * as React from "react";
import type { JsonValue } from "../features/navigation/targets";
export type PluginManifest = Readonly<{
    id: string;
    name: string;
    apiVersion: 1;
    description?: string;
    /** Author-supplied browsing metadata. It never grants host capabilities. */
    discovery?: Readonly<{
        /** Stable category slug. Hosts may group unrecognized values under Other. */
        category?: string;
        /** Readable tags: 1–80 UTF-8 bytes each, no control characters, at most 16.
         * Duplicate comparison collapses whitespace and uses Unicode lowercase. */
        tags?: readonly string[];
    }>;
    host?: Readonly<{
        commands?: readonly Readonly<{
            id: string;
            program: string;
            args: readonly string[];
            /** Opt-in UTF-8 stdin bound, at most 65536 bytes; absent means no input. */
            maxInputBytes?: number;
            /** Maximum UTF-8 stdout bytes; defaults to 4096, bounded at 1048576. */
            maxOutputBytes?: number;
        }>[];
        networkOrigins?: readonly string[];
        /** Programs the plugin may start with `host.spawn`; the caller's
         * arguments follow the declared ones. */
        processes?: readonly Readonly<{
            id: string;
            program: string;
            args?: readonly string[];
            /** Run the copy the app ships, never one on PATH. */
            bundled?: boolean;
        }>[];
        /** The plugin may serve MCP servers to its agents with `host.serveMcp`. */
        mcp?: boolean;
        /** The plugin may read files with `host.readFile` and resolve directories
         * with `host.resolveDirectory`, with the user's own access. */
        files?: boolean;
    }>;
}>;
export type PluginModule = {
    inject?: Inject;
    apply: (ctx: Context) => void | Promise<void>;
};
/** `community` is the open community; `identity` is shared across communities. */
export type PluginDataScope = "community" | "identity";
export type PluginDataOptions = Readonly<{
    scope?: PluginDataScope;
}>;
/** Keys moved from the shared webview `localStorage`; the rest were already stored or too large. */
export type PluginDataAdoption = Readonly<{
    adopted: string[];
    skipped: string[];
}>;
export type PluginData = {
    /** The stored JSON value, or undefined when the key is absent. */
    get(key: string, options?: PluginDataOptions): Promise<JsonValue | undefined>;
    /** JSON only; the host bounds one value to 1 MiB. */
    set(key: string, value: JsonValue, options?: PluginDataOptions): Promise<void>;
    /** False when the key was already absent. */
    delete(key: string, options?: PluginDataOptions): Promise<boolean>;
    keys(prefix?: string, options?: PluginDataOptions): Promise<string[]>;
    /** Move named keys out of the shared webview `localStorage` into this plugin's data once.
     * A key already stored is skipped; a value over 1 MiB is skipped, never truncated. */
    adoptLocalStorage(keys: readonly string[], options?: PluginDataOptions): Promise<PluginDataAdoption>;
    readFile(name: string, options?: PluginDataOptions): Promise<Uint8Array>;
    writeFile(name: string, bytes: Uint8Array, options?: PluginDataOptions): Promise<void>;
    /** False when the file was already absent. */
    deleteFile(name: string, options?: PluginDataOptions): Promise<boolean>;
    listFiles(options?: PluginDataOptions): Promise<string[]>;
};
declare module "@deepseek-ai/cordis" {
    interface Context {
        react: typeof React;
        /** Scoped automatically to the calling plugin; the plugin cannot name another. */
        readonly storage: PluginData;
        readonly pluginOwner?: Readonly<{
            id: string;
            revision: string;
            /** Bundled plugins ship with the app; external ones are installed or dev-loaded. */
            source?: "bundled" | "external";
        }>;
    }
}
