import type { Context } from "@deepseek-ai/cordis";
export type Contribution<T> = Readonly<T & {
    key: string;
    pluginId: string;
    revision: string;
    /** Where the owning plugin came from; absent for hand-built registries. */
    source?: "bundled" | "external";
}>;
/** How strongly a contribution claims a target: lower wins, default 0. Bands by
 * convention: -10 specialises a known plugin, 0 default/specific, 100 catch-all. */
export type MatchOrder = number | ((target: string) => number);
/** Among active matches, the lowest order for this target wins; ties fall to the
 * contribution key so activation or re-enable order never decides. A throwing
 * matcher is skipped; a throwing or non-finite order counts as the default. */
export declare function resolveMatch<T extends {
    matches(target: string): boolean;
    order?: MatchOrder | undefined;
}>(entries: readonly Contribution<T>[], target: string): Readonly<T & {
    key: string;
    pluginId: string;
    revision: string;
    /** Where the owning plugin came from; absent for hand-built registries. */
    source?: "bundled" | "external";
}> | undefined;
export declare function createContributions<T extends {
    id: string;
}>(root: Context): {
    snapshot: () => readonly Readonly<T & {
        key: string;
        pluginId: string;
        revision: string;
        /** Where the owning plugin came from; absent for hand-built registries. */
        source?: "bundled" | "external";
    }>[];
    subscribe(listener: () => void): () => void;
    register(ctx: Context, value: T): void;
};
