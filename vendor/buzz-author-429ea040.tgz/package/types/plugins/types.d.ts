import type { PluginManifest } from "./api";
/** A manifest plus the fork facts this build reads beside the shared contract. */
export type ManifestWithNeeds = PluginManifest & {
    /** What the plugin needs on this computer (CLO-347); unknown values mean a
     * newer Wabifi, not an install error. */
    needs?: readonly string[];
};
/** The journal states before OPEN (fork/plugin-updates.md); the new version is
 * still closed and may return to the previous revision automatically. */
export declare const UPDATE_STATES: readonly ["staged", "quiesced", "snapshotted", "switched", "checked", "open", "returned", "pending"];
export type UpdateState = (typeof UPDATE_STATES)[number];
export type UpdateAgent = {
    id: string;
    running: boolean;
    /** Unix seconds when the agent was slept; the replay floor after OPEN. */
    sleptAt?: number;
};
export type PluginUpdateKind = "update" | "restore";
/** One chosen retry window, in the person's local time. */
export type PluginUpdateWindow = {
    startHour: number;
    endHour: number;
};
/** The one nightly window this build offers; mirrors native's named hours. */
export declare const NIGHTLY_UPDATE_WINDOW: {
    readonly startHour: 2;
    readonly endHour: 5;
};
export type PluginUpdateStatus = {
    id: string;
    state: UpdateState;
    version: string;
    revision: string;
    reason?: string;
    agents?: UpdateAgent[];
    /** The update may resume by itself once the plugin's agents are idle. */
    retryWhenIdle?: boolean;
    /** What the candidate declares it needs; `ai` decides the engine check. */
    needs?: readonly string[];
    /** `update` replaces the installed revision; `restore` puts back a copy. */
    kind?: PluginUpdateKind;
    /** The chosen nightly retry window, when one was scheduled. */
    window?: PluginUpdateWindow | null;
};
/** What the person sees before confirming a restore. */
export type PluginRestoreCopy = {
    /** The copy's date, `YYYY-MM-DD`. */
    date: string;
    /** The revision whose code wrote the copy. */
    revision: string;
    bytes: number;
    /** False when the version that wrote the copy is no longer installed. */
    restorable: boolean;
    reason?: string | null;
    /** Display names of the plugin's agents that a restore restarts. */
    agents?: readonly string[];
};
/** A state before OPEN is closed: nothing of the new version accepts work. */
export declare function updateClosed(plugin: Pick<PluginInfo, "update">): boolean;
export type PluginInfo = {
    manifest: ManifestWithNeeds;
    source: "bundled" | "external";
    enabled: boolean;
    revision: string;
    previous: string | null;
    hasSignature?: boolean;
    publisher?: string | null;
    rollbackBlockedReason?: string | null;
    reloadable: boolean;
    error: string | null;
    /** Communities whose plugin directory installed it; absent or null = installed by hand. */
    communities?: string[] | null;
    /** This revision came from a folder made on this Mac (fork/local-plugins.md). */
    madeHere?: boolean;
    /** The update journal for this plugin, when one exists (CLO-348 D4). */
    update?: PluginUpdateStatus | null;
    readmeRevision?: string | null;
    iconPngRevision?: string | null;
    iconJpgRevision?: string | null;
};
export type Catalog = {
    profile: string;
    location: string;
    plugins: PluginInfo[];
};
export type ManagementAction = "enable" | "disable" | "pause" | "resume" | "remove" | "rollback";
export type StorageResult = {
    status: "ready";
    catalog: Catalog;
    externalPluginsPaused: boolean;
} | {
    status: "recovery";
    reason: string;
    canReset: boolean;
};
export type ConfigurationState = {
    status: "loading";
} | StorageResult;
export type ImportPreview = {
    token: string;
    source: string;
    commit: string | null;
    candidates: {
        path: string;
        manifest: ManifestWithNeeds;
        revision: string;
        publisher?: string | null;
        readmeRevision?: string | null;
        iconPngRevision?: string | null;
        iconJpgRevision?: string | null;
    }[];
    warnings: string[];
};
export type ImportFile = {
    path: string;
} & ({
    text: string;
    base64?: never;
} | {
    base64: string;
    text?: never;
});
export type PluginImports = {
    folder(): Promise<ImportPreview | null>;
    files(source: string, files: ImportFile[]): Promise<ImportPreview | null>;
    /** `authorization` is a NIP-98 token signed for exactly `repository`. */
    git(repository: string, reference: string, authorization?: string): Promise<ImportPreview | null>;
    /** A directory install passes the pins it must match, the community it is
     * for, and the access the person accepted (a sha256 hex). */
    install(token: string, path: string, pin?: Pin, acceptedAccessHash?: string): Promise<StorageResult>;
    /** CK's shared source: one pinned artifact and its NIP-PS release signature. */
    https?(sha256: string): Promise<ImportPreview | null>;
    discard(token: string): Promise<void>;
};
export type Pin = {
    list: string;
    listing: string;
    community: string;
};
/** What removing a plugin would take with it (fork/local-plugins.md). */
export type PluginRemovalParts = {
    /** Saved agents this exact plugin created. */
    agents: number;
    /** Its builder worktree, when Git lists it at the expected path and branch. */
    workingCopy: boolean;
    /** Bytes of your saved data this plugin keeps on this Mac. */
    dataBytes: number;
};
/** One saved agent whose plugin is no longer installed. */
export type ReconcileAgent = {
    id: string;
    name: string;
};
/** The native ownership ledger's report; orphans are never deleted. */
export type PluginReconcile = {
    orphans: readonly ReconcileAgent[];
};
/** What a removal could not clean up; empty fields mean that part is gone. */
export type PluginRemovalOutcome = {
    /** Agent names left behind; the leftovers notice deletes them through Agents. */
    agentsLeft: readonly string[];
    workingCopyLeft: boolean;
    /** The saved data was kept and why, as one plain sentence. */
    dataLeftReason?: string | null;
};
/** One step of a plugin update; see fork/plugin-updates.md. */
export type PluginUpdateRequest = {
    step: "stage" | "quiesced" | "snapshot" | "switch" | "check" | "open" | "pending" | "return" | "retry" | "schedule" | "restore-swap";
    id: string;
    version?: string;
    token?: string;
    path?: string;
    pin?: Pin;
    agents?: readonly UpdateAgent[];
    reason?: string;
    pending?: boolean;
    /** The access the person agreed to, computed from the listing they saw. */
    acceptedAccessHash?: string;
    /** The candidate's access now, checked before a retry installs anything. */
    candidateAccessHash?: string;
    /** `null` schedules "when it's not working"; a window schedules that time. */
    window?: PluginUpdateWindow | null;
};
/** A removal's new catalog plus the parts it could not clean up. */
export type PluginRemovalRun = PluginRemovalOutcome & {
    result: StorageResult;
    /** The person chose to delete their saved data and it is gone. */
    dataDeleted: boolean;
};
