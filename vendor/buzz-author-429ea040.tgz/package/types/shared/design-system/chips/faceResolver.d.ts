import { type ChipAddress, type ChipKind } from "./address";
/**
 * What a chip shows. Derived from an address, never stored in the document.
 *
 * Keeping the face out of the document is the load-bearing decision: if a
 * display name lived in the draft, every profile rename would be an edit to
 * the person's unsent message — dirtying it and polluting undo history. So the
 * document holds the address and the face is looked up at render time.
 */
export type ChipFace = {
    /** The compact label a person reads. Never the identity. */
    label: string;
    avatarUrl?: string | null;
    /** Live status where the kind has one; absent means "no status to show". */
    status?: "online" | "busy" | "offline";
    /** True while the face is still being fetched, so a chip can show a skeleton. */
    loading: boolean;
    /**
     * Whether `label` is a real display name or a stand-in derived from the id.
     * Assistive semantics need this: announcing an abbreviated identity tells a
     * screen-reader user nothing, so an unresolved chip says so instead.
     */
    resolved: boolean;
};
/** The face shown before anything is known, and if a lookup finds nothing. */
export declare function unresolvedFace(address: ChipAddress): ChipFace;
/**
 * A readable stand-in when an identity cannot be resolved.
 *
 * Deliberately an abbreviation of the id rather than a raw 64-character key: a
 * chip's face must never expose the full identity, because a face that shows a
 * key is the defect the current client shipped.
 */
export declare function fallbackLabel(address: ChipAddress): string;
export type ChipFaceSource = {
    /** Synchronous read from whatever this surface already knows. */
    peek: (address: ChipAddress) => ChipFace | undefined;
    /** Kicks off a fetch for an address the cache does not hold yet. */
    request?: (address: ChipAddress) => void;
};
type Listener = () => void;
/**
 * Resolves chip faces from addresses, and tells subscribers when one changes.
 *
 * This is a module-level cache holding community-scoped data, so it must be
 * reset when the community changes or a name from the previous community leaks
 * into the new one. See `resetChipFaces`.
 */
declare class ChipFaceRegistry {
    private faces;
    private listeners;
    private source;
    private requested;
    setSource(source: ChipFaceSource | null): void;
    /**
     * The current face for an address. Always returns something renderable —
     * a chip never has "no face", it has an unresolved one.
     *
     * The returned object must be reference-stable between changes. React's
     * `useSyncExternalStore` compares snapshots by identity, so handing back a
     * fresh object each call is an infinite render loop that tears down the
     * whole subtree — which is exactly what a freshly-built unresolved face did
     * here. Unresolved faces are therefore cached like resolved ones.
     */
    get(address: ChipAddress): ChipFace;
    /** Records a resolved face and notifies anything rendering that address. */
    put(address: ChipAddress, face: ChipFace): void;
    subscribe(listener: Listener): () => void;
    reset(): void;
    private emit;
}
export declare const chipFaces: ChipFaceRegistry;
/**
 * Clears every resolved face.
 *
 * Must be called when the community changes. A face resolved in one community
 * is not valid in another, and a stale name surviving a switch is the exact
 * leak the desktop client's `resetCommunityState()` inventory exists to
 * prevent.
 */
export declare function resetChipFaces(): void;
/**
 * The sigil a kind is introduced by, independent of any lookup.
 *
 * A message and a link have no sigil a reader would recognise, so they carry an
 * icon instead and prefix nothing.
 */
export declare const CHIP_KIND_TRIGGER: Record<ChipKind, string>;
export {};
