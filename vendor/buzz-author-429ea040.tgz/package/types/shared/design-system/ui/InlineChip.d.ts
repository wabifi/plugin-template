import type { ChipAddress } from "../chips/address";
import { type ChipFace } from "../chips/faceResolver";
export declare function InlineChip({ address, face: suppliedFace, qualifier, interactive, onActivate, }: {
    address: ChipAddress;
    /** Scoped display data supplied by a host that already owns identity lookup. */
    face?: ChipFace;
    /** Optional host-owned distinction; never part of the address or authored name. */
    qualifier?: {
        text: string;
        accessibleLabel: string;
        reveal?: boolean;
    } | undefined;
    /**
     * An inert rendering for places where even a preview would compete with the
     * surrounding interaction, such as a future editable document boundary.
     */
    interactive?: boolean;
    /** An explicit owner-provided action; previews never imply a deep-open. */
    onActivate?: (address: ChipAddress) => void;
}): import("react").JSX.Element;
