import { RadioGroup as BaseRadioGroup } from "@base-ui/react/radio-group";
import { Radio as BaseRadio } from "@base-ui/react/radio";
import { type ComponentProps, type ReactNode } from "react";
/** Compose inside Field so each Radio has its own labelled Field.Item. */
export declare function RadioGroup<Value>({ children, ...props }: Omit<BaseRadioGroup.Props<Value>, "className">): import("react").JSX.Element;
export declare function Radio({ label, description, variant, id, ...props }: Omit<ComponentProps<typeof BaseRadio.Root>, "className" | "children"> & {
    label: ReactNode;
    description?: ReactNode;
    variant?: "default" | "card" | "tile";
}): import("react").JSX.Element;
