import type { ReactNode } from "react";
/** Shared header frame. Product identity and controls are supplied through slots.
 * Workspace dragging and tab strips are owned by the layout, not this frame. */
export declare function PanelHeader({ title, icon, navigation, actions, variant, }: {
    title: ReactNode;
    icon?: ReactNode;
    navigation?: ReactNode;
    actions?: ReactNode;
    variant?: "default" | "compact";
}): import("react").JSX.Element;
/** Static identity aligned with the navigation tabs, without adding a tab stop. */
export declare function PanelHeaderLabel({ title, icon, children, }: {
    title: string;
    icon?: ReactNode;
    children?: ReactNode;
}): import("react").JSX.Element;
