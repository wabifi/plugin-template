import { Checkbox as BaseCheckbox } from "@base-ui/react/checkbox";
import { type ComponentProps, type ReactNode } from "react";
export declare function Checkbox({ label, id, indeterminate, ...props }: Omit<ComponentProps<typeof BaseCheckbox.Root>, "className" | "children"> & {
    label: ReactNode;
}): import("react").JSX.Element;
