import { type AriaAttributes, type ReactElement, type ReactNode } from "react";
/** A short supplementary hint. The trigger still owns its accessible name. */
export declare function Tooltip({ children, content, delay, closeOnClick, disableHoverablePopup, side, follow, open: controlledOpen, onOpenChange, }: {
    children: ReactElement<Pick<AriaAttributes, "aria-describedby" | "aria-expanded"> & {
        "data-accent"?: string;
        "data-color-mode"?: string;
    }>;
    content: ReactNode;
    delay?: number;
    closeOnClick?: boolean;
    disableHoverablePopup?: boolean;
    side?: "top" | "right";
    /** Attach a non-interactive hint below/right of the native pointer. */
    follow?: "trigger" | "pointer";
    /** Action feedback may open a hint after an asynchronous result. */
    open?: boolean;
    onOpenChange?(open: boolean): void;
}): import("react").JSX.Element;
