import { Button as BaseButton } from "@base-ui/react/button";
import type { ComponentProps, ReactNode } from "react";
type ButtonVariant = "prominent" | "subtle" | "subtle-muted" | "ghost" | "destructive" | "outline" | "attention" | "glass" | "inverted" | "link" | "plain" | "primary" | "quiet";
type ButtonSize = "caption" | "inline" | "xs" | "sm" | "md" | "lg" | "compact" | "default";
export type ButtonProps = Omit<ComponentProps<typeof BaseButton>, "className"> & {
    children: ReactNode;
    variant?: ButtonVariant;
    size?: ButtonSize;
    loading?: boolean;
} & ({
    shape?: "capsule" | "control";
} | {
    shape: "icon";
    "aria-label": string;
});
/** Base UI owns activation. Legacy variant/size names remain during migration. */
export declare function Button({ children, variant, size, shape, type, loading, disabled, onClick, title, ...props }: ButtonProps): import("react").JSX.Element;
export {};
