import { Popover as BasePopover } from "@base-ui/react/popover";
import type { ComponentProps } from "react";
export declare const PopoverRoot: typeof BasePopover.Root;
export declare const PopoverTrigger: BasePopover.Trigger;
export declare const PopoverClose: import("react").ForwardRefExoticComponent<Omit<import("@base-ui/react").PopoverCloseProps, "ref"> & import("react").RefAttributes<HTMLButtonElement>>;
type PopoverPopupProps = Omit<ComponentProps<typeof BasePopover.Popup>, "className"> & Pick<ComponentProps<typeof BasePopover.Positioner>, "side" | "align" | "sideOffset" | "alignOffset" | "collisionPadding" | "collisionAvoidance" | "anchor" | "sticky"> & {
    /** Preserve an explicitly themed surface across the portal. */
    colorMode?: "light" | "dark" | undefined;
    /** Compact account/action surfaces use 8px corners as well as a narrower width. */
    size?: "compact" | "default" | "wide";
    /** Embedded pickers own their internal spacing. */
    padding?: "content" | "list" | "none";
};
export declare function PopoverPopup({ side, align, sideOffset, alignOffset, collisionPadding, collisionAvoidance, anchor, sticky, size, padding, colorMode, finalFocus, ref, ...props }: PopoverPopupProps): import("react").JSX.Element;
export declare function PopoverTitle(props: Omit<ComponentProps<typeof BasePopover.Title>, "className">): import("react").JSX.Element;
export declare function PopoverDescription(props: Omit<ComponentProps<typeof BasePopover.Description>, "className">): import("react").JSX.Element;
export {};
