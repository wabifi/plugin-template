import { Dialog as BaseDialog } from "@base-ui/react/dialog";
import { type ComponentProps, type ReactNode } from "react";
type PopupProps = ComponentProps<typeof BaseDialog.Popup>;
export type DialogProps = {
    open: boolean;
    onOpenChange(open: boolean): void;
    onOpenChangeComplete?: ComponentProps<typeof BaseDialog.Root>["onOpenChangeComplete"];
    title: ReactNode;
    /** Search palettes keep an accessible title without visible header chrome. */
    presentation?: "default" | "search";
    /** Introductory copy belongs in the title lockup, not a body paragraph. */
    description?: ReactNode;
    /** Omit for a header-only message; no empty body spacing is rendered. */
    children?: ReactNode;
    /** Integrated sections for an expanded modal; Dialog owns framing and scrollports. */
    navigation?: {
        label: string;
        content: ReactNode;
    };
    /** Fill a positioned host frame; null waits for its callback ref on cold opens. */
    container?: HTMLElement | null;
    actions?: ReactNode;
    /** Tighter heading-to-body spacing for compact forms. */
    headerGap?: "default" | "compact";
    /** Keep spacing beside scrolling content on the fixed header and footer. */
    chromeSpacing?: "default" | "padded";
    /** Compact groups actions; none lets a footerless scrollport reach the bottom edge. */
    footerGap?: "default" | "compact" | "none";
    /** Replace a step inside this modal; scale defines its recessed/raised position. */
    step?: {
        key: string;
        scale: number;
    };
    leadingActions?: ReactNode;
    headerActions?: ReactNode;
    /** Return true when an inner editor layer consumed Escape. */
    onEscape?: () => boolean;
    placement?: "center" | "right";
    dismissOnOutsideClick?: boolean;
    closeLabel?: string;
    /** Reserve viewport-capped space for changing content; scroll only the body. */
    height?: "content" | "stable" | "stable-tall";
    /** Let bounded content own its scrolling instead of the shared body. */
    bodyLayout?: "flow" | "flex";
    /** Compact dialogs; standard, wide, and expanded task modals. */
    size?: "compact" | "default" | "wide" | "expanded";
    /** Keep frequent surfaces such as search palettes immediate. */
    motion?: "default" | "none";
    /** A pending operation can prevent all user dismissal paths. */
    preventClose?: boolean;
    initialFocus?: PopupProps["initialFocus"];
    finalFocus?: PopupProps["finalFocus"];
};
/** Base UI owns the modal, portal, focus trap, Escape and focus restoration. */
export declare function Dialog({ open, onOpenChange, onOpenChangeComplete, title, presentation, description, children, navigation, container, actions, headerGap, chromeSpacing, footerGap, step, leadingActions, headerActions, onEscape, placement, dismissOnOutsideClick, closeLabel, size, preventClose, motion, height, bodyLayout, initialFocus, finalFocus, }: DialogProps): import("react").JSX.Element;
export {};
