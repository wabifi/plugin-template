import "../styles/avatar-shape.css";
import "../styles/avatar-status.css";
import { type ReactNode } from "react";
type AvatarSize = "compact" | "small" | "default" | "large" | "fill";
export declare function Avatar({ src, alt, fallback, fallbackContent, size, shape, statusBadge, loading, }: {
    src?: string | null | undefined;
    alt: string;
    fallback: string;
    fallbackContent?: ReactNode;
    size?: AvatarSize;
    shape?: "circle" | "squircle";
    statusBadge?: "online" | "away" | "offline" | undefined;
    /** Immediate visible editors may bypass lazy scheduling, never image readiness. */
    loading?: "eager" | "lazy";
}): import("react").JSX.Element;
export {};
