import { type ReactNode } from "react";
type Tone = "error" | "warning" | "info" | "success";
/** Mount once in the host. Sonner owns announcements, expiry and swiping. */
export declare function ToastProvider({ children, portalContainer, }: {
    children: ReactNode;
    portalContainer?: HTMLElement | undefined;
}): import("react").JSX.Element;
/** A notice lives with its source; removing it clears its floating presentation. */
export declare function ToastNotice({ title, description, children, onDismiss, closeLabel, timeout, tone, }: {
    title: string;
    description?: string;
    children?: ReactNode;
    onDismiss?: () => void;
    closeLabel?: string;
    /** Zero keeps recovery visible until its source resolves or explicitly dismisses. */
    timeout?: number;
    tone?: Tone;
}): null;
/** Close host-owned feedback when its action is no longer valid. */
export declare function useToastDismiss(): (id?: number | string) => string | number;
/** Completed actions outlive their originating row. */
export declare function useToastNotification(): (title: string, tone: "success" | "error" | "info", action?: {
    label: string;
    onClick(): void;
}) => string;
export {};
