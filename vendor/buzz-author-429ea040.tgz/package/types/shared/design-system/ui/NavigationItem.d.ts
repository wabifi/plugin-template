import { Button as BaseButton } from "@base-ui/react/button";
import type { ComponentProps, ReactNode } from "react";
export declare function NavigationItem({ label, icon, trailing, selected, highlighted, inset, variant, ...props }: {
    label: ReactNode;
    icon?: ReactNode;
    trailing?: ReactNode;
    selected?: boolean;
    /** Transient picker focus; persistent navigation selection stays separate. */
    highlighted?: boolean;
    inset?: boolean;
    variant?: "row" | "pill" | "option" | "search" | "text";
} & Omit<ComponentProps<typeof BaseButton>, "className" | "children">): import("react").JSX.Element;
