/** Shared activity motion. Callers own receipt/work evidence and accessible labels. */
export declare function TypingDots({ state, size, }: {
    state?: "waiting" | "working";
    size?: "default" | "small";
}): import("react").JSX.Element;
