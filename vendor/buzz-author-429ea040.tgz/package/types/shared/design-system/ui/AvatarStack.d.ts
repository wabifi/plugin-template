type StackAvatar = {
    id: string;
    name: string;
    src?: string | undefined;
    shape: "circle" | "squircle";
};
/** Compact identity artwork. The enclosing control supplies its accessible name. */
export declare function AvatarStack({ items, size, max, }: {
    items: readonly StackAvatar[];
    size?: "compact" | "small" | "mini" | "hero";
    /** How many avatars show before the overflow count. */
    max?: number;
}): import("react").JSX.Element | null;
export {};
