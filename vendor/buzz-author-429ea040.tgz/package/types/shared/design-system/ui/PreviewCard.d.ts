import { PreviewCard as BasePreviewCard } from "@base-ui/react/preview-card";
import { type ReactElement, type ReactNode, type RefObject } from "react";
export type PreviewCardProps = {
    /** The one interactive element that anchors and reveals this preview. */
    trigger: ReactElement;
    /** Context that supplements, but never replaces, the trigger's destination. */
    children: ReactNode;
    open?: boolean;
    onOpenChange?: BasePreviewCard.Root.Props["onOpenChange"];
    side?: BasePreviewCard.Positioner.Props["side"];
    /** Optional content anchor when the trigger owns a wider hit area. */
    anchor?: BasePreviewCard.Positioner.Props["anchor"];
    delay?: number;
    className?: string;
    id?: string;
    "aria-label"?: string;
    /** Optional anchor that makes the whole card open the trigger's destination. */
    link?: ReactElement;
    /** One supplemental action, reachable from the trigger with Tab. Not used with link. */
    actionRef?: RefObject<HTMLButtonElement | null>;
};
/**
 * A non-modal, portal-rendered preview of a resolved object.
 *
 * Base UI owns the hover/focus timing, anchored positioning, viewport collision,
 * and portal lifecycle. The preview stays supplemental: it does not take focus
 * automatically. A destination card can be reached with Tab.
 */
export declare function PreviewCard({ trigger, children, open, onOpenChange, side, anchor, delay, className, id, link, actionRef, "aria-label": label, }: PreviewCardProps): import("react").JSX.Element;
