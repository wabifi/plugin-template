import type { ComponentProps } from "react";
export type TextareaProps = Omit<ComponentProps<"textarea">, "className">;
/** Field.Control supplies the same label/validation behavior as Input. */
export declare function Textarea({ variant, surface, appearance, id, name, value, defaultValue, disabled, autoFocus, ref, ...props }: TextareaProps & {
    variant?: "text" | "code";
    surface?: "inset" | "panel";
    /** A transparent, outlined field instead of the default inset fill. */
    appearance?: "field" | "outlined";
}): import("react").JSX.Element;
