import type { IconProps } from "./createDecorativeIcon";
/** Tabler-style chat bubble with a separate, designer-requested unread dot. */
export declare const ChatUnreadArtwork: import("react").ForwardRefExoticComponent<Omit<IconProps, "ref"> & import("react").RefAttributes<SVGSVGElement>>;
