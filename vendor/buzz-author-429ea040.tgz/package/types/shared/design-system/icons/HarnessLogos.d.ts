import type { IconProps } from "./createDecorativeIcon";
/** Goose's official mark, adapted from old Buzz. Apache-2.0 © Block, Inc.; see NOTICE.md. */
export declare const GooseLogoArtwork: import("react").ForwardRefExoticComponent<Omit<IconProps, "ref"> & import("react").RefAttributes<SVGSVGElement>>;
/** Pi's official favicon, adapted from old Buzz. MIT © 2026 Earendil Inc. and contributors; see NOTICE.md. */
export declare const PiLogoArtwork: import("react").ForwardRefExoticComponent<Omit<IconProps, "ref"> & import("react").RefAttributes<SVGSVGElement>>;
/** Claude's bundled brand mark, reused unchanged from old Buzz; see NOTICE.md. */
export declare const ClaudeLogoArtwork: import("react").ForwardRefExoticComponent<Omit<IconProps, "ref"> & import("react").RefAttributes<SVGSVGElement>>;
/** Hermes's bundled brand mark, reused unchanged from old Buzz; see NOTICE.md. */
export declare const HermesLogoArtwork: import("react").ForwardRefExoticComponent<Omit<IconProps, "ref"> & import("react").RefAttributes<SVGSVGElement>>;
/** OpenAI's Blossom mark for Codex, from OpenAI's brand kit; see NOTICE.md. */
export declare const CodexLogoArtwork: import("react").ForwardRefExoticComponent<Omit<IconProps, "ref"> & import("react").RefAttributes<SVGSVGElement>>;
