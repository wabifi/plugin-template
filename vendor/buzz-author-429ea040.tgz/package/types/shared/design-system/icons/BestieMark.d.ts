import { type SVGProps } from "react";
/** Bestie's raster companion mark, framed as an icon so navigation rows and search can size it. */
export declare const BestieMarkArtwork: import("react").ForwardRefExoticComponent<Omit<SVGProps<SVGSVGElement> & {
    size?: number | string;
    weight?: string;
    mirrored?: boolean;
}, "ref"> & import("react").RefAttributes<SVGSVGElement>>;
