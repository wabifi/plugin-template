import { type SVGProps } from "react";
/** Custom outline recreation of the Microsoft OneDrive cloud mark. */
export declare const OneDriveLogoArtwork: import("react").ForwardRefExoticComponent<Omit<SVGProps<SVGSVGElement> & {
    size?: number | string;
}, "ref"> & import("react").RefAttributes<SVGSVGElement>>;
