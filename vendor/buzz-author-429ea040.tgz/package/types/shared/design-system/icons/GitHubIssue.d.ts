import { type SVGProps } from "react";
/** GitHub's open-issue mark, using Phosphor Circle's regular full-canvas geometry. */
export declare const GitHubIssueArtwork: import("react").ForwardRefExoticComponent<Omit<SVGProps<SVGSVGElement> & {
    size?: number | string;
}, "ref"> & import("react").RefAttributes<SVGSVGElement>>;
