/** Copy control for a row that intentionally shows a label instead of a key. */
export declare function CopyKeyButton({ pubkey, size, }: {
    pubkey: string;
    size?: "compact" | "xs";
}): import("react").JSX.Element | null;
