/** The genuine name in a profile projection, or undefined when it is exactly
 * one of this identity's key spellings. `foldProfiles` uses the first ten key
 * characters; callers historically used the npub, its full form, or an
 * abbreviation. Compare only against that exact identity so a real name that
 * happens to look like hex (for example, "1234567890") survives. */
export declare function profileDisplayName(name: string | undefined, pubkey: string): string | undefined;
/** One plain fallback for a verified owner whose profile has no name. */
export declare const VERIFIED_AGENT = "Verified agent";
