/** The npub of a lowercase hex key. Bech32 encoding is the cost of resolving a
 * display name, which lists redo for every row on every render, so remember the
 * result. The map is bounded; a full map restarts empty. */
export declare function npubOf(pubkey: string): string;
/** The full npub of a hex public key, or undefined for anything else. */
export declare function canonicalPublicKey(pubkey: string): string | undefined;
/** Display only: never use this abbreviation for copying, storage or routing. */
export declare function formatPublicKey(pubkey: string, suffixLength?: number): string | undefined;
/** Distinct public identities share the shortest unambiguous suffix, starting at three. */
export declare function publicKeyLabels(pubkeys: Iterable<string>): ReadonlyMap<string, string>;
