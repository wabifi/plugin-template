export declare function draftCoordinates(key: string): {
    channelId: string;
    threadRootId?: string;
} | undefined;
/** Same durable view keys as the composer; no parallel draft store or index. */
export declare function subscribeView(scope: string, listener: () => void): () => void;
export declare function readView<T>(scope: string, key: string, fallback: T): T;
/** Exact serialized revision; undefined means storage could not be read. */
export declare function viewRevision(scope: string, key: string): string | null | undefined;
export declare function writeView(scope: string, key: string, value: unknown): boolean;
/** Foreground comparison, not a cross-window transaction or lock. */
export declare function replaceView(scope: string, key: string, expected: string | null | undefined, value: unknown): "saved" | "changed" | "failed";
/** Snapshot of a viewer's existing composer drafts, never other view coordinates. */
export declare function listDraftViews(scope: string, meaningful: (value: unknown) => boolean, selected?: string): Readonly<{
    entries: readonly Readonly<{
        key: string;
        value: unknown;
    }>[];
    limited: boolean;
    unavailable: number;
}>;
/** Forgets every key saved under one scope, for a community the viewer has left. */
export declare function clearViewScope(scope: string): void;
/** Recovery callers must confirm cleanup before retiring their durable operation. */
export declare function clearView(scope: string, ...keys: string[]): void;
