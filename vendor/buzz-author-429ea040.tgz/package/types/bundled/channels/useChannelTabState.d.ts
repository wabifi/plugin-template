import type { RelaySession } from "../../features/relay/session";
import type { PanelOpening } from "../../features/panels/service";
export type ConversationTab = {
    id: string;
    kind: "conversation";
    channelId: string;
    /** The message the tab opens at, revealed once per `revealRequest`. */
    messageId?: string | undefined;
    revealRequest?: number | undefined;
    /** False: seeing messages here marks none read; the opener decides. */
    markRead?: false | undefined;
    /** Each new value focuses the composer. */
    focusRequest?: number | undefined;
} | {
    id: string;
    kind: "thread";
    channelId: string;
    messageId: string;
    replyRequest?: number | undefined;
    /** Each new value focuses the reply box, keeping its target. */
    focusRequest?: number | undefined;
    /** Each new value reveals `messageId` again; set only by openings at it. */
    revealRequest?: number | undefined;
    /** Transient visual cue when an opening reuses this tab. */
    attentionRequest?: number | undefined;
    /** Threads live in the side pane unless moved or opened into main. */
    pane?: TabPane | undefined;
    /** The reader's verified root, which may differ from a link's hint. */
    rootId?: string | undefined;
    /** A name given to the tab, shown instead of its root's text. */
    name?: string | undefined;
};
export type TabPane = "main" | "side";
export declare const tabPane: (tab: ConversationTab) => TabPane;
type VisitSelection = {
    selected: string;
    mainSelected?: string | undefined;
    paneOpen: boolean;
};
type State = {
    entries: PanelOpening[];
    tabs: ConversationTab[];
    selected: string;
    /** Selected main-pane tab; undefined is the channel conversation. */
    mainSelected?: string | undefined;
    /** The last history visit applied, so remounting never reapplies it. */
    visit?: string | undefined;
    /** Selection each recent visit had when it was left. */
    visits?: Record<string, VisitSelection> | undefined;
    /** The current visit's selection was already captured as it was left. */
    left?: boolean;
    paneOpen: boolean;
    thread: {
        channelId: string;
        messageId: string;
    } | undefined;
    settings: {
        id: string;
        channelId: string | undefined;
    } | undefined;
    /** A launcher's side panel shows in the pane; the page owns that panel. */
    sidePanel?: boolean;
};
export declare const panelTabId: (entry: PanelOpening) => string;
export declare const selectedTabId: (selected: string, ids: readonly string[]) => string;
/** A channel's open tab for a thread: by its verified root, or until then by
 * the id it was opened with. */
export declare const threadTab: (tabs: readonly ConversationTab[], channelId: string, rootId: string) => ConversationTab | undefined;
/** Reply asks for the composer; select keeps the tab's requests; reveal asks
 * the reader to show `messageId` again. */
export type ThreadIntent = "reply" | "select" | "reveal" | "focus";
export declare const rootOfTab: (tab: Extract<ConversationTab, {
    kind: "thread";
}>) => string;
/** A channel's own thread tabs in its workspace, changed from outside the
 * page. Tabs the viewer opened for other channels' threads are left alone.
 * Opening never moves the viewer's selection or focus, and closing refuses
 * the tab the viewer sees, so no selection needs repair. */
export declare function channelTabs(session: RelaySession): {
    list: (channelId: string) => {
        root: string;
        pane: TabPane;
        name: string | undefined;
        shown: boolean;
    }[];
    /** Opens thread `rootId` of `channelId` in its workspace; false when it
     * already has a tab there. */
    open(channelId: string, rootId: string): boolean;
    close(channelId: string, rootId: string): "closed" | "missing" | "shown";
    /** Names thread `rootId`'s tab; an empty name restores its automatic
     * title. False when it has no tab there. */
    rename(channelId: string, rootId: string, name: string): boolean;
};
/** No credentials, page callbacks, or DOM elements are retained. */
export declare function useChannelTabState(session: RelaySession, channelId: string | undefined, page?: string): {
    entries: PanelOpening[];
    tabs: ConversationTab[];
    selected: string;
    /** Selected main-pane tab; undefined is the channel conversation. */
    mainSelected?: string | undefined;
    /** The last history visit applied, so remounting never reapplies it. */
    visit?: string | undefined;
    /** Selection each recent visit had when it was left. */
    visits?: Record<string, VisitSelection> | undefined;
    /** The current visit's selection was already captured as it was left. */
    left?: boolean;
    paneOpen: boolean;
    thread: {
        channelId: string;
        messageId: string;
    } | undefined;
    settings: {
        id: string;
        channelId: string | undefined;
    } | undefined;
    /** A launcher's side panel shows in the pane; the page owns that panel. */
    sidePanel?: boolean;
    getSelected: () => string;
    setEntries: (entries: PanelOpening[]) => void;
    retireMenuEntries: () => void;
    setTabs: (change: (tabs: ConversationTab[]) => ConversationTab[]) => void;
    openThreadTab: (channelId: string, messageId: string, rootId: string, intent?: ThreadIntent, pane?: TabPane) => void;
    moveTab: (id: string, pane: TabPane, index: number) => void;
    resolveThreadRoot: (id: string, rootId: string) => void;
    divertThread: (id: string, requested: string, kept: string) => void;
    enterVisit: (visit: string, routed?: {
        channelId: string;
        messageId: string;
        rootId: string;
        pane?: TabPane | undefined;
    }, keep?: boolean) => void;
    leaveVisit: () => void;
    selectMain: (mainSelected: string | undefined) => void;
    select: (selected: string) => void;
    setThread: (thread: State["thread"]) => void;
    setSettings: (settings: {
        channelId: string | undefined;
    } | undefined) => void;
    setPaneOpen: (paneOpen: boolean) => void;
    setSidePanel: (sidePanel: boolean) => void;
    renameTab: (id: string, name: string) => void;
    closeTabs: (keep?: string) => void;
};
export {};
