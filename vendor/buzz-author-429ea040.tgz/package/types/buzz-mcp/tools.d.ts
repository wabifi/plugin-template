import type { BuzzClient, Context } from "./client";
declare const tool: (name: string, description: string, properties: Readonly<Record<string, object>>, required?: readonly string[]) => {
    name: string;
    description: string;
    inputSchema: {
        type: string;
        properties: Readonly<Record<string, object>>;
        required?: readonly string[];
        additionalProperties: boolean;
    };
};
export type Tool = ReturnType<typeof tool>;
export declare const TOOLS: readonly Tool[];
type Args = Readonly<Record<string, unknown>>;
/** A tool's answer: text, or an image (base64 `data`) for the agent to see,
 * with any `text` about it. */
export type Reply = string | Readonly<{
    data: string;
    type: string;
    text?: string;
}>;
/** Runs tool `name` for an agent working in `context`. A throw is a tool
 * error for the agent to correct. */
export declare function callTool(client: BuzzClient, context: Context, name: string, args: Args): Promise<Reply>;
export {};
